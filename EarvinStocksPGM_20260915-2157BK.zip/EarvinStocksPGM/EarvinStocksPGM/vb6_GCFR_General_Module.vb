'***************************************************************************************************
'* ���ҲթҦ����禡�����@�� -- 20080910 --
'***************************************************************************************************

Option Explicit
Option Base 1
Dim sngMax(8) As Single, sngMin(8) As Single

'***************************************************************************************************
'* ��    ��: �q���w���ɮצW�٤�Ū�X�H�鬰��쪺�򥻸��
'* ��J�Ѽ�: strFileName �C��ѻ�����ɮצW��
'* ��X�Ѽ�: Ū�ɦ��\�^��true�F���Ѧ^��false
'* ��    ��: 2.00 20080910 �s�W
'*           2.01 20081209 �վ�榡�μW�[����
'***************************************************************************************************
Public Function subReadData(ByVal inputFileName As String) As Boolean
    Dim path As String
    Dim intFileNo As Integer
    Dim openFile As String
    
    On Error GoTo ERR_HANDLE
    
    ' [WAIT-TO-DO]
    openFile = FILEPATH & inputFileName
    
    path = GetAppPath
    openFile = path + "myPGMs\DATA\dat\" & inputFileName
    
    
    If Dir(openFile) = "" Then
        MsgBox "�Ѳ���Ƥ��s�b", vbOKOnly
        subReadData = False
        blnOpenFileSuccess = False
    Else
        ' Reading the data of personal stock
        intFileNo = FreeFile()
        Open openFile For Binary As #intFileNo ' Opening the individual stock
        subReadData = True
      
        '---��ѥ���Ƭ�����T --------------------------------------
        gintDayIndex = LOF(intFileNo) / Len(gudtMydata)
        gsngEndIndex = gintDayIndex
        gsngStartIndex = Int(gsngEndIndex - frmEarvinStocks.Width / gsngBarWidth)  ' �����e�� / K-Bar�e��
        ReDim gudtStockDay(gintDayIndex)  ' ��ѥ����
        ReDim gudtIndexDay(gintDayIndex)  ' ��޳N���и��
             
        ' Read the data of personal stock
        Get #intFileNo, , gudtStockDay
        Close #intFileNo
                
        '--- �g�ѥ���Ƭ�����T --------------------------------------
        If Int(gintDayIndex / 3) = 0 Then   ' ���H3���ӥu�O���F�j���p��t�m�g���array���Ŷ�
            gintWeekIndex = 1
        Else
            gintWeekIndex = gintDayIndex / 3
        End If
        
        ReDim gudtStockWeek(gintWeekIndex)   ' �g�ѥ����
        ReDim gudtIndexWeek(gintWeekIndex)   ' �g�޳N���и��

        '--- ��ѥ���Ƭ�����T --------------------------------------
'        If Int(gintWeekIndex / 3) = 0 Then  ' ���H3���ӥu�O���F�j���p��t�m����array���Ŷ�
        If Int(gintWeekIndex / 4) = 0 Then  ' 20230615 ���ӬO���H4����X�z
            gintMonthIndex = 1
        Else
            gintMonthIndex = gintWeekIndex / 4
        End If
      
        ReDim gudtStockMonth(gintMonthIndex)    ' ��ѥ����
        ReDim gudtIndexMonth(gintMonthIndex)    ' ��޳N���и��
  
        ' �I�s�p����Ш禡 : ���ͤ���и��
        Call subCalculateIndex(gudtStockDay, gudtIndexDay, gintDayIndex)
        ' To general the weekly stock data from daily stock data
        Call subGenerateWeek(gintDayIndex, gudtStockWeek)
        ' �I�s�p����Ш禡 : ���Ͷg���и��
        Call subCalculateIndex(gudtStockWeek, gudtIndexWeek, gintWeekIndex)
        ' To general the monthly stock data from daily stock data
        Call subGenerateMonth(gintWeekIndex, gudtStockMonth)
        ' �I�s�p����Ш禡 : ���ͤ���и��
        Call subCalculateIndex(gudtStockMonth, gudtIndexMonth, gintMonthIndex)
      
        If frmEarvinStocks.lblDateType.Caption = "��u" Then
            gsngEndIndex = gintDayIndex
        ElseIf frmEarvinStocks.lblDateType.Caption = "�g�u" Then
            gsngEndIndex = gintWeekIndex
        ElseIf frmEarvinStocks.lblDateType.Caption = "��u" Then
            gsngEndIndex = gintMonthIndex
        End If
        gsngStartIndex = Int(gsngEndIndex - frmEarvinStocks.Width / gsngBarWidth)
    End If
    
    Exit Function
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.subReadData()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Function


'***************************************************************************************************
'* ��    ��: ����p��Ҧ����޳N���Ъ��{��
'* ��J�Ѽ�: Stockdata  �ѻ����
'*           IndexData  �޳N���и��
'*           intStockNo ��Ƶ���
'* ��X�Ѽ�: �L
'* ��    ��: 2.00 20080910 �s�W
'*           2.01 20081209 �վ�榡�μW�[����
'***************************************************************************************************
Public Sub subCalculateIndex(ByRef udtStock() As StockData, _
                             ByRef udtIndex() As IndexData, _
                             ByVal intStockNo As Integer)
    
    On Error GoTo ERR_HANDLE
    
    Call subAverage(udtStock, udtIndex, intStockNo, MAP_0, 0, True)
    Call subAverage(udtStock, udtIndex, intStockNo, MAP_1, 1, True)
    Call subAverage(udtStock, udtIndex, intStockNo, MAP_2, 2, True)
    Call subAverage(udtStock, udtIndex, intStockNo, MAP_3, 3, True)
    Call subAverage(udtStock, udtIndex, intStockNo, MAP_4, 4, True)
    Call subAverage(udtStock, udtIndex, intStockNo, MAP_5, 5, True)
    Call subAverage(udtStock, udtIndex, intStockNo, MAP_6, 6, True)
    Call subAverage(udtStock, udtIndex, intStockNo, MAP_7, 7, True)
  
    Call subPSY(udtStock, udtIndex, intStockNo, PSY_No)
    Call subEMA(udtStock, udtIndex, intStockNo, EMA_NO)
    Call subWMS(udtStock, udtIndex, intStockNo, WMS_No)
    Call subRWMS(udtStock, udtIndex, intStockNo, WMS_No)
    Call subRSI(udtStock, udtIndex, intStockNo, RSI_S, True)
    Call subRSI(udtStock, udtIndex, intStockNo, RSI_L, False)
    Call subStochRSI(udtStock, udtIndex, intStockNo)
    Call subWRSI(udtStock, udtIndex, intStockNo, WRSI)
    Call subMAWRSI(udtStock, udtIndex, intStockNo, MAWRSI, SMAorEMA_WRSI)
    Call subKD(udtStock, udtIndex, intStockNo, KD_No)
    Call subMACD(udtStock, udtIndex, intStockNo, MACD_No, EMA_S, EMA_L, False)
    Call subBias(udtStock, udtIndex, intStockNo, Bias_No)
    
    Call subAverage(udtStock, udtIndex, intStockNo, MAV_1, 1, False)
    Call subAverage(udtStock, udtIndex, intStockNo, MAV_2, 2, False)
    Call subAverage(udtStock, udtIndex, intStockNo, MAV_3, 3, False)
    Call subAverage(udtStock, udtIndex, intStockNo, MAV_4, 4, False)
    Call subAverage(udtStock, udtIndex, intStockNo, MAV_5, 5, False)
    Call subGenerateAcc(gintDayIndex, gudtVolAcc)
    Call subVolumnRatio(gintDayIndex, gudtStockDay)
    Call subShortTerm(gintDayIndex, gudtStockDay, intHeadOrLow)
  
  
    '=======================================================================
    '* GCFR Model: �p��޳N����
    '=======================================================================
    '--- �p�⦬�L�� ---
    Call subAverage2(udtStock, udtIndex, intStockNo, 3, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 4, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 5, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 6, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 8, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 10, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 12, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 20, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 24, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 30, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 60, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 72, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 120, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 144, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 240, True)
    Call subAverage2(udtStock, udtIndex, intStockNo, 288, True)
    '--- �p�⦨��q ---
    Call subAverage2(udtStock, udtIndex, intStockNo, 3, False)
    Call subAverage2(udtStock, udtIndex, intStockNo, 5, False)
    Call subAverage2(udtStock, udtIndex, intStockNo, 6, False)
    Call subAverage2(udtStock, udtIndex, intStockNo, 10, False)
    Call subAverage2(udtStock, udtIndex, intStockNo, 12, False)
    Call subAverage2(udtStock, udtIndex, intStockNo, 20, False)
    Call subAverage2(udtStock, udtIndex, intStockNo, 24, False)
    '--- �䥦�޳N���� ---
    Call subPSY(udtStock, udtIndex, intStockNo, PSY_No)
    Call subWMS(udtStock, udtIndex, intStockNo, WMS_No)
    Call subRSI(udtStock, udtIndex, intStockNo, RSI_S, True)
    Call subRSI(udtStock, udtIndex, intStockNo, RSI_L, False)
    Call subKD(udtStock, udtIndex, intStockNo, KD_No)
    Call subMACD(udtStock, udtIndex, intStockNo, MACD_No, EMA_S, EMA_L, False)
    Call subBias(udtStock, udtIndex, intStockNo, Bias_No)
    
    Call subVR(udtStock, udtIndex, intStockNo, 12)
    Call subMASlope(udtStock, udtIndex, intStockNo, 60)
'   Call subMADistance(udtStock, udtIndex, intStockNo, 60)
    Call subMAPDis(udtStock, udtIndex, intStockNo)
    Call subLBias(udtStock, udtIndex, intStockNo, 60)
    Call subSBias(udtStock, udtIndex, intStockNo, 10)
    Call subLSBias(udtStock, udtIndex, intStockNo)
    Call subBullList(udtStock, udtIndex, intStockNo)
    Call subBearList(udtStock, udtIndex, intStockNo)
    Call subIsInRange(udtStock, udtIndex, intStockNo)
    Call subUpDownDays(udtStock, udtIndex, intStockNo)
    '=======================================================================
    '* GCFR Model: �p��޳N����     --- END ---
    '=======================================================================

    '=======================================================================
    '* ���Ͱ��B�C�I���
    '=======================================================================
    Call subGenLowPointDate(udtStock, udtIndex, intStockNo)
    Call subGenHighPointDate(udtStock, udtIndex, intStockNo)
    
    Exit Sub
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.subCalculateIndex()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Sub


'***************************************************************************************************
'* ��    ��: �q�骺�򥻸�Ƥ��A���Ͷg���򥻸��
'* ��J�Ѽ�: gintDayIndex  ��ѥ���Ƶ���
'*           gudtStockWeek �g�ѥ����
'* ��X�Ѽ�: �L
'* ��    ��: 2.00 20080910 �s�W
'*           2.01 20081209 �վ�榡�μW�[����
'***************************************************************************************************
Public Sub subGenerateWeek(ByVal gintDayIndex As Integer, _
                           ByRef gudtStockWeek() As StockData)
    Dim i As Integer
    Dim lngYear As Long
    Dim lngMonth As Long
    Dim lngDay As Long
    Dim datDate As Date
    Dim lngTemp As Long
    Dim intWeekDay As Integer
    Dim intWeekFlag As Integer
    Dim blnFirst As Boolean
    
    i = 1
    gintWeekIndex = 1
    intWeekFlag = 0
    blnFirst = True
    
    On Error GoTo ERR_HANDLE
    
    '*** Weekday() �Ѽƪ��N�q ***********************************************
    ' FirstDayOfWeek.System    0  �t�γ]�w�����w���C�g�Ĥ@��
    ' FirstDayOfWeek.Sunday    1  �P���� (�w�]��)
    ' FirstDayOfWeek.Monday    2  �P���@ (�ŦX ISO �з� 8601 ���� 3.17 �`)
    ' FirstDayOfWeek.Tuesday   3  �P���G
    ' FirstDayOfWeek.Wednesday 4  �P���T
    ' FirstDayOfWeek.Thursday  5  �P���|
    ' FirstDayOfWeek.Friday    6  �P����
    ' FirstDayOfWeek.Saturday  7  �P����
    '************************************************************************
    
    
    While i <= gintDayIndex
        lngTemp = gudtStockDay(i).sngDate
        lngYear = Int(lngTemp / 10000)   ' ���X�~
        lngMonth = Int((lngTemp - lngYear * 10000) / 100)  ' ���X��
        lngDay = lngTemp - lngYear * 10000 - lngMonth * 100   ' ���X��
        lngYear = lngYear + 1911
        datDate = DateSerial(lngYear, lngMonth, lngDay) ' �ഫ�����
        intWeekDay = Weekday(datDate) ' �p�⤵�ѬO�P���X
      
        If intWeekFlag < intWeekDay Then
            If blnFirst Then
                gudtStockWeek(gintWeekIndex).sngStartprice = gudtStockDay(i).sngStartprice
                gudtStockWeek(gintWeekIndex).sngHighPrice = gudtStockDay(i).sngHighPrice
                gudtStockWeek(gintWeekIndex).sngLowPrice = gudtStockDay(i).sngLowPrice
                blnFirst = False
            End If
            ' �̰���
            If gudtStockWeek(gintWeekIndex).sngHighPrice < gudtStockDay(i).sngHighPrice Then
                gudtStockWeek(gintWeekIndex).sngHighPrice = gudtStockDay(i).sngHighPrice
            End If
            ' �̧C��
            If gudtStockWeek(gintWeekIndex).sngLowPrice > gudtStockDay(i).sngLowPrice Then
                gudtStockWeek(gintWeekIndex).sngLowPrice = gudtStockDay(i).sngLowPrice
            End If
            gudtStockWeek(gintWeekIndex).sngDate = gudtStockDay(i).sngDate
            gudtStockWeek(gintWeekIndex).sngEndprice = gudtStockDay(i).sngEndprice
            gudtStockWeek(gintWeekIndex).sngVol = gudtStockWeek(gintWeekIndex).sngVol + gudtStockDay(i).sngVol
            gudtStockWeek(gintWeekIndex).sngAcc = gudtStockWeek(gintWeekIndex).sngAcc + gudtStockDay(i).sngAcc      ' �ĸ�
            gudtStockWeek(gintWeekIndex).sngTome = gudtStockWeek(gintWeekIndex).sngTome + gudtStockDay(i).sngTome   ' �Ĩ�
         
            gudtStockWeek(gintWeekIndex).sngForeignStock = gudtStockWeek(gintWeekIndex).sngForeignStock + gudtStockDay(i).sngForeignStock                   ' �~��w�s
            gudtStockWeek(gintWeekIndex).sngSitAndCbStock = gudtStockWeek(gintWeekIndex).sngSitAndCbStock + gudtStockDay(i).sngSitAndCbStock                ' ��H�w�s
            gudtStockWeek(gintWeekIndex).sngSelfEmployedStock = gudtStockWeek(gintWeekIndex).sngSelfEmployedStock + gudtStockDay(i).sngSelfEmployedStock    ' ����Ӯw�s
            gudtStockWeek(gintWeekIndex).sngLegalPersonStock = gudtStockWeek(gintWeekIndex).sngLegalPersonStock + gudtStockDay(i).sngLegalPersonStock       ' �k�H�w�s
         
            intWeekFlag = intWeekDay
        Else
            intWeekFlag = intWeekDay
            gintWeekIndex = gintWeekIndex + 1
            gudtStockWeek(gintWeekIndex).sngDate = gudtStockDay(i).sngDate
            gudtStockWeek(gintWeekIndex).sngStartprice = gudtStockDay(i).sngStartprice
            gudtStockWeek(gintWeekIndex).sngHighPrice = gudtStockDay(i).sngHighPrice
            gudtStockWeek(gintWeekIndex).sngLowPrice = gudtStockDay(i).sngLowPrice
            gudtStockWeek(gintWeekIndex).sngEndprice = gudtStockDay(i).sngEndprice
            gudtStockWeek(gintWeekIndex).sngVol = gudtStockWeek(gintWeekIndex).sngVol + gudtStockDay(i).sngVol
            gudtStockWeek(gintWeekIndex).sngAcc = gudtStockWeek(gintWeekIndex).sngAcc + gudtStockDay(i).sngAcc      ' �ĸ�
            gudtStockWeek(gintWeekIndex).sngTome = gudtStockWeek(gintWeekIndex).sngTome + gudtStockDay(i).sngTome   ' �Ĩ�
        
            gudtStockWeek(gintWeekIndex).sngForeignStock = gudtStockWeek(gintWeekIndex).sngForeignStock + gudtStockDay(i).sngForeignStock                   ' �~��w�s
            gudtStockWeek(gintWeekIndex).sngSitAndCbStock = gudtStockWeek(gintWeekIndex).sngSitAndCbStock + gudtStockDay(i).sngSitAndCbStock                ' ��H�w�s
            gudtStockWeek(gintWeekIndex).sngSelfEmployedStock = gudtStockWeek(gintWeekIndex).sngSelfEmployedStock + gudtStockDay(i).sngSelfEmployedStock    ' ����Ӯw�s
            gudtStockWeek(gintWeekIndex).sngLegalPersonStock = gudtStockWeek(gintWeekIndex).sngLegalPersonStock + gudtStockDay(i).sngLegalPersonStock       ' �k�H�w�s
        
        End If
        i = i + 1
    Wend
    
    Exit Sub
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.subGenerateWeek()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Sub


'***************************************************************************************************
'* ��    ��: �q�g���򥻸�Ƥ��A���ͤ몺�򥻸��
'* ��J�Ѽ�: gintDayIndex �g�ѥ���Ƶ���
'*           gudtStockWeek ��ѥ����
'* ��X�Ѽ�: �L
'* ��    ��: 2.00 20080910 �s�W
'*           2.01 20081223 �վ�榡�μW�[����
'***************************************************************************************************
Public Sub subGenerateMonth(ByVal gintWeekIndex As Integer, _
                            ByRef gudtStockMonth() As StockData)
    Dim i As Integer
    Dim intMonthFlag As Integer
    
    i = 1
    gintMonthIndex = 0
    
    On Error GoTo ERR_HANDLE
    
    While i <= gintWeekIndex
        With gudtStockWeek(i)
            intMonthFlag = .sngDate \ 100
            If gintMonthIndex = 0 Then
                gintMonthIndex = gintMonthIndex + 1
                gudtStockMonth(gintMonthIndex).sngDate = intMonthFlag
                gudtStockMonth(gintMonthIndex).sngStartprice = .sngStartprice
                gudtStockMonth(gintMonthIndex).sngHighPrice = .sngHighPrice
                gudtStockMonth(gintMonthIndex).sngLowPrice = .sngLowPrice
                gudtStockMonth(gintMonthIndex).sngEndprice = .sngEndprice
                gudtStockMonth(gintMonthIndex).sngVol = .sngVol
                gudtStockMonth(gintMonthIndex).sngAcc = .sngAcc     ' �ĸ�
                gudtStockMonth(gintMonthIndex).sngTome = .sngTome   ' �Ĩ�
                gudtStockMonth(gintMonthIndex).sngForeignStock = .sngForeignStock               ' �~��w�s
                gudtStockMonth(gintMonthIndex).sngSitAndCbStock = .sngSitAndCbStock             ' ��H�w�s
                gudtStockMonth(gintMonthIndex).sngSelfEmployedStock = .sngSelfEmployedStock     ' ����Ӯw�s
                gudtStockMonth(gintMonthIndex).sngLegalPersonStock = .sngLegalPersonStock       ' �k�H�w�s
            Else
                If gudtStockMonth(gintMonthIndex).sngDate <> intMonthFlag Then
                    gintMonthIndex = gintMonthIndex + 1
                    gudtStockMonth(gintMonthIndex).sngDate = intMonthFlag
                    gudtStockMonth(gintMonthIndex).sngStartprice = .sngStartprice
                    gudtStockMonth(gintMonthIndex).sngHighPrice = .sngHighPrice
                    gudtStockMonth(gintMonthIndex).sngLowPrice = .sngLowPrice
                    gudtStockMonth(gintMonthIndex).sngEndprice = .sngEndprice
                    gudtStockMonth(gintMonthIndex).sngVol = .sngVol
                    gudtStockMonth(gintMonthIndex).sngAcc = .sngAcc      ' �ĸ�
                    gudtStockMonth(gintMonthIndex).sngTome = .sngTome    ' �Ĩ�
                    gudtStockMonth(gintMonthIndex).sngForeignStock = .sngForeignStock           ' �~��w�s
                    gudtStockMonth(gintMonthIndex).sngSitAndCbStock = .sngSitAndCbStock         ' ��H�w�s
                    gudtStockMonth(gintMonthIndex).sngSelfEmployedStock = .sngSelfEmployedStock ' ����Ӯw�s
                    gudtStockMonth(gintMonthIndex).sngLegalPersonStock = .sngLegalPersonStock   ' �k�H�w�s
                Else
                    If gudtStockMonth(gintMonthIndex).sngHighPrice < .sngHighPrice Then
                        gudtStockMonth(gintMonthIndex).sngHighPrice = .sngHighPrice
                    End If
                    If gudtStockMonth(gintMonthIndex).sngLowPrice > .sngLowPrice Then
                        gudtStockMonth(gintMonthIndex).sngLowPrice = .sngLowPrice
                    End If
                    gudtStockMonth(gintMonthIndex).sngEndprice = .sngEndprice
                    gudtStockMonth(gintMonthIndex).sngVol = gudtStockMonth(gintMonthIndex).sngVol + .sngVol
                    gudtStockMonth(gintMonthIndex).sngAcc = gudtStockMonth(gintMonthIndex).sngAcc + .sngAcc      ' �ĸ�
                    gudtStockMonth(gintMonthIndex).sngTome = gudtStockMonth(gintMonthIndex).sngTome + .sngTome   ' �Ĩ�
                    gudtStockMonth(gintMonthIndex).sngTome = gudtStockMonth(gintMonthIndex).sngForeignStock + .sngForeignStock              ' �~��w�s
                    gudtStockMonth(gintMonthIndex).sngTome = gudtStockMonth(gintMonthIndex).sngSelfEmployedStock + .sngSelfEmployedStock    ' ��H�w�s
                    gudtStockMonth(gintMonthIndex).sngTome = gudtStockMonth(gintMonthIndex).sngSelfEmployedStock + .sngSelfEmployedStock    ' ����Ӯw�s
                    gudtStockMonth(gintMonthIndex).sngTome = gudtStockMonth(gintMonthIndex).sngLegalPersonStock + .sngLegalPersonStock      ' �k�H�w�s
                End If
            End If
        End With
        i = i + 1
    Wend
    
    Exit Sub
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.subGenerateMonth()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Sub


'***************************************************************************************************
'* ��    ��: �b��ܵe�����k����ܤ@�ǧ޳N���Ъ���
'* ��J�Ѽ�: gudtStock     �ѻ����
'*           gudtIndex     �޳N���и��
'*           intTotalIndex ����`����
'*           sngIndex      �ثe�e���Ҧb��m(��??��)
'* ��X�Ѽ�: �L
'* ��    ��: 2.00 20080910 �s�W
'*           2.01 20081209 �վ�榡�μW�[����
'***************************************************************************************************
Public Sub DrawStockIndexes(ByRef gudtStock() As StockData, _
                            ByRef gudtIndex() As IndexData, _
                            ByVal intTotalIndex As Integer, _
                            ByVal sngIndex As Single)
    Dim strUpDown As String
    Dim sngTemp As Single   ' �O���n��ܪ����Ф�r�����I�y��
    Dim flag_str As String
    Dim sngCount As Integer
    Dim i As Integer
 
    On Error GoTo ERR_HANDLE
    
    If sngIndex <= intTotalIndex And sngIndex >= 1 Then
        With gudtStock(sngIndex)
            If sngIndex > 1 Then
                If (.sngEndprice - gudtStock(sngIndex - 1).sngEndprice) > 0 Then
                    strUpDown = " ��"
                    frmEarvinStocks.lblStockSts.ForeColor = QBColor(12)
                ElseIf (.sngEndprice - gudtStock(sngIndex - 1).sngEndprice) < 0 Then
                    strUpDown = " ��"
                    frmEarvinStocks.lblStockSts.ForeColor = QBColor(10)
                Else
                    strUpDown = ""
                End If
            ' 20090108 GRG_PS_Add����@
'''            If GRG_PS_Add(sngIndex) <> 0 Then
'''               strUpDown = strUpDown & Str(Format((.sngEndprice - gudtStock(sngIndex - 1).sngEndprice), "#.00")) & "  GRG_Pre=" & GRG_PS_Add(sngIndex)
'''            Else
'''               strUpDown = strUpDown & Str(Format((.sngEndprice - gudtStock(sngIndex - 1).sngEndprice), "#.00"))
'''            End If
                strUpDown = strUpDown & Str(Format((.sngEndprice - gudtStock(sngIndex - 1).sngEndprice), "#.00"))
            End If
            Focus_Today = sngIndex
            frmEarvinStocks.lblStockInf.ForeColor = QBColor(11)
            frmEarvinStocks.lblStockInf.Caption = Str(.sngDate) & " �}" & Str(.sngStartprice) & " ��" & Str(.sngHighPrice) & _
                " �C" & Str(.sngLowPrice) & " ��" & Str(.sngEndprice) & "   �q" & Str(.sngVol) & "��"
            If sngIndex <> 1 Then
                frmEarvinStocks.lblStockSts.Caption = strUpDown & "  " & Round((.sngEndprice - gudtStock(sngIndex - 1).sngEndprice) / gudtStock(sngIndex - 1).sngEndprice * 100, 2) & "%"
            Else
                frmEarvinStocks.lblStockSts.Caption = strUpDown
            End If
        End With
 
        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand + 20
        frmEarvinStocks.Line (frmEarvinStocks.ScaleWidth - gsngRightLevel, sngTemp)-(frmEarvinStocks.ScaleWidth - 0.01 * gsngRightLevel, sngTemp), RGB(200, 100, 0)
        sngTemp = sngTemp - 20
 
        With frmEarvinStocks.lblDateType
            .Top = sngTemp
            .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
            .Width = gsngRightLevel * 0.96
            .Caption = frmEarvinStocks.cboStocksType.Text
            sngTemp = sngTemp - .Height
        End With
 
        frmEarvinStocks.Line (frmEarvinStocks.ScaleWidth - gsngRightLevel, sngTemp)-(frmEarvinStocks.ScaleWidth - 0.01 * gsngRightLevel, sngTemp), RGB(200, 100, 0)
        sngTemp = sngTemp - 20
 
        ' ���e��l
        frmEarvinStocks.DrawStyle = vbSolid
        With frmEarvinStocks
            frmEarvinStocks.Line (.ScaleWidth - gsngRightLevel, 0.98 * gsngBottomFrame)-(.ScaleWidth - 0.01 * gsngRightLevel, 0.98 * gsngBottomFrame), RGB(200, 100, 0)
            gsngYshift = gsngBottomFrame
            For sngCount = gbytFrameNum To 2 Step -1
                gsngYshift = gsngYshift + mudtFrame(sngCount).sngHeight
                frmEarvinStocks.Line (.ScaleWidth - gsngRightLevel, gsngYshift)-(.ScaleWidth - 0.01 * gsngRightLevel, gsngYshift), RGB(200, 100, 0)
            Next
        End With
 
        frmEarvinStocks.lblMAP0.Visible = False
        frmEarvinStocks.lblMAP1.Visible = False
        frmEarvinStocks.lblMAP2.Visible = False
        frmEarvinStocks.lblMAP3.Visible = False
        frmEarvinStocks.lblMAP4.Visible = False
        frmEarvinStocks.lblMAP5.Visible = False
 
        frmEarvinStocks.lbl12RSI.Visible = False
        frmEarvinStocks.lbl6RSI.Visible = False
        frmEarvinStocks.lblStochRSI.Visible = False
        frmEarvinStocks.lblAcc.Visible = False
        frmEarvinStocks.lblBias.Visible = False
        frmEarvinStocks.lblQuantity.Visible = False
        frmEarvinStocks.lblD.Visible = False
        frmEarvinStocks.lblK.Visible = False
        frmEarvinStocks.lblMACD.Visible = False
        frmEarvinStocks.lblDIF.Visible = False
        frmEarvinStocks.lblCy.Visible = False
        frmEarvinStocks.lblPSY.Visible = False
        frmEarvinStocks.lblSignAcc.Visible = False
        frmEarvinStocks.lblSignTome.Visible = False
        frmEarvinStocks.lblTome.Visible = False
        frmEarvinStocks.lblWMS.Visible = False
        frmEarvinStocks.lblRWMS.Visible = False
        frmEarvinStocks.lbl6WRSI.Visible = False
        frmEarvinStocks.lbl65MAWRSI.Visible = False

        '==== 2004/3/9 DFTS ====
        frmEarvinStocks.lblTrend.Visible = False
        frmEarvinStocks.lblQM.Visible = False
        frmEarvinStocks.lblDiff1.Visible = False
        frmEarvinStocks.lblDiff2.Visible = False
        frmEarvinStocks.lblDC.Visible = False
        frmEarvinStocks.lblWLST.Visible = False
        frmEarvinStocks.lblWCY.Visible = False
        frmEarvinStocks.lblWLW.Visible = False
        
        ' 20180825
        frmEarvinStocks.lblForeignStock.Visible = False
        frmEarvinStocks.lblLegalPersonStock.Visible = False
        frmEarvinStocks.lblSelfEmployedStock.Visible = False
        frmEarvinStocks.lblSignSitAndCbStock.Visible = False
        frmEarvinStocks.lblSignForeignStock.Visible = False
        frmEarvinStocks.lblSignLegalPersonStock.Visible = False
        frmEarvinStocks.lblSignSelfEmployedStock.Visible = False
        frmEarvinStocks.lblSignSitAndCbStock.Visible = False
        

        '***********�M�w���MAP��Tether_Line��Reverse Engineering RSI     2003/5/26****************
        If frmEarvinStocks.mnuKmap.HelpContextID = 0 Then
            ' ���ʥ����u�򲾰ʥ����q���Ȥ@�������
            With frmEarvinStocks.lblMAP0
                .FontSize = 10
                .ForeColor = QBColor(5)
                .Top = sngTemp
                .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                .Width = gsngRightLevel * 0.96
                .Visible = True
                If sngIndex <> 1 Then
                    If gudtIndex(sngIndex).sngMAP0 > gudtIndex(sngIndex - 1).sngMAP0 Then
                        flag_str = "��"
                    ElseIf gudtIndex(sngIndex).sngMAP0 < gudtIndex(sngIndex - 1).sngMAP0 Then
                        flag_str = "��"
                    Else
                        flag_str = "�V"
                    End If
                End If
              
                If MAP_0 <> 0 Then
                    .Caption = MAP_0 & "MAP=" & Str(Round(gudtIndex(sngIndex).sngMAP0, 2)) & flag_str
                Else
                    .Caption = ""
                End If
                sngTemp = sngTemp - .Height
            End With

            With frmEarvinStocks.lblMAP1
                .FontSize = 10
                .ForeColor = QBColor(3)
                .Top = sngTemp
                .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                .Width = gsngRightLevel * 0.96
                .Visible = True
                If sngIndex <> 1 Then
                    If gudtIndex(sngIndex).sngMAP1 > gudtIndex(sngIndex - 1).sngMAP1 Then
                        flag_str = "��"
                    ElseIf gudtIndex(sngIndex).sngMAP1 < gudtIndex(sngIndex - 1).sngMAP1 Then
                        flag_str = "��"
                    Else
                        flag_str = "�V"
                    End If
                End If
              
                If MAP_1 <> 0 Then
                    .Caption = MAP_1 & "MAP=" & Str(Round(gudtIndex(sngIndex).sngMAP1, 2)) & flag_str
                Else
                    .Caption = ""
                End If
                sngTemp = sngTemp - .Height
            End With

            With frmEarvinStocks.lblMAP2
                .FontSize = 10
                .ForeColor = QBColor(9)
                .Top = sngTemp
                .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                .Width = gsngRightLevel * 0.96
                .Visible = True
                If sngIndex <> 1 Then
                    If gudtIndex(sngIndex).sngMAP2 > gudtIndex(sngIndex - 1).sngMAP2 Then
                        flag_str = "��"
                    ElseIf gudtIndex(sngIndex).sngMAP2 < gudtIndex(sngIndex - 1).sngMAP2 Then
                        flag_str = "��"
                    Else
                        flag_str = "�V"
                    End If
                End If
                If MAP_2 <> 0 Then
                    .Caption = MAP_2 & "MAP=" & Str(Round(gudtIndex(sngIndex).sngMAP2, 2)) & flag_str
                Else
                    .Caption = ""
                End If
                sngTemp = sngTemp - .Height
            End With

            With frmEarvinStocks.lblMAP3
                .FontSize = 10
                .ForeColor = QBColor(13)
                .Top = sngTemp
                .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                .Width = gsngRightLevel * 0.96
                .Visible = True
                If sngIndex <> 1 Then
                    If gudtIndex(sngIndex).sngMAP3 > gudtIndex(sngIndex - 1).sngMAP3 Then
                        flag_str = "��"
                    ElseIf gudtIndex(sngIndex).sngMAP3 < gudtIndex(sngIndex - 1).sngMAP3 Then
                        flag_str = "��"
                    Else
                        flag_str = "�V"
                    End If
                End If
            
                If MAP_3 <> 0 Then
                    .Caption = MAP_3 & "MAP=" & Str(Round(gudtIndex(sngIndex).sngMAP3, 2)) & flag_str
                Else
                    .Caption = ""
                End If
                sngTemp = sngTemp - .Height
            End With

            With frmEarvinStocks.lblMAP4
                .FontSize = 10
                .ForeColor = QBColor(11)
                .Top = sngTemp
                .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                .Width = gsngRightLevel * 0.96
                .Visible = True
                If sngIndex <> 1 Then
                    If gudtIndex(sngIndex).sngMAP4 > gudtIndex(sngIndex - 1).sngMAP4 Then
                        flag_str = "��"
                    ElseIf gudtIndex(sngIndex).sngMAP4 < gudtIndex(sngIndex - 1).sngMAP4 Then
                        flag_str = "��"
                    Else
                        flag_str = "�V"
                    End If
                End If
            
                If MAP_4 <> 0 Then
                    .Caption = MAP_4 & "MAP=" & Str(Round(gudtIndex(sngIndex).sngMAP4, 2)) & flag_str
                Else
                    .Caption = ""
                End If
                sngTemp = sngTemp - .Height
            End With

            With frmEarvinStocks.lblMAP5
                .FontSize = 10
                .ForeColor = QBColor(7)
                .Top = sngTemp
                .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                .Width = gsngRightLevel * 0.96
                .Visible = True
                If sngIndex <> 1 Then
                    If gudtIndex(sngIndex).sngMAP5 > gudtIndex(sngIndex - 1).sngMAP5 Then
                        flag_str = "��"
                    ElseIf gudtIndex(sngIndex).sngMAP5 < gudtIndex(sngIndex - 1).sngMAP5 Then
                        flag_str = "��"
                    Else
                        flag_str = "�V"
                    End If
                End If
            
                If MAP_5 <> 0 Then
                    .Caption = MAP_5 & "MAP=" & Str(Round(gudtIndex(sngIndex).sngMAP5, 2)) & flag_str
                Else
                    .Caption = ""
                End If
                sngTemp = sngTemp - .Height
            End With
        End If
     
        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand + 20 - (frmEarvinStocks.lblDateType.Height + mudtFrame(1).sngHeight) / 2
        frmEarvinStocks.Line (frmEarvinStocks.ScaleWidth - gsngRightLevel, sngTemp)-(frmEarvinStocks.ScaleWidth - 0.01 * gsngRightLevel, sngTemp), RGB(200, 100, 0)
        sngTemp = sngTemp - 20
     
        '*** ��ܡu����q�v******************************************************************************
        With frmEarvinStocks.lblMAV1
            .FontSize = 9
            .ForeColor = QBColor(14)
            .Top = sngTemp
            .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
            .Width = gsngRightLevel * 0.96
            .Visible = True
            If sngIndex <> 1 Then
                If gudtIndex(sngIndex).sngMAV1 > gudtIndex(sngIndex - 1).sngMAV1 Then
                    flag_str = "��"
                ElseIf gudtIndex(sngIndex).sngMAV1 < gudtIndex(sngIndex - 1).sngMAV1 Then
                    flag_str = "��"
                Else
                    flag_str = "�V"
                End If
            End If
        
            If MAV_1 <> 0 Then
                .Caption = MAV_1 & "MAV=" & Str(Round(gudtIndex(sngIndex).sngMAV1, 2)) & flag_str
            Else
                .Caption = ""
            End If
            sngTemp = sngTemp - .Height
        End With
    
        With frmEarvinStocks.lblMAV2
            .FontSize = 9
            .ForeColor = QBColor(9)
            .Top = sngTemp
            .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
            .Width = gsngRightLevel * 0.96
            .Visible = True
            If sngIndex <> 1 Then
                If gudtIndex(sngIndex).sngMAV2 > gudtIndex(sngIndex - 1).sngMAV2 Then
                    flag_str = "��"
                ElseIf gudtIndex(sngIndex).sngMAV2 < gudtIndex(sngIndex - 1).sngMAV2 Then
                    flag_str = "��"
                Else
                    flag_str = "�V"
                End If
            End If
        
            If MAV_2 <> 0 Then
                .Caption = MAV_2 & "MAV=" & Str(Round(gudtIndex(sngIndex).sngMAV2, 2)) & flag_str
            Else
                .Caption = ""
            End If
            sngTemp = sngTemp - .Height
        End With

        With frmEarvinStocks.lblMAV3
            .FontSize = 9
            .ForeColor = QBColor(13)
            .Top = sngTemp
            .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
            .Width = gsngRightLevel * 0.96
            .Visible = True
            If sngIndex <> 1 Then
                If gudtIndex(sngIndex).sngMAV3 > gudtIndex(sngIndex - 1).sngMAV3 Then
                    flag_str = "��"
                ElseIf gudtIndex(sngIndex).sngMAV3 < gudtIndex(sngIndex - 1).sngMAV3 Then
                    flag_str = "��"
                Else
                    flag_str = "�V"
                End If
            End If
        
            If MAV_3 <> 0 Then
                .Caption = MAV_3 & "MAV=" & Str(Round(gudtIndex(sngIndex).sngMAV3, 2)) & flag_str
            Else
                .Caption = ""
            End If
            sngTemp = sngTemp - .Height
        End With

        With frmEarvinStocks.lblMAV4
            .FontSize = 9
            .ForeColor = QBColor(11)
            .Top = sngTemp
            .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
            .Width = gsngRightLevel * 0.96
            .Visible = True
          
            If sngIndex <> 1 Then
                If gudtIndex(sngIndex).sngMAV4 > gudtIndex(sngIndex - 1).sngMAV4 Then
                    flag_str = "��"
                ElseIf gudtIndex(sngIndex).sngMAV4 < gudtIndex(sngIndex - 1).sngMAV4 Then
                    flag_str = "��"
                Else
                    flag_str = "�V"
                End If
            End If
        
            If MAV_4 <> 0 Then
                .Caption = MAV_4 & "MAV=" & Str(Round(gudtIndex(sngIndex).sngMAV4, 2)) & flag_str
            Else
                .Caption = ""
            End If
            sngTemp = sngTemp - .Height
        End With

        With frmEarvinStocks.lblMAV5
            .FontSize = 9
            .ForeColor = QBColor(7)
            .Top = sngTemp
            .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
            .Width = gsngRightLevel * 0.96
            .Visible = True
          
            If sngIndex <> 1 Then
                If gudtIndex(sngIndex).sngMAV5 > gudtIndex(sngIndex - 1).sngMAV5 Then
                    flag_str = "��"
                ElseIf gudtIndex(sngIndex).sngMAV5 < gudtIndex(sngIndex - 1).sngMAV5 Then
                    flag_str = "��"
                Else
                    flag_str = "�V"
                End If
            End If
        
            If MAV_5 <> 0 Then
                .Caption = MAV_5 & "MAV=" & Str(Round(gudtIndex(sngIndex).sngMAV5, 2)) & flag_str
            Else
                .Caption = ""
            End If
            sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand - mudtFrame(1).sngHeight
        End With

        ' ��l�w�g���e�n�F�A�ҥH�U���o��h��
'       frmEarvinStocks.Line (frmEarvinStocks.ScaleWidth - gsngRightlevel, sngTemp)-(frmEarvinStocks.ScaleWidth - 0.01 * gsngRightlevel, sngTemp), RGB(200, 100, 0)
        sngTemp = sngTemp - 20

        ' ����XX���Ф~���XX���Э�
        For sngCount = 1 To gbytFrameNum
            Select Case mudtFrame(sngCount).bytAttribute
'               Case mKmap
 
                Case mQuantityMap
                    sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                    For i = 1 To sngCount
                        sngTemp = sngTemp - mudtFrame(i).sngHeight
                    Next
                    sngTemp = sngTemp - 20
            
                Case mKDmap
                    With frmEarvinStocks.lblK
                        .FontSize = 10
                        .ForeColor = QBColor(12)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngK > gudtIndex(sngIndex - 1).sngK Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngK < gudtIndex(sngIndex - 1).sngK Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = KD_No & "K=" & Str(Round(gudtIndex(sngIndex).sngK, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblD
                        .FontSize = 10
                        .ForeColor = QBColor(9)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngD > gudtIndex(sngIndex - 1).sngD Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngD < gudtIndex(sngIndex - 1).sngD Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = KD_No & "D=" & Str(Round(gudtIndex(sngIndex).sngD, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
            
                Case mRSImap
                    With frmEarvinStocks.lbl6RSI
                        .FontSize = 10
                        .ForeColor = QBColor(7)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngRSI_S > gudtIndex(sngIndex - 1).sngRSI_S Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngRSI_S < gudtIndex(sngIndex - 1).sngRSI_S Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = RSI_S & "RSI=" & Str(Round(gudtIndex(sngIndex).sngRSI_S, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lbl12RSI
                        .FontSize = 10
                        .ForeColor = QBColor(9)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngRSI_L > gudtIndex(sngIndex - 1).sngRSI_L Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngRSI_L < gudtIndex(sngIndex - 1).sngRSI_L Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = RSI_L & "RSI=" & Str(Round(gudtIndex(sngIndex).sngRSI_L, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
            
                Case mStochRSImap
                    With frmEarvinStocks.lblStochRSI
                        .FontSize = 10
                        .ForeColor = QBColor(7)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngStochRSI > gudtIndex(sngIndex - 1).sngStochRSI Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngStochRSI < gudtIndex(sngIndex - 1).sngStochRSI Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = StochRSI_No & "StochRSI=" & Str(Round(gudtIndex(sngIndex).sngStochRSI, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
            
                Case mMACDmap
                    With frmEarvinStocks.lblMACD
                        .FontSize = 10
                        .ForeColor = QBColor(12)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngMACD > gudtIndex(sngIndex - 1).sngMACD Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngMACD < gudtIndex(sngIndex - 1).sngMACD Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = MACD_No & "MACD=" & Str(Round(gudtIndex(sngIndex).sngMACD, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblDIF
                        .FontSize = 10
                        .ForeColor = QBColor(10)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngDIF > gudtIndex(sngIndex - 1).sngDIF Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngDIF < gudtIndex(sngIndex - 1).sngDIF Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "DIF=" & Str(Round(gudtIndex(sngIndex).sngDIF, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblCy
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngDIF_MACD > gudtIndex(sngIndex - 1).sngDIF_MACD Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngDIF_MACD < gudtIndex(sngIndex - 1).sngDIF_MACD Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        If gudtIndex(sngIndex).sngDIF_MACD >= 0 Then
                            .ForeColor = QBColor(12)
                        Else
                            .ForeColor = QBColor(10)
                        End If
                        .Caption = "Cy=" & Str(Round(gudtIndex(sngIndex).sngDIF_MACD, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
        
                Case mWMSmap
                    With frmEarvinStocks.lblWMS
                        .FontSize = 10
                        .ForeColor = QBColor(11)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngWMS > gudtIndex(sngIndex - 1).sngWMS Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngWMS < gudtIndex(sngIndex - 1).sngWMS Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = WMS_No & "WMS=" & Str(Round(gudtIndex(sngIndex).sngWMS, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
               
                Case mRWMSmap
                    With frmEarvinStocks.lblRWMS
                        .FontSize = 10
                        .ForeColor = QBColor(11)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngRWMS > gudtIndex(sngIndex - 1).sngRWMS Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngRWMS < gudtIndex(sngIndex - 1).sngRWMS Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = RWMS_No & "WMSC=" & Str(Round(gudtIndex(sngIndex).sngRWMS, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
            
                Case mWRSImap
                    With frmEarvinStocks.lbl6WRSI
                        .FontSize = 10
                        .ForeColor = QBColor(7)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngWRSI > gudtIndex(sngIndex - 1).sngWRSI Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngWRSI < gudtIndex(sngIndex - 1).sngWRSI Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = WRSI & "wrsi=" & Str(Round(gudtIndex(sngIndex).sngWRSI, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lbl65MAWRSI
                        .FontSize = 10
                        .ForeColor = QBColor(11)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngMAWRSI > gudtIndex(sngIndex - 1).sngMAWRSI Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngMAWRSI < gudtIndex(sngIndex - 1).sngMAWRSI Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = MAWRSI & "wrsi=" & Str(Round(gudtIndex(sngIndex).sngMAWRSI, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
         
                Case mPSYmap
                    With frmEarvinStocks.lblPSY
                        .FontSize = 10
                        .ForeColor = QBColor(12)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngPSY > gudtIndex(sngIndex - 1).sngPSY Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngPSY < gudtIndex(sngIndex - 1).sngPSY Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = PSY_No & "PSY=" & Str(Round(gudtIndex(sngIndex).sngPSY, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
      
                Case mEMAmap
                    With frmEarvinStocks.lblEMA
                        .FontSize = 10
                        .ForeColor = QBColor(12)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngEMA > gudtIndex(sngIndex - 1).sngEMA Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngEMA < gudtIndex(sngIndex - 1).sngEMA Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = EMA_NO & "EMA=" & Str(Round(gudtIndex(sngIndex).sngEMA, 2)) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
      
                Case mBiasmap
                    With frmEarvinStocks.lblBias
                        .FontSize = 10
                        .ForeColor = QBColor(14)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngBias > gudtIndex(sngIndex - 1).sngBias Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngBias < gudtIndex(sngIndex - 1).sngBias Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = Bias_No & "Bias=" & Str(Round(gudtIndex(sngIndex).sngBias, 2)) & "%" & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
          
                Case mQuantityMap
                    With frmEarvinStocks.lblQuantity
                        .FontSize = 10
                        .ForeColor = QBColor(14)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngVol > gudtStock(sngIndex - 1).sngVol Then
                                flag_str = "��"
                            ElseIf gudtStock(sngIndex).sngVol < gudtStock(sngIndex - 1).sngVol Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "Vol=" & Str(Round(gudtStock(sngIndex).sngVol, 2)) & "%" & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
       
                Case mAccMap
                    With frmEarvinStocks.lblAcc
                        .FontSize = 10
                        .ForeColor = QBColor(12)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngAcc > gudtStock(sngIndex - 1).sngAcc Then
                                flag_str = "��"
                            ElseIf gudtStock(sngIndex).sngAcc < gudtStock(sngIndex - 1).sngAcc Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "�ĸ�=" & Str(Round(gudtStock(sngIndex).sngAcc, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                        With frmEarvinStocks.lblSignAcc
                            .FontSize = 10
                            .Top = sngTemp
                            .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                            .Width = gsngRightLevel * 0.96
                            .Visible = True
                            If sngIndex <> 1 Then
                                If gudtStock(sngIndex).sngAcc >= gudtStock(sngIndex - 1).sngAcc Then
                                    .ForeColor = QBColor(12)
                                    flag_str = "+"
                                ElseIf gudtStock(sngIndex).sngAcc < gudtStock(sngIndex - 1).sngAcc Then
                                    .ForeColor = QBColor(10)
                                    flag_str = ""
                                End If
                                .Caption = flag_str & Round(CSng(gudtStock(sngIndex).sngAcc) - CSng(gudtStock(sngIndex - 1).sngAcc), 2)
                            Else
                                .Caption = ""
                            End If
                            sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                            For i = 1 To sngCount
                                sngTemp = sngTemp - mudtFrame(i).sngHeight
                            Next
                            sngTemp = sngTemp - 20
                        End With
                    End With
        
                Case mTomeMap
                    With frmEarvinStocks.lblTome
                        .FontSize = 10
                        .ForeColor = QBColor(10)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngTome > gudtStock(sngIndex - 1).sngTome Then
                                flag_str = "��"
                            ElseIf gudtStock(sngIndex).sngTome < gudtStock(sngIndex - 1).sngTome Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "�Ĩ�=" & Str(Round(gudtStock(sngIndex).sngTome, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblSignTome
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngTome >= gudtStock(sngIndex - 1).sngTome Then
                                .ForeColor = QBColor(12)
                                flag_str = "+"
                            ElseIf gudtStock(sngIndex).sngTome < gudtStock(sngIndex - 1).sngTome Then
                                .ForeColor = QBColor(10)
                                flag_str = ""
                            End If
                            .Caption = flag_str & Round(CSng(gudtStock(sngIndex).sngTome) - CSng(gudtStock(sngIndex - 1).sngTome), 2)
                        Else
                            .Caption = ""
                        End If
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
                       
                '****** 20180825 START ***********************************
                Case mForeignStockMap
                    With frmEarvinStocks.lblForeignStock
                        .FontSize = 10
                        .ForeColor = QBColor(10)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngForeignStock > gudtStock(sngIndex - 1).sngForeignStock Then
                                flag_str = "��"
                            ElseIf gudtStock(sngIndex).sngForeignStock < gudtStock(sngIndex - 1).sngForeignStock Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "�~��=" & Str(Round(gudtStock(sngIndex).sngForeignStock, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblSignForeignStock
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngForeignStock >= gudtStock(sngIndex - 1).sngForeignStock Then
                                .ForeColor = QBColor(12)
                                flag_str = "+"
                            ElseIf gudtStock(sngIndex).sngForeignStock < gudtStock(sngIndex - 1).sngForeignStock Then
                                .ForeColor = QBColor(10)
                                flag_str = ""
                            End If
                            .Caption = flag_str & Round(CSng(gudtStock(sngIndex).sngForeignStock) - CSng(gudtStock(sngIndex - 1).sngForeignStock), 2)
                        Else
                            .Caption = ""
                        End If
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
                       
                Case mSitAndCbStockMap
                    With frmEarvinStocks.lblSitAndCbStock
                        .FontSize = 10
                        .ForeColor = QBColor(10)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngSitAndCbStock > gudtStock(sngIndex - 1).sngSitAndCbStock Then
                                flag_str = "��"
                            ElseIf gudtStock(sngIndex).sngSitAndCbStock < gudtStock(sngIndex - 1).sngSitAndCbStock Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "��H=" & Str(Round(gudtStock(sngIndex).sngSitAndCbStock, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblSignSitAndCbStock
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngSitAndCbStock >= gudtStock(sngIndex - 1).sngSitAndCbStock Then
                                .ForeColor = QBColor(12)
                                flag_str = "+"
                            ElseIf gudtStock(sngIndex).sngSitAndCbStock < gudtStock(sngIndex - 1).sngSitAndCbStock Then
                                .ForeColor = QBColor(10)
                                flag_str = ""
                            End If
                            .Caption = flag_str & Round(CSng(gudtStock(sngIndex).sngSitAndCbStock) - CSng(gudtStock(sngIndex - 1).sngSitAndCbStock), 2)
                        Else
                            .Caption = ""
                        End If
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
                       
                Case mSelfEmployedStockMap
                    With frmEarvinStocks.lblSelfEmployedStock
                        .FontSize = 10
                        .ForeColor = QBColor(10)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngSelfEmployedStock > gudtStock(sngIndex - 1).sngSelfEmployedStock Then
                                flag_str = "��"
                            ElseIf gudtStock(sngIndex).sngSelfEmployedStock < gudtStock(sngIndex - 1).sngSelfEmployedStock Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "�����=" & Str(Round(gudtStock(sngIndex).sngSelfEmployedStock, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblSignSelfEmployedStock
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngSelfEmployedStock >= gudtStock(sngIndex - 1).sngSelfEmployedStock Then
                                .ForeColor = QBColor(12)
                                flag_str = "+"
                            ElseIf gudtStock(sngIndex).sngSelfEmployedStock < gudtStock(sngIndex - 1).sngSelfEmployedStock Then
                                .ForeColor = QBColor(10)
                                flag_str = ""
                            End If
                            .Caption = flag_str & Round(CSng(gudtStock(sngIndex).sngSelfEmployedStock) - CSng(gudtStock(sngIndex - 1).sngSelfEmployedStock), 2)
                        Else
                            .Caption = ""
                        End If
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
                       
                Case mLegalPersonStockMap
                    With frmEarvinStocks.lblLegalPersonStock
                        .FontSize = 10
                        .ForeColor = QBColor(10)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngLegalPersonStock > gudtStock(sngIndex - 1).sngLegalPersonStock Then
                                flag_str = "��"
                            ElseIf gudtStock(sngIndex).sngLegalPersonStock < gudtStock(sngIndex - 1).sngLegalPersonStock Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "�k�H=" & Str(Round(gudtStock(sngIndex).sngLegalPersonStock, 2)) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblSignLegalPersonStock
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtStock(sngIndex).sngLegalPersonStock >= gudtStock(sngIndex - 1).sngLegalPersonStock Then
                                .ForeColor = QBColor(12)
                                flag_str = "+"
                            ElseIf gudtStock(sngIndex).sngLegalPersonStock < gudtStock(sngIndex - 1).sngLegalPersonStock Then
                                .ForeColor = QBColor(10)
                                flag_str = ""
                            End If
                            .Caption = flag_str & Round(CSng(gudtStock(sngIndex).sngLegalPersonStock) - CSng(gudtStock(sngIndex - 1).sngLegalPersonStock), 2)
                        Else
                            .Caption = ""
                        End If
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
                    
                '****** 20180825 END   ***********************************
                             
                Case m_Trendmap                     '' 2004/3/9
                    With frmEarvinStocks.lblTrend
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        If (gudtIndex(sngIndex).sngTrend > 0) Then
                            .ForeColor = RGB(255, 50, 100)
                        Else
                            .ForeColor = RGB(50, 200, 100)
                        End If
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngTrend > gudtIndex(sngIndex - 1).sngTrend Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngTrend < gudtIndex(sngIndex - 1).sngTrend Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "Trend = " & gudtIndex(sngIndex).sngTrend & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With

                Case m_QMmap
                    With frmEarvinStocks.lblQM
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .ForeColor = RGB(255, 100, 0)
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngQM > gudtIndex(sngIndex - 1).sngQM Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngQM < gudtIndex(sngIndex - 1).sngQM Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "QM = " & gudtIndex(sngIndex).sngQM & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
            
                Case m_Diffmap
                    With frmEarvinStocks.lblDiff1      '------- Diff1 -------
                        .FontSize = 10
                        .ForeColor = QBColor(12)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngDIFF1 > gudtIndex(sngIndex - 1).sngDIFF1 Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngDIFF1 < gudtIndex(sngIndex - 1).sngDIFF1 Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "Diff1=" & Str(gudtIndex(sngIndex).sngDIFF1) & flag_str
                        sngTemp = sngTemp - .Height
                    End With
                    With frmEarvinStocks.lblDiff2
                        .FontSize = 10
                        .ForeColor = QBColor(9)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngDIFF2 > gudtIndex(sngIndex - 1).sngDIFF2 Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngDIFF2 < gudtIndex(sngIndex - 1).sngDIFF2 Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "Diff2=" & Str(gudtIndex(sngIndex).sngDIFF2) & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With

                Case m_DCmap
                    With frmEarvinStocks.lblDC
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .ForeColor = RGB(255, 50, 100)
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngDC > gudtIndex(sngIndex - 1).sngDC Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngDC < gudtIndex(sngIndex - 1).sngDC Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "DC = " & gudtIndex(sngIndex).sngDC & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With

                Case m_WLSTmap
                    With frmEarvinStocks.lblWLST      '------- Diff1 -------
                        .FontSize = 10
                        .ForeColor = QBColor(13)
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngWLST > gudtIndex(sngIndex - 1).sngWLST Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngWLST < gudtIndex(sngIndex - 1).sngWLST Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "WLST=" & Str(gudtIndex(sngIndex).sngWLST) & flag_str
                        sngTemp = sngTemp - .Height
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
        
                Case m_WCYmap
                    With frmEarvinStocks.lblWCY
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        If (gudtIndex(sngIndex).sngWCY > 0) Then
                            .ForeColor = RGB(255, 50, 100)
                        Else
                            .ForeColor = RGB(50, 200, 100)
                        End If
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngWCY > gudtIndex(sngIndex - 1).sngWCY Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngWCY < gudtIndex(sngIndex - 1).sngWCY Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "WCY = " & gudtIndex(sngIndex).sngWCY & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With

                Case m_WLWmap
                    With frmEarvinStocks.lblWLW
                        .FontSize = 10
                        .Top = sngTemp
                        .Left = frmEarvinStocks.ScaleWidth - 0.98 * gsngRightLevel
                        .Width = gsngRightLevel * 0.96
                        If (gudtIndex(sngIndex).sngWLW > 0) Then
                            .ForeColor = RGB(255, 0, 0)
                        Else
                            .ForeColor = RGB(0, 255, 0)
                        End If
                        .Visible = True
                        If sngIndex <> 1 Then
                            If gudtIndex(sngIndex).sngWLW > gudtIndex(sngIndex - 1).sngWLW Then
                                flag_str = "��"
                            ElseIf gudtIndex(sngIndex).sngWLW < gudtIndex(sngIndex - 1).sngWLW Then
                                flag_str = "��"
                            Else
                                flag_str = "�V"
                            End If
                        End If
                        .Caption = "WLW = " & gudtIndex(sngIndex).sngWLW & flag_str
                        sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                        For i = 1 To sngCount
                            sngTemp = sngTemp - mudtFrame(i).sngHeight
                        Next
                        sngTemp = sngTemp - 20
                    End With
            
                Case Else
                    sngTemp = Abs(frmEarvinStocks.ScaleHeight) - gsngTopFrame - gsngTopCommand
                    For i = 1 To sngCount
                        sngTemp = sngTemp - mudtFrame(i).sngHeight
                    Next
                    sngTemp = sngTemp - 20
            End Select
        Next
        ' �̥k�䨺���u
        With frmEarvinStocks
            frmEarvinStocks.Line (Abs(.ScaleWidth) - 0.01 * gsngRightLevel, gsngBottomFrame)-(Abs(.ScaleWidth) - 0.01 * gsngRightLevel, Abs(.ScaleHeight) - gsngTopFrame - gsngTopCommand), RGB(200, 100, 0)
        End With
        sngTemp = sngTemp - 60
    End If
    
    Exit Sub
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.DrawStockIndexes()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Sub


'***************************************************************************************************
'* ��    ��: ���o�n��ܪ��Ѳ��M��
'* ��J�Ѽ�: stockType ���o�Ѳ��M�檺�覡 ( "file" or "directory" )
'* ��X�Ѽ�: �L
'* ��    ��: 2.00 20080910 �s�W
'*           2.01 20081223 �վ�榡�μW�[����
'***************************************************************************************************
Public Sub GetStockList(stockType As String)
    Dim i As Integer
    Dim path As String
   
    On Error GoTo ERR_HANDLE
    
    path = GetAppPath
    frmEarvinStocks.cboStocks.Clear
    frmEarvinStocks.cboStocks.AddItem "Taiex", 0
    If stockType = "file" Then
        '======================================
        '* �HŪ���ɮפ覡���o�n�B�z���Ӫ�     *
        '======================================
        ' Read StockNo file form "taiwan_stkno.bat" file
        Dim openFile As String
        Dim lineData As String
        Dim splitData As Variant
        ' ���|�g���A���n!!�n�A�վ�!!
'        openFile = "C:\myData\EarvinStockPGMs\myPGMs\DATA\config\�ާ@�Ӫ�.txt"
        path = GetAppPath
        openFile = path + "myPGMs\DATA\config\�ާ@�Ӫ�.txt"
        i = 1
        
        Open openFile For Input As #100
        While Not EOF(100)
            Line Input #100, lineData
'            splitData = Split(lineData, " ")
'            frmEarvinStocks.cboStocks.AddItem splitData(1), i
            frmEarvinStocks.cboStocks.AddItem lineData, i
            i = i + 1
        Wend
        Close #100
    ElseIf stockType = "directory" Then
        '=================================
        '* �H�ؿ��覡���o�n�B�z���Ӫ�    *
        '=================================
        ' ���o���w���|�U���ɮ�
        Dim thePath As String
'        thePath = "C:\myData\EarvinStockPGMs\myPGMs\DATA\dat\"
        thePath = GetAppPath + "myPGMs\DATA\dat\"
        Dim fileName As String
        Dim fileInfoList As Variant
        Dim stockName As String
        
        ' 20230309 �N���o�ɮצW�١A���g�Jlist��A�s�W��combo-list����(�����ɮ׶���)
'        fileName = Dir(thePath) ' ���o�ɮצW��(�@����^�@���ɮצW��)
'        Do While fileName <> ""
'            fileInfoList = Split(fileName, ".")
'            stockName = fileInfoList(0) + ", " + GetStockName(fileInfoList(0))
'            frmEarvinStocks.cboStocks.AddItem stockName, i
'            fileName = Dir() ' �A���ե�Dir���,���ɥi�H���a�Ѽ�
'        Loop
        Dim stockList(5000) As String   ' �x�s���o���ɮצW��(�̦h�i�x�s5000��)
        i = 1
        fileName = Dir(thePath)
        Do While fileName <> ""
            stockList(i) = fileName
            i = i + 1
            fileName = Dir() ' �A���ե�Dir���,���ɥi�H���a�Ѽ�
        Loop
        Dim j As Integer
        For j = 1 To UBound(stockList)
            If stockList(j) <> "" Then
                fileInfoList = Split(stockList(j), ".")
                stockName = fileInfoList(0) + ", " + GetStockName(fileInfoList(0))
                frmEarvinStocks.cboStocks.AddItem stockName
            Else
                j = UBound(stockList)
            End If
             Debug.Print (Str(j))
        Next
    End If
'   frmEarvinStocks.cboStocks.Text = "Taiex"
    frmEarvinStocks.cboStocks.Text = SHOW_DEFAULT_STOCK
    
    Exit Sub
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.GetStockList()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Sub


'***************************************************************************************************
'* ��    ��: �]�w�s��ӪѸ�ƪ����|(���o�{���s����|���W1�h(ex: D:\A\B --> D:\A\))
'* ��J�Ѽ�: �L
'* ��X�Ѽ�: �L
'* ��    ��: 2.00 20080910 �s�W
'*           2.01 20081223 �վ�榡�μW�[����
'***************************************************************************************************
Public Function GetAppPath() As String
    Dim blnFlag As Boolean
    Dim path As String
    Dim strChar As String
    Dim intUpDir As Integer
    Const upLevel = 2 ' ���W??�h
    Dim i As Integer
    
    blnFlag = False
    intUpDir = 0
    path = App.path
    
    On Error GoTo ERR_HANDLE
   
    For i = Len(path) To 1 Step -1
        strChar = Mid(path, i, 1)
        If strChar = "\" Then
            intUpDir = intUpDir + 1
        End If
        If intUpDir = upLevel Then ' ���W1�h
            path = Mid(path, 1, i)
            Exit For
        End If
    Next
    GetAppPath = path
    
    Exit Function
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.GetAppPath()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Function


Public Function GetStockName(ByVal stockCode As String)
    Dim stockName As String
    Dim path As String
    Dim openFile As String
    Dim lineData As String
    Dim splitData As Variant
    Dim i As Integer
   
    On Error GoTo ERR_HANDLE
    
    If stockCode = "Taiex" Then
        stockName = "�[�v����"
    Else
        ' ���|���g�k�n�A�վ�A�o���٬O�g��!! // �Ҽ{���Ƽg��table
        path = GetAppPath
        openFile = path + "myPGMs\DATA\config\�Ѳ��N���W�ٹ�Ӫ�.txt"
        i = 1
   
        Open openFile For Input As #100
        While Not EOF(100)
            Line Input #100, lineData
            splitData = Split(lineData, " ")
         
            If splitData(0) = stockCode Then
                stockName = splitData(1)
                GoTo END_WHILE
            End If
         
            i = i + 1
        Wend

END_WHILE:
      
        Close #100
   
    End If

    GetStockName = stockName
    
    Exit Function
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.GetStockName()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Function


'***************************************************************************************************************************
'* ��    ��:
'*    �̶ǤJ��MAP�ഫ���������ƭȰ�split�ʧ@      --** 20071214 OK **--
'* ��J�Ѽ�:
'*    indexName: �޳N���ЦW��
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20080916 Earvin   �s�W
'* ��    ��:
'*    1. sngSector = 1 ���ܬ����I�Ϭq�FsngSector = 0.5 ���ܬ��C�I�Ϭq
'***************************************************************************************************************************
Private Function getIndexDays(ByVal indexName As String) As Integer
    If indexName = "3MAP" Then
        getIndexDays = 3
    ElseIf indexName = "4MAP" Then
        getIndexDays = 4
    ElseIf indexName = "5MAP" Then
        getIndexDays = 5
    ElseIf indexName = "6MAP" Then
        getIndexDays = 6
    ElseIf indexName = "8MAP" Then
        getIndexDays = 8
    ElseIf indexName = "10MAP" Then
        getIndexDays = 10
    ElseIf indexName = "12MAP" Then
        getIndexDays = 12
    ElseIf indexName = "20MAP" Then
        getIndexDays = 20
    ElseIf indexName = "24MAP" Then
        getIndexDays = 24
    ElseIf indexName = "30MAP" Then
        getIndexDays = 30
    ElseIf indexName = "60MAP" Then
        getIndexDays = 60
    ElseIf indexName = "72MAP" Then
        getIndexDays = 72
    ElseIf indexName = "120MAP" Then
        getIndexDays = 120
    ElseIf indexName = "144MAP" Then
        getIndexDays = 144
    ElseIf indexName = "240MAP" Then
        getIndexDays = 240
    ElseIf indexName = "288MAP" Then
        getIndexDays = 288
    ElseIf indexName = "K" Then
        getIndexDays = 600
    ElseIf indexName = "D" Then
        getIndexDays = 601
    Else
'      getIndexDays = 288
        Err.Raise 100
    End If
End Function



'***************************************************************************************************************************
'* ��    ��:
'*    ���ΥX�C��Sector: use MAP      --** 20071214 OK **--
'* ��J�Ѽ�:
'*    udtStock() �C��ѻ����(��l���)
'*    udtIndex() �C��ѻ����(�޳N����)
'*    intStockNo �ѻ���Ƶ���
'*    indexName1 �ǤJK -- �_��
'*    indexName2 �ǤJD -- ����
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20080916 Earvin   �s�W
'* ��    ��:
'*    1. sngSector = 1 ���ܬ����I�Ϭq�FsngSector = 0.5 ���ܬ��C�I�Ϭq
'***************************************************************************************************************************
Public Sub setSectorByKD(ByRef udtStock() As StockData, _
                        ByRef udtIndex() As IndexData, _
                        ByVal intStockNo As Integer, _
                        ByVal indexDay As String)
    Dim signalFlag As Single       ' ��=1�����I�B��=0.5���C�I
    Dim indexDay1 As Integer     ' �N�ǤJ��MAP�r���ഫ���ƭ�
    Dim indexDay2 As Integer     ' �N�ǤJ��MAP�r���ഫ���ƭ�
    Dim nowIndex1 As Single   ' ����@�G�ثe��ƪ�MAP��
    Dim prevIndex1 As Single   ' ����@�G�e�@����ƪ�MAP��
    Dim nowIndex2 As Single   ' ����G�G�ثe��ƪ�MAP��
    Dim prevIndex2 As Single   ' ����G�G�e�@����ƪ�MAP��
    Dim i As Integer
      
    On Error GoTo ERR_HANDLE
    
    '--------------------------------------------------------------------
    '* Initialize Variables
    '--------------------------------------------------------------------
   
    Call subKD(udtStock, udtIndex, intStockNo, indexDay)

    indexDay1 = getIndexDays("K")
    indexDay2 = getIndexDays("D")
    signalFlag = HIGH_SIGNAL
    gintSector = 0
   
    For i = 2 To intStockNo
        With udtIndex(i)
            ' �x�s�ҿ�ܪ��Ĥ@�ӱ��󪺭�
            Select Case indexDay1
                Case 600    ' K value
                    nowIndex1 = .sngK
                    prevIndex1 = udtIndex(i - 1).sngK
                Case 601    ' D value
                    nowIndex1 = .sngD
                    prevIndex1 = udtIndex(i - 1).sngD
            End Select
            '--- �x�b�ҿ�ܪ��ĤG�ӱ��󪺭� ---
            Select Case indexDay2
                Case 600    ' K value
                    nowIndex2 = .sngK
                    prevIndex2 = udtIndex(i - 1).sngK
                Case 601    ' D value
                    nowIndex2 = .sngD
                    prevIndex2 = udtIndex(i - 1).sngD
            End Select
            
            '--------------------------------------------------------------------
            '* �O�����I�O�ݩ��I�ΧC�I
            '--------------------------------------------------------------------
            If (nowIndex1 > nowIndex2) Or _
                ((nowIndex1 = nowIndex2) And (prevIndex1 < prevIndex2)) Then
                signalFlag = HIGH_SIGNAL     ' ���I
            Else
                signalFlag = LOW_SIGNAL   ' �C�I
            End If
            .sngSector = signalFlag
        End With
    Next
   
    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.setSectorByKD()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
    End Select
End Sub


'***************************************************************************************************************************
'* ��    ��:
'*    ���ΥX�C��Sector -- use MACD  --** 20071218 OK **--
'* ��J�Ѽ�:
'*    udtStock �C��ѻ����(��l���)
'*    udtIndex �C��ѻ����(�޳N����)
'*    intStockNo �ѻ���Ƶ���
'*    strDayNo �϶����̤֤Ѽ�(�p�󦹭Ȫ̻ݦX��)
'*    strStkDis �϶����̰��P�̧C�I�t�Z��(�p�󦹭Ȫ̻ݦX��)
'*    indexName1 �ǤJ��MAP�r��--�_��
'*    indexName2 �ǤJ��MAP�r��--����
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20080916 Earvin   �s�W
'* ��    ��:
'*    1. sngSector = 1 ���ܬ����I�Ϭq�FsngSector = 0.5 ���ܬ��C�I�Ϭq
'***************************************************************************************************************************
Public Sub setSectorByMACD(ByRef udtStock() As StockData, _
                        ByRef udtIndex() As IndexData, _
                        ByVal intStockNo As Integer)
    Dim signalFlag As Single       ' ��=1�����I�B��=0.5���C�I
    Dim i As Integer
      
    On Error GoTo ERR_HANDLE
    
    '--------------------------------------------------------------------
    '* Initialize Variables
    '--------------------------------------------------------------------
    signalFlag = 1
    gintSector = 0
    
    For i = 2 To intStockNo
        With udtIndex(i)
            If udtStock(i).sngDate >= 851015 Then
                If .sngDIF_MACD >= 0 Then
                    signalFlag = HIGH_SIGNAL    ' ���I
                Else
                    signalFlag = LOW_SIGNAL     ' �C�I
                End If
                .sngSector = signalFlag
            End If
        End With
    Next
        
    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.setSectorByMACD()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
    End Select
End Sub


'***************************************************************************************************************************
'* ��    ��:
'*    ���ΥX�C��Sector: use MAP
'* ��J�Ѽ�:
'*    udtStock() �C��ѻ����(��l���)
'*    udtIndex() �C��ѻ����(�޳N����)
'*    intStockCount �ѻ���Ƶ���
'*    splitDay ���ΰ϶����Ѽ�
'* ��X�Ѽ�: �L
'* ��    ��:
'*    1.00  20090214 Earvin   �s�W
'* ��    ��:
'*    1. sngSector = 1 ���ܬ����I�Ϭq�FsngSector = 0.5 ���ܬ��C�I�Ϭq
'***************************************************************************************************************************
Public Sub setSectorByFixedDay(ByRef udtStock() As StockData, _
                        ByRef udtIndex() As IndexData, _
                        ByVal intStockCount As Integer, _
                        ByVal intSplitDay As Integer)
    Dim sngSignalFlag As Single   ' ��=1�����I�B��=0.5���C�I
    Dim intDayCount As Integer
    Dim i As Integer
      
    On Error GoTo ERR_HANDLE
    
    '--------------------------------------------------------------------
    '* Initialize Variables
    '--------------------------------------------------------------------
   
    sngSignalFlag = LOW_SIGNAL
    intDayCount = 1
   
    For i = 1 To intStockCount
        With udtIndex(i)
            .sngSector = sngSignalFlag
            If intDayCount >= intSplitDay Then
                If sngSignalFlag = HIGH_SIGNAL Then
                    sngSignalFlag = LOW_SIGNAL
                Else
                    sngSignalFlag = HIGH_SIGNAL
                End If
                intDayCount = 1
            Else
                intDayCount = intDayCount + 1
            End If
        End With
    Next
   
    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.setSectorByFixedDay()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
    End Select
End Sub









































'Not Finished -- 921212
'***********************************************************************************
'* Quick Sort Method
'***********************************************************************************
Public Sub QuickSort(udtStkData() As StockData, intStart As Integer, _
                    intEnd As Integer)
    Dim intPosOfSplitter As Integer
    
    On Error GoTo ERR_HANDLE
    
    If intEnd > intStart Then
        Partition udtStkData(), intStart, intEnd
        QuickSort udtStkData(), intStart, intPosOfSplitter - 1
        QuickSort udtStkData(), intPosOfSplitter + 1, intEnd
    End If
        
    Exit Sub
    
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.QuickSort()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Sub


'Not Finished -- 921212
'***********************************************************************************
'* Partition Method use for Qucik Sort Method
'***********************************************************************************
Private Sub Partition(udtStkData() As StockData, intStart As Integer, _
                        intEnd As Integer)
    Dim intSplitPos As Integer, intNewStart As Integer
    Dim i As Integer
    
End Sub


'***************************************************************************************************************************
'* ��    ��:
'*    �N���ΥX��Sector�亦�^�T�p����w���e�R����
'* ��J�Ѽ�:
'*    udtStock �ѥ���l���
'*    udtIndex �ѥ��޳N����
'*    intStockNo ��Ƶ���
'*    strFluctuation �̧C���^�T���e
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20080916 Earvin   �s�W
'* ��    ��:
'*    1. sngSector = 1 ���ܬ����I�Ϭq�FsngSector = 0.5 ���ܬ��C�I�Ϭq
'***************************************************************************************************************************
Public Sub MeetFluctuation(ByRef udtStock() As StockData, _
                            ByRef udtIndex() As IndexData, _
                            ByVal intStockNo As Integer, _
                            ByVal strFluctuation As String)
    Dim sngHigh As Single
    Dim sngLow As Single
    Dim sngStart As Single
    Dim sngFluctuation As Single
    Dim sngSector As Single
    Dim intBegPos As Integer
    Dim intEndPos As Integer
    Dim i As Integer, j As Integer
    
    On Error GoTo ERR_HANDLE
    
    '--- Initialize Variables ---
    sngFluctuation = 0
    sngHigh = -1
    sngLow = 99999
    sngStart = 0
    sngSector = udtIndex(1).sngSector
    intBegPos = 1
    intEndPos = 1
    
    For i = 2 To intStockNo
        With udtIndex(i)
            If .sngSector <> sngSector Then
                sngStart = udtStock(intBegPos).sngEndprice  ' �ӰϬq���}�L��
                If sngSector = 1 Then
                    For j = intBegPos To intEndPos
                        '--- �䰪�I ---
                        If udtStock(j).sngEndprice > sngHigh Then
                            sngHigh = udtStock(j).sngEndprice
                        End If
                    Next
                Else
                    For j = intBegPos To intEndPos
                        '--- ��C�I ---
                        If udtStock(j).sngEndprice < sngLow Then
                            sngLow = udtStock(j).sngEndprice
                        End If
                    Next
                End If
                '--- �P�_�̰��I�P�_�l�����t�Z�T�� ---
                If sngSector = 1 Then
                    sngFluctuation = (sngHigh - sngStart) / sngStart
                Else
                    sngFluctuation = (sngStart - sngLow) / sngStart
                End If
                '--- �p����e�ȡA�h�M��0 ---
                If sngFluctuation < CSng(strFluctuation / 100) Then
                    For j = intBegPos To intEndPos
                        udtIndex(j).sngSector = 0
                    Next
                End If
                '--- Reset the variables and continue next sector ---
                sngFluctuation = 0
                sngHigh = -1
                sngLow = 99999
                sngStart = 0
                intBegPos = i
                intEndPos = i
                sngSector = udtIndex(i).sngSector
            Else
                intEndPos = i
            End If
        End With
    Next
    
    Exit Sub
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.MeetFluctuation()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Sub


'***************************************************************************************************************************
'* ��    ��:
'*    ���ΥX�C��Sector: use MAP      --** 20071214 Finished **--
'* ��J�Ѽ�:
'*    udtStock() �C��ѻ����(��l���)
'*    udtIndex() �C��ѻ����(�޳N����)
'*    intStockNo �ѻ���Ƶ���
'*    strDayNo �϶����̤֤Ѽ�(�p�󦹭Ȫ̻ݦX��)
'*    strStkDis �϶����̰��P�̧C�I�t�Z��(�p�󦹭Ȫ̻ݦX��)
'*    indexName1 �ǤJ��MAP�r��--�_��
'*    indexName2 �ǤJ��MAP�r��--����
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20080916 Earvin   �s�W
'* ��    ��:
'*    1. sngSector = 1 ���ܬ����I�Ϭq�FsngSector = 0.5 ���ܬ��C�I�Ϭq
'***************************************************************************************************************************
Public Sub setSectorByMAP(ByRef udtStock() As StockData, _
                        ByRef udtIndex() As IndexData, _
                        ByVal intStockNo As Integer, _
                        ByVal indexName1 As String, _
                        ByVal indexName2 As String)
    Dim signalFlag As Single    ' ��=1�����I�B��=0.5���C�I
    Dim indexDay1 As Integer    ' �N�ǤJ��MAP�r���ഫ���ƭ�
    Dim indexDay2 As Integer    ' �N�ǤJ��MAP�r���ഫ���ƭ�
    Dim nowIndex1 As Single     ' ����@�G�ثe��ƪ�MAP��
    Dim prevIndex1 As Single    ' ����@�G�e�@����ƪ�MAP��
    Dim nowIndex2 As Single     ' ����G�G�ثe��ƪ�MAP��
    Dim prevIndex2 As Single    ' ����G�G�e�@����ƪ�MAP��
    Dim intDayNo As Integer     ' �϶����̤֤Ѽ�(�p�󦹭Ȫ̻ݦX��)
    Dim intStkDis As Integer    ' �϶����̰��P�̧C�I�t�Z��(�p�󦹭Ȫ̻ݦX��)
    Dim i As Integer
      
    On Error GoTo ERR_HANDLE
    
    '--------------------------------------------------------------------
    '* Initialize Variables
    '--------------------------------------------------------------------
    indexDay1 = getIndexDays(indexName1)
    indexDay2 = getIndexDays(indexName2)
    signalFlag = 1
    gintSector = 0
   
    For i = 2 To intStockNo
        With udtIndex(i)
            '--------------------------------------------------------------------
            '* �ثe�O�Χ��u�Ӱ�split sector
            '* �ӿ�ܪ����u������u�|�v��split���G
            '* 1.�������u�iomit���u���p�i�ʡA����ֳt�ӵu�����j�i��
            '*   �o�L�k����
            '* 2.�u�����u�i�����h���i�ʡA���]split sector�L�h�A��
            '*   �L�k������Ͷժ��̰��I
            '*
            '* �ҥH�o��split ���ʧ@�i�H�A��i�A�H���U���u�����u�I�A
            '* �h����U�۪����I
            '--------------------------------------------------------------------
            ' �x�s�ҿ�ܪ��Ĥ@�ӱ��󪺭�
            Select Case indexDay1
                Case 3      ' 3MAP
                    nowIndex1 = .sngP3
                    prevIndex1 = udtIndex(i - 1).sngP3
                Case 4      ' 4MAP
                    nowIndex1 = .sngP4
                    prevIndex1 = udtIndex(i - 1).sngP4
                Case 5      ' 5MAP
                    nowIndex1 = .sngP5
                    prevIndex1 = udtIndex(i - 1).sngP5
                Case 6      ' 6MAP
                    nowIndex1 = .sngP6
                    prevIndex1 = udtIndex(i - 1).sngP6
                Case 8      ' 8MAP
                    nowIndex1 = .sngP8
                    prevIndex1 = udtIndex(i - 1).sngP8
                Case 10     ' 10MAP
                    nowIndex1 = .sngP10
                    prevIndex1 = udtIndex(i - 1).sngP10
                Case 12     ' 12MAP
                    nowIndex1 = .sngP12
                    prevIndex1 = udtIndex(i - 1).sngP12
                Case 20     ' 20MAP
                    nowIndex1 = .sngp20
                    prevIndex1 = udtIndex(i - 1).sngp20
                Case 24     ' 24MAP
                    nowIndex1 = .sngP24
                    prevIndex1 = udtIndex(i - 1).sngP24
                Case 30     ' 30MAP
                    nowIndex1 = .sngP30
                    prevIndex1 = udtIndex(i - 1).sngP30
                Case 60     ' 60MAP
                    nowIndex1 = .sngP60
                    prevIndex1 = udtIndex(i - 1).sngP60
                Case 72     ' 72MAP
                    nowIndex1 = .sngP72
                    prevIndex1 = udtIndex(i - 1).sngP72
                Case 120    ' 120MAP
                    nowIndex1 = .sngP120
                    prevIndex1 = udtIndex(i - 1).sngP120
                Case 144    ' 144MAP
                    nowIndex1 = .sngP144
                    prevIndex1 = udtIndex(i - 1).sngP144
                Case 240    ' 240MAP
                    nowIndex1 = .sngP240
                    prevIndex1 = udtIndex(i - 1).sngP240
                Case 288    ' 288MAP
                    nowIndex1 = .sngP288
                    prevIndex1 = udtIndex(i - 1).sngP288
                Case Else
'               nowIndex1 = .sngP288
'               prevIndex1 = udtIndex(i - 1).sngP288
                    Err.Raise 100
            End Select
            '--- �x�b�ҿ�ܪ��ĤG�ӱ��󪺭� ---
            Select Case indexDay2
                Case 3      ' 3MAP
                    nowIndex2 = .sngP3
                    prevIndex2 = udtIndex(i - 1).sngP3
                Case 4      ' 4MAP
                    nowIndex2 = .sngP4
                    prevIndex2 = udtIndex(i - 1).sngP4
                Case 5      ' 5MAP
                    nowIndex2 = .sngP5
                    prevIndex2 = udtIndex(i - 1).sngP5
                Case 6      ' 6MAP
                    nowIndex2 = .sngP6
                    prevIndex2 = udtIndex(i - 1).sngP6
                Case 8      ' 8MAP
                    nowIndex2 = .sngP8
                    prevIndex2 = udtIndex(i - 1).sngP8
                Case 10     ' 10MAP
                    nowIndex2 = .sngP10
                    prevIndex2 = udtIndex(i - 1).sngP10
                Case 12     ' 12MAP
                    nowIndex2 = .sngP12
                    prevIndex2 = udtIndex(i - 1).sngP12
                Case 20     ' 20MAP
                    nowIndex2 = .sngp20
                    prevIndex2 = udtIndex(i - 1).sngp20
                Case 24     ' 24MAP
                    nowIndex2 = .sngP24
                    prevIndex2 = udtIndex(i - 1).sngP24
                Case 30     ' 30MAP
                    nowIndex2 = .sngP30
                    prevIndex2 = udtIndex(i - 1).sngP30
                Case 60     ' 60MAP
                    nowIndex2 = .sngP60
                    prevIndex2 = udtIndex(i - 1).sngP60
                Case 72     ' 72MAP
                    nowIndex2 = .sngP72
                    prevIndex2 = udtIndex(i - 1).sngP72
                Case 120    ' 120MAP
                    nowIndex2 = .sngP120
                    prevIndex2 = udtIndex(i - 1).sngP120
                Case 144    ' 144MAP
                    nowIndex2 = .sngP144
                    prevIndex2 = udtIndex(i - 1).sngP144
                Case 240    ' 240MAP
                    nowIndex2 = .sngP240
                    prevIndex2 = udtIndex(i - 1).sngP240
                Case 288    ' 288MAP
                    nowIndex2 = .sngP288
                    prevIndex2 = udtIndex(i - 1).sngP288
                Case Else
'               nowIndex2 = .sngP288
'               prevIndex2 = udtIndex(i - 1).sngP288
                    Err.Raise 100
            End Select
            
            '--------------------------------------------------------------------
            '* �O�����I�O�ݩ��I�ΧC�I
            '--------------------------------------------------------------------
            If (nowIndex1 > nowIndex2) Or _
                ((nowIndex1 = nowIndex2) And (prevIndex1 < prevIndex2)) Then
                signalFlag = HIGH_SIGNAL     ' ���I
            Else
                signalFlag = LOW_SIGNAL   ' �C�I
            End If
            .sngSector = signalFlag
        End With
    Next
   
    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.setSectorByMAP()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
    End Select
End Sub



'-----------------20080918
'***********************************************************************************
'* �̶ǤJ�ثe��Ʀ�m�����������
'* Input Param.
'*   udtStock  �G�C��ѻ����
'*   intStockNo�G�ثe��Ƶ���
'*   strStkDate�G�ǤJ�����
'* Return : �Ǧ^�Ӥ���b��ƶ�������m (Type�GInteger)
'***********************************************************************************
'***************************************************************************************************************************
'* ��    ��:
'*    ���ΥX�C��Sector: use MAP      --** 20071214 Finished **--
'* ��J�Ѽ�:
'*    udtStock() �C��ѻ����(��l���)
'*    udtIndex() �C��ѻ����(�޳N����)
'*    intStockNo �ѻ���Ƶ���
'*    strDayNo �϶����̤֤Ѽ�(�p�󦹭Ȫ̻ݦX��)
'*    strStkDis �϶����̰��P�̧C�I�t�Z��(�p�󦹭Ȫ̻ݦX��)
'*    indexName1 �ǤJ��MAP�r��--�_��
'*    indexName2 �ǤJ��MAP�r��--����
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20080916 Earvin   �s�W
'* ��    ��:
'*    1. sngSector = 1 ���ܬ����I�Ϭq�FsngSector = 0.5 ���ܬ��C�I�Ϭq
'***************************************************************************************************************************
Public Function ReturnIndexPos(ByRef udtStock() As StockData, _
                                ByVal intStockNo As Integer, _
                                ByVal strStkDate As String) As Integer
    Dim intStkPos As Integer
    Dim i As Integer
    
    On Error GoTo ERR_HANDLE
    
    For i = 1 To intStockNo
        '--- ���ŦX����ơA�Ǧ^�ᵲ���Ө禡 ---
        If udtStock(i).sngDate >= strStkDate Then
            ReturnIndexPos = i
            Exit Function
        End If
    Next
      
    Err.Raise 10000, "ReturnIndexPos", "�䤣����w��������"

    Exit Function
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.ReturnIndexPos()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
End Function


'***********************************************************************************
'* �p��b�C��sector�϶���GRG -- use MAP
'* Input Param.
'*   udtStock  �G�C��ѻ����
'*   udtIndex  �G�x�s�����Ƹ��
'*   intStockNo�G��Ƶ���
'*   strStartDT�G�ǤJ����ư_�l���
'*   strEndDT  �G�ǤJ����Ƶ������
'***********************************************************************************
Public Sub GetHighLowPoints(ByRef udtStock() As StockData, _
                            ByRef udtIndex() As IndexData, _
                            ByVal intStockNo As Integer, _
                            ByVal strStartDT As String, _
                            ByVal strEndDT As String)
    Dim intPos As Integer           ' �ثe�p�⪺��m
    Dim intStartPos As Integer      ' �ΨӰO���C��sector���_�l��ƪ���m
    Dim intEndPos As Integer        ' �ΨӰO���C��sector���̫�@����ƪ���m
    Dim intTmpStockNo As Integer    ' �O���ҶǤJ����������Ө��o�b���(udtStock)������m
    Dim signalFlag As Single        ' Sector ���e (1 : ���I�F0.5 : �C�I)
    Dim udtGRG() As udtGRGIndex     ' �x�s�n���E�������
    Dim udtGroup() As Boolean       ' �O���O���X����ƻE����(�C)�I
    Dim intGRGLine As Integer       ' �O���ثe�O������Ƭ����ƦC
    Dim blnFlag As Boolean          ' �P�_�����p��O�_����
    Dim intMainPos As Integer       ' ���ƦC����m
    Dim intClusterPos As Integer    ' �x�scluster ��m
    Dim sngHighLowDate As Single    ' �O���p�⪺�E����Ƥ����̰��I�γ̧C�I�O���@��
    Dim i As Integer, j As Integer, k As Integer
    '--- �]�wOutput File, For Evaluation Use ---
    Dim intOutputFile As Integer
    Dim OutputFileName As String
    Dim strOutData As String

    On Error GoTo ERR_HANDLE
    
    '--- Initialize Variables ---
    ReDim gudtClusterDat(100)   ' �O���C��sector�̫�E�����G���� (�̦h�i�O100��)
    intClusterPos = 1           ' �O���ثegudtClusterDat�}�C�Ϊ�����
    
    '--- Open file to record the results ---
    OutputFileName = "ClusterPattern.csv"
    intOutputFile = FreeFile()
    Open OutputFileName For Output As #intOutputFile
    
    '----------------------------------------------------------------------------
    '--- Write Header ---
    strOutData = "sector�_��,sector����,sector�̰��I���," & _
                "sector�̰��I��������L��,sector�̧C�I���," & _
                "sector�̧C�I��������L��,�ϥλE�������," & _
                "GRG,parm1-name,parm1,parm2-name,parm2,parm3-name,parm3," & _
                "parm4-name,parm4,parm5-name,parm5,parm6-name,parm6," & _
                "parm7-name,parm7,parm8-name,parm8,Select-Count"
    Print #intOutputFile, strOutData
    '----------------------------------------------------------------------------
    
    '--- �ǤJ�_�l����Ө��o�b���(udtStock)������m ---
    intGRGLine = ReturnIndexPos(udtStock, intStockNo, strStartDT)
    '--- �ǤJ��������Ө��o�b���(udtStock)������m ---
    intTmpStockNo = ReturnIndexPos(udtStock, intStockNo, strEndDT)
    
    i = intGRGLine
    signalFlag = udtIndex(i).sngSector
    '--- �x�s�ҭn�p�Ⱚ�I(�C�I)��sector���ȡA�ç�X�_�l��m ---
    While signalFlag <> gsngHighLow
        i = i + 1
        If i > intTmpStockNo Then
            Err.Raise 10001, "(GetHighLowPoints)", "�䤣��ŦX��ơA�h���Ϳ��~�T��"
        End If
        signalFlag = udtIndex(i).sngSector
    Wend
    '--- Assign start line position ---
    intPos = i
    intStartPos = i
    intEndPos = i
    
    '--------------------------------------------------------------------
    '* �p��b strStartDT �� strEndDT ����ƻE��
    '--------------------------------------------------------------------
    While intEndPos < intTmpStockNo
        '--- �M��C��sector�_���I ---
        intStartPos = intEndPos
        While (signalFlag = udtIndex(intEndPos).sngSector) And intEndPos < intStockNo
            intEndPos = intEndPos + 1
        Wend
        
        '--- �N�Ӱ϶������x�b��GRG variables�A�̫�@���s����ƦC����� ---
        intMainPos = intEndPos - intStartPos + 1    ' �p���sector������ (���Ȥ]���ܥ��ƦC�N�Ӧs�񪺦�m)
        
        '---------------------------------------------------------------------------------------
        '--- �O���C��sector���_�l��B�I��� -- 920923 ---
        strOutData = udtStock(intStartPos).sngDate & "," & udtStock(intEndPos).sngDate
        k = FindHighLowDate(udtStock, intStartPos, intEndPos, 1)        ' sector�������I
        strOutData = strOutData & "," & udtStock(k).sngDate & "," & udtStock(k).sngEndprice
        k = FindHighLowDate(udtStock, intStartPos, intEndPos, 0.5)      ' sector�����C�I
        strOutData = strOutData & "," & udtStock(k).sngDate & "," & udtStock(k).sngEndprice
        '---------------------------------------------------------------------------------------
        
        ReDim udtGRG(intMainPos)    ' �x�s�n���E�������
        ReDim udtGroup(intMainPos)  ' �x�s�E�������G (�b�ҳ]�w������U�A���X���̫�|�E�b�@�_)
 
        '--- Assign �϶����U�����Ц�udtGRG (�̦h�i���8�ӫ���) ---
        k = intStartPos
        For j = 1 To intMainPos - 1
            udtGRG(j).sngDate = udtStock(k).sngDate
            udtGRG(j).sngParam1 = GetFactorValue(udtIndex, k, 1)
            udtGRG(j).sngParam2 = GetFactorValue(udtIndex, k, 2)
            udtGRG(j).sngParam3 = GetFactorValue(udtIndex, k, 3)
            udtGRG(j).sngParam4 = GetFactorValue(udtIndex, k, 4)
            udtGRG(j).sngParam5 = GetFactorValue(udtIndex, k, 5)
            udtGRG(j).sngParam6 = GetFactorValue(udtIndex, k, 6)
            udtGRG(j).sngParam7 = GetFactorValue(udtIndex, k, 7)
            udtGRG(j).sngParam8 = GetFactorValue(udtIndex, k, 8)
            k = k + 1
        Next
        
        '--- ��X�n�����ƦC(��sector���̰��I�γ̧C�I)�����assing�̫ܳ�@�C ---
        i = FindHighLowDate(udtStock, intStartPos, intEndPos, signalFlag)
        '--- Assign ���ƦC��̫�@�C ---
        With udtGRG(intMainPos)
            sngHighLowDate = udtStock(i).sngDate
            
            
            .sngDate = udtStock(i).sngDate
            .sngParam1 = GetFactorValue(udtIndex, i, 1)
            .sngParam2 = GetFactorValue(udtIndex, i, 2)
            .sngParam3 = GetFactorValue(udtIndex, i, 3)
            .sngParam4 = GetFactorValue(udtIndex, i, 4)
            .sngParam5 = GetFactorValue(udtIndex, i, 5)
            .sngParam6 = GetFactorValue(udtIndex, i, 6)
            .sngParam7 = GetFactorValue(udtIndex, i, 7)
            .sngParam8 = GetFactorValue(udtIndex, i, 8)
        End With
        '--- Preprocessing ---
        Call PreProcess(udtGRG, intMainPos)
        '--- Calcuate GRG ---
        Call CalGRG(udtGRG, udtGroup, intMainPos, sngHighLowDate)
        '--------------------------------------------------------------------
        '* �O���U�o���E�������G -- 920914
        '--------------------------------------------------------------------
        If udtGRG(intMainPos).sngGRG <> -1 Then
            gudtClusterDat(intClusterPos) = udtGRG(intMainPos)
            ' �N�E�����G��attribute���٭�
            Call RestoreData(gudtClusterDat, intClusterPos)
            
            '-----------------------------------------------------------------------------------------------
            '* Write-out, File-name : ccu.csv
            '* �A�������ɡA�H���ɮרӰ�GRG -- 921212
            '-----------------------------------------------------------------------------------------------
            ' 20080228 marked for compiler...
'''            strOutData = strOutData & "," & _
'''                        gudtClusterDat(intClusterPos).sngDate & "," & _
'''                        gudtClusterDat(intClusterPos).sngGRG & "," & _
'''                        frmGeryExp.txtAttrName(0).Text & "," & gudtClusterDat(intClusterPos).sngParam1 & "," & _
'''                        frmGeryExp.txtAttrName(1).Text & "," & gudtClusterDat(intClusterPos).sngParam2 & "," & _
'''                        frmGeryExp.txtAttrName(2).Text & "," & gudtClusterDat(intClusterPos).sngParam3 & "," & _
'''                        frmGeryExp.txtAttrName(3).Text & "," & gudtClusterDat(intClusterPos).sngParam4 & "," & _
'''                        frmGeryExp.txtAttrName(4).Text & "," & gudtClusterDat(intClusterPos).sngParam5 & "," & _
'''                        frmGeryExp.txtAttrName(5).Text & "," & gudtClusterDat(intClusterPos).sngParam6 & "," & _
'''                        frmGeryExp.txtAttrName(6).Text & "," & gudtClusterDat(intClusterPos).sngParam7 & "," & _
'''                        frmGeryExp.txtAttrName(7).Text & "," & gudtClusterDat(intClusterPos).sngParam8 & "," & _
'''                        gintSelCount
            Print #intOutputFile, strOutData
            '-----------------------------------------------------------------------------------------------
            
            intClusterPos = intClusterPos + 1
        
            '---------------------------------------------------------------------------
            '* 930324: �N��sector����ƪ�GRG��Assign�^udtindex()�ѵ{��display the value
            '---------------------------------------------------------------------------
            i = 1
            gsngCompFa = frmGeryExp.txtGRGThreshold.Text
            gsngCompFa2 = frmGeryExp.txtGRGThreshold2.Text
            
            For intPos = intStartPos To intEndPos - 1
                '--- 920923 : �N���������I��GRG�ȲM��0 ####### ---
                If udtGRG(i).sngGRG >= gsngCompFa Then
                    udtIndex(intPos).sngGRG = udtGRG(i).sngGRG
                ElseIf udtGRG(i).sngGRG <= gsngCompFa2 Then
                    udtIndex(intPos).sngGRG = udtGRG(i).sngGRG
                Else
                    udtIndex(intPos).sngGRG = 0
                End If
                i = i + 1
            Next
        End If
        '--- ���n�P�_�O�Ⱚ�I�άO�C�I�A�H�K����U�@�ӲŦX��sector�B�� ---
        signalFlag = udtIndex(intEndPos).sngSector
        '--- �x�s�Ĥ@��sector�� ---
        While signalFlag <> gsngHighLow
            intEndPos = intEndPos + 1
            signalFlag = udtIndex(intEndPos).sngSector
            If intEndPos > intTmpStockNo Then
                '--- �w�䧹�Ҧ�sector�A�õL�ŦX��ƥi�ѭp�� ---
                signalFlag = gsngHighLow
            End If
        Wend
    Wend

    Close #intOutputFile
    
'    '--------------------------------------------------------------------
'    '* �p��90�~�H�᪺�E�����p -- 920914
'    '* 920917�G���D
'    '*         �p��N���Ӫ���ƻP�p��X�Ӫ����B�C�Ipattern�����??
'    '* 920922�G�ثe��GRGa���覡�b���A���O�ĪG���n�K
'    '--------------------------------------------------------------------
'    Call CalculateHighLowPoints(udtStock, udtIndex, intStockNo, gudtClusterDat, gintClusterCnt)
       
    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case 6
            MsgBox "[GCFR_General_Module.GetHighLowPoints()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
            Resume Next
        Case 10001
            MsgBox "[GCFR_General_Module.GetHighLowPoints()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
        Case Else
            MsgBox "[GCFR_General_Module.GetHighLowPoints()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
   
    Err.Clear
    Resume Next
End Sub


'***********************************************************************************
'* �p��b�C��sector�϶���GRG (use Days)
'* Input Param.
'*   udtStock  �G�C��ѻ����
'*   udtIndex  �G�x�s�C��ѻ���ƪ����Ƹ��
'*   intStockNo�G��Ƶ���
'*   strStartDT�G�ǤJ����ư_�l���
'*   strEndDT  �G�ǤJ����Ƶ������
'***********************************************************************************
Public Sub GetHighLowPoints2(ByRef udtStock() As StockData, _
                            ByRef udtIndex() As IndexData, _
                            ByVal intStockNo As Integer, _
                            ByVal strStartDT As String, _
                            ByVal strEndDT As String)
    Dim intPos As Integer       ' �ثe�p�⪺��m
    Dim intStartPos As Integer
    Dim intEndPos As Integer
    Dim intTmpStockNo As Integer
    Dim i As Integer, j As Integer, k As Integer
    Dim signalFlag As Single       ' Sector ���e
    Dim udtGRG() As udtGRGIndex
    Dim udtGroup() As Boolean
    Dim intGRGLine As Integer   ' �O���ثe�O������Ƭ����ƦC
    Dim blnFlag As Boolean      ' �P�_�����p��O�_����
    Dim blnOK As Boolean
    Dim intMainPos As Integer   ' ���ƦC����m
    Dim sngGRG() As Single      ' �x�b�U�ƦC��GRG value
    Dim intOutputFile As Integer
    Dim OutputFileName As String
    Dim strData As String

    On Error GoTo ERR_HANDLE
      
    OutputFileName = "ClusterPattern.csv"
    intOutputFile = FreeFile()
    Open OutputFileName For Output As #intOutputFile
    '--- �ǤJ�_�l����Ө��o�b���(udtStock)������m ---
    intGRGLine = ReturnIndexPos(udtStock, intStockNo, strStartDT)
    '--- �ǤJ��������Ө��o�b���(udtStock)������m ---
    intTmpStockNo = ReturnIndexPos(udtStock, intStockNo, strEndDT)
    i = intGRGLine
    signalFlag = udtIndex(i).sngSector
    '--- assign start line position ---
    intPos = i
    intStartPos = i
    intEndPos = i
    
    '--------------------------------------------------------------------
    '* �p��b strStartDT �� strEndDT ����ƻE��
    '--------------------------------------------------------------------
'    While intPos < intTmpStockNo
    While intEndPos < intTmpStockNo
        '--- �M��C��sector�_���I ---
        intStartPos = intEndPos
        While (signalFlag = udtIndex(intEndPos).sngSector) And intEndPos < intStockNo
            intEndPos = intEndPos + 1
        Wend
        
        '--- �N�Ӱ϶������x�b��GRG variables�A�̫�@���s����ƦC����� ---
        intMainPos = intEndPos - intStartPos + 1
        ReDim udtGRG(intMainPos)
        ReDim sngGRG(intMainPos)
        ReDim udtGroup(intMainPos)  ' save the group
 
        '--- assign �϶����U�����Ц�udtGRG ---
        k = intStartPos
        For j = 1 To intMainPos - 1
            udtGRG(j).sngDate = udtStock(k).sngDate
            udtGRG(j).sngParam1 = GetFactorValue(udtIndex, k, 1)
            udtGRG(j).sngParam2 = GetFactorValue(udtIndex, k, 2)
            udtGRG(j).sngParam3 = GetFactorValue(udtIndex, k, 3)
            udtGRG(j).sngParam4 = GetFactorValue(udtIndex, k, 4)
            udtGRG(j).sngParam5 = GetFactorValue(udtIndex, k, 5)
            udtGRG(j).sngParam6 = GetFactorValue(udtIndex, k, 6)
            udtGRG(j).sngParam7 = GetFactorValue(udtIndex, k, 7)
            udtGRG(j).sngParam8 = GetFactorValue(udtIndex, k, 8)
            k = k + 1
        Next
        '--- 92705 : ��X�n�����ƦC�����assing�̫ܳ�@�C ---
        i = FindHighLowDate(udtStock, intStartPos, intEndPos, signalFlag)
        '--- Assign ���ƦC��̫�@�C ---
        With udtGRG(intMainPos)
            .sngDate = udtStock(i).sngDate
            .sngParam1 = GetFactorValue(udtIndex, i, 1)
            .sngParam2 = GetFactorValue(udtIndex, i, 1)
            .sngParam3 = GetFactorValue(udtIndex, i, 1)
            .sngParam4 = GetFactorValue(udtIndex, i, 1)
            .sngParam5 = GetFactorValue(udtIndex, i, 1)
            .sngParam6 = GetFactorValue(udtIndex, i, 1)
            .sngParam7 = GetFactorValue(udtIndex, i, 1)
            .sngParam8 = GetFactorValue(udtIndex, i, 1)
        End With
        '--- Preprocessing ---
        Call PreProcess(udtGRG, intMainPos)
        '--- Calcuate GRG --- 930810 has bug
        Call CalGRG(udtGRG, udtGroup, intMainPos, signalFlag)
        '--- �O���U�o���E�������G -- 920702 ---
        Dim strOutData As String
        strOutData = ""
        For j = 1 To intMainPos - 1
            If udtGroup(j) = True Then
                k = intStartPos + j - 1
                strOutData = udtStock(k).sngDate & vbTab
                strOutData = strOutData & udtStock(k).sngDate & vbTab
            End If
        Next
        Print #intOutputFile, strOutData
        '--- Assign�^udtindex() ---
        i = 1
        For intPos = intStartPos To intEndPos - 1
            udtIndex(intPos).sngGRG = udtGRG(i).sngGRG
            i = i + 1
        Next
        signalFlag = udtIndex(intEndPos).sngSector
    Wend

    Close #intOutputFile
    
    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case 6
            MsgBox "[GCFR_General_Module.GetHighLowPoints2()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
            Err.Clear
            Resume Next
        Case 10001
            MsgBox "[GCFR_General_Module.GetHighLowPoints2()] -- " & Err.Number & ":�S���ŦXsector��ƥi�ѭp��", vbOKOnly
        Case Else
            MsgBox "[GCFR_General_Module.GetHighLowPoints2()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
'            Resume Next
    End Select
End Sub


' 930410 : CY index use
' -- 921213 -- �ثe�D�n�ϥΤ�Method
'***********************************************************************************
'* ���ư��e�B�z
'* Input Param.
'*   udtGRG  �G�n�B�z�����
'*   intCount�G�n�B�z����ƪ�����
'***********************************************************************************
Public Sub PreProcess(ByRef udtGRG() As udtGRGIndex, ByVal intCount As Integer)
    Dim i As Integer

    On Error GoTo ERR_HANDLE
    
'''    '--- Initialize Variables ---
'''    For i = 1 To 8
'''        sngMax(i) = -99999
'''        sngMin(i) = 99999
'''    Next
'''
'''    '--------------------------------------------------------------------
'''    '* Find each Max value and Min value in each parameter
'''    '--------------------------------------------------------------------
'''    For i = 1 To intCount
'''        With udtGRG(i)
'''            If frmGeryExp.chkSelAttr(0).Value = "1" Then
'''                If sngMax(1) < .sngParam1 Then
'''                    sngMax(1) = .sngParam1
'''                End If
'''                If sngMin(1) > .sngParam1 Then
'''                    sngMin(1) = .sngParam1
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(1).Value = "1" Then
'''                If sngMax(2) < .sngParam2 Then
'''                    sngMax(2) = .sngParam2
'''                End If
'''                If sngMin(2) > .sngParam2 Then
'''                    sngMin(2) = .sngParam2
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(2).Value = "1" Then
'''                If sngMax(3) < .sngParam3 Then
'''                    sngMax(3) = .sngParam3
'''                End If
'''                If sngMin(3) > .sngParam3 Then
'''                    sngMin(3) = .sngParam3
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(3).Value = "1" Then
'''                If sngMax(4) < .sngParam4 Then
'''                    sngMax(4) = .sngParam4
'''                End If
'''                If sngMin(4) > .sngParam4 Then
'''                    sngMin(4) = .sngParam4
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(4).Value = "1" Then
'''                If sngMax(5) < .sngParam5 Then
'''                    sngMax(5) = .sngParam5
'''                End If
'''                If sngMin(5) > .sngParam5 Then
'''                    sngMin(5) = .sngParam5
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(5).Value = "1" Then
'''                If sngMax(6) < .sngParam6 Then
'''                    sngMax(6) = .sngParam6
'''                End If
'''                If sngMin(6) > .sngParam6 Then
'''                    sngMin(6) = .sngParam6
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(6).Value = "1" Then
'''                If sngMax(7) < .sngParam7 Then
'''                    sngMax(7) = .sngParam7
'''                End If
'''                If sngMin(7) > .sngParam7 Then
'''                    sngMin(7) = .sngParam7
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(7).Value = "1" Then
'''                If sngMax(8) < .sngParam8 Then
'''                    sngMax(8) = .sngParam8
'''                End If
'''                If sngMin(8) > .sngParam8 Then
'''                    sngMin(8) = .sngParam8
'''                End If
'''            End If
'''        End With
'''    Next
'''
'''    '--------------------------------------------------------------------
'''    '* ��Ȥ�
'''    '--------------------------------------------------------------------
'''    For i = 1 To intCount
'''        With udtGRG(i)
'''            '--------------------------------------------------------------------
'''            '* gintSelFactorsMethod = 1 ���u��j�v
'''            '* gintSelFactorsMethod = 2 ���u��p�v
'''            '* gintSelFactorsMethod = 3 ���u��ءv
'''            '--------------------------------------------------------------------
'''            If frmGeryExp.chkSelAttr(0).Value = "1" Then
'''                If gintSelFactorsMethod(1) = 1 Then
'''                    .sngParam1 = (.sngParam1 - sngMin(1)) / (sngMax(1) - sngMin(1))
'''                ElseIf gintSelFactorsMethod(1) = 2 Then
'''                    .sngParam1 = (sngMax(1) - .sngParam1) / (sngMax(1) - sngMin(1))
'''                Else
'''                    .sngParam1 = 1 - Abs(.sngParam1 - udtGRG(intCount).sngParam1) / (IIf((sngMax(1) - udtGRG(intCount).sngParam1 > udtGRG(intCount).sngParam1 - sngMin(1)), sngMax(1) - udtGRG(intCount).sngParam1, udtGRG(intCount).sngParam1 - sngMin(1)))
'''                End If
'''            End If
'''
'''            If frmGeryExp.chkSelAttr(1).Value = "1" Then
'''                If gintSelFactorsMethod(2) = 1 Then
'''                    .sngParam2 = (.sngParam2 - sngMin(2)) / (sngMax(2) - sngMin(2))
'''                ElseIf gintSelFactorsMethod(2) = 2 Then
'''                    .sngParam2 = (sngMax(2) - .sngParam2) / (sngMax(2) - sngMin(2))
'''                Else
'''                    .sngParam2 = 1 - Abs(.sngParam2 - udtGRG(intCount).sngParam2) / (IIf((sngMax(2) - udtGRG(intCount).sngParam2 > udtGRG(intCount).sngParam2 - sngMin(2)), sngMax(2) - udtGRG(intCount).sngParam2, udtGRG(intCount).sngParam2 - sngMin(2)))
'''                End If
'''            End If
'''
'''            If frmGeryExp.chkSelAttr(2).Value = "1" Then
'''                If gintSelFactorsMethod(3) = 1 Then
'''                    .sngParam3 = (.sngParam3 - sngMin(3)) / (sngMax(3) - sngMin(3))
'''                ElseIf gintSelFactorsMethod(3) = 2 Then
'''                    .sngParam3 = (sngMax(3) - .sngParam3) / (sngMax(3) - sngMin(3))
'''                Else
'''                    .sngParam3 = 1 - Abs(.sngParam3 - udtGRG(intCount).sngParam3) / (IIf((sngMax(3) - udtGRG(intCount).sngParam3 > udtGRG(intCount).sngParam3 - sngMin(3)), sngMax(3) - udtGRG(intCount).sngParam3, udtGRG(intCount).sngParam3 - sngMin(3)))
'''                End If
'''            End If
'''
'''            If frmGeryExp.chkSelAttr(3).Value = "1" Then
'''                If gintSelFactorsMethod(4) = 1 Then
'''                    .sngParam4 = (.sngParam4 - sngMin(4)) / (sngMax(4) - sngMin(4))
'''                ElseIf gintSelFactorsMethod(4) = 2 Then
'''                    .sngParam4 = (sngMax(4) - .sngParam4) / (sngMax(4) - sngMin(4))
'''                Else
'''                    .sngParam4 = 1 - Abs(.sngParam4 - udtGRG(intCount).sngParam4) / (IIf((sngMax(4) - udtGRG(intCount).sngParam4 > udtGRG(intCount).sngParam4 - sngMin(4)), sngMax(4) - udtGRG(intCount).sngParam4, udtGRG(intCount).sngParam4 - sngMin(4)))
'''                End If
'''            End If
'''
'''            If frmGeryExp.chkSelAttr(4).Value = "1" Then
'''                If gintSelFactorsMethod(5) = 1 Then
'''                    .sngParam5 = (.sngParam5 - sngMin(5)) / (sngMax(5) - sngMin(5))
'''                ElseIf gintSelFactorsMethod(5) = 2 Then
'''                    .sngParam5 = (sngMax(5) - .sngParam5) / (sngMax(5) - sngMin(5))
'''                Else
'''                    .sngParam5 = 1 - Abs(.sngParam5 - udtGRG(intCount).sngParam5) / (IIf((sngMax(5) - udtGRG(intCount).sngParam5 > udtGRG(intCount).sngParam5 - sngMin(5)), sngMax(5) - udtGRG(intCount).sngParam5, udtGRG(intCount).sngParam5 - sngMin(5)))
'''                End If
'''            End If
'''
'''            If frmGeryExp.chkSelAttr(5).Value = "1" Then
'''                If gintSelFactorsMethod(6) = 1 Then
'''                    .sngParam6 = (.sngParam6 - sngMin(6)) / (sngMax(6) - sngMin(6))
'''                ElseIf gintSelFactorsMethod(6) = 2 Then
'''                    .sngParam6 = (sngMax(6) - .sngParam6) / (sngMax(6) - sngMin(6))
'''                Else
'''                    .sngParam6 = 1 - Abs(.sngParam6 - udtGRG(intCount).sngParam6) / (IIf((sngMax(6) - udtGRG(intCount).sngParam6 > udtGRG(intCount).sngParam6 - sngMin(6)), sngMax(6) - udtGRG(intCount).sngParam6, udtGRG(intCount).sngParam6 - sngMin(6)))
'''                End If
'''            End If
'''
'''            If frmGeryExp.chkSelAttr(6).Value = "1" Then
'''                If gintSelFactorsMethod(7) = 1 Then
'''                    .sngParam7 = (.sngParam7 - sngMin(7)) / (sngMax(7) - sngMin(7))
'''                ElseIf gintSelFactorsMethod(7) = 2 Then
'''                    .sngParam7 = (sngMax(7) - .sngParam7) / (sngMax(7) - sngMin(7))
'''                Else
'''                    .sngParam7 = 1 - Abs(.sngParam7 - udtGRG(intCount).sngParam7) / (IIf((sngMax(7) - udtGRG(intCount).sngParam7 > udtGRG(intCount).sngParam7 - sngMin(7)), sngMax(7) - udtGRG(intCount).sngParam7, udtGRG(intCount).sngParam7 - sngMin(7)))
'''                End If
'''            End If
'''
'''            If frmGeryExp.chkSelAttr(7).Value = "1" Then
'''                If gintSelFactorsMethod(8) = 1 Then
'''                    .sngParam8 = (.sngParam8 - sngMin(8)) / (sngMax(8) - sngMin(8))
'''                ElseIf gintSelFactorsMethod(8) = 2 Then
'''                    .sngParam8 = (sngMax(8) - .sngParam8) / (sngMax(8) - sngMin(8))
'''                Else
'''                    .sngParam8 = 1 - Abs(.sngParam8 - udtGRG(intCount).sngParam8) / (IIf((sngMax(8) - udtGRG(intCount).sngParam8 > udtGRG(intCount).sngParam8 - sngMin(8)), sngMax(8) - udtGRG(intCount).sngParam8, udtGRG(intCount).sngParam8 - sngMin(8)))
'''                End If
'''            End If
'''        End With
'''    Next
    
    Exit Sub
    
    
ERR_HANDLE:
    Select Case Err.Number
        Case 6
            Debug.Print "[GCFR_General_Module.PreProcess()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
        Case Else
            MsgBox "[GCFR_General_Module.PreProcess()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
    
    Err.Clear
    Resume Next
End Sub



'***************************************************************************************************
'* ��    ��:
'*    ��X��Sector���̰�(�C)�I
'* ��J�Ѽ�:
'*    udtStock �n�B�z�����(�s��C��Sector�����)
'*    intStartPos ��Sector���_�l��m
'*    intEndPos ��Sector��������m
'*    sngFlag ��=1���O�䰪�I�F��=0.5���ܧ�C�I
'* ��X�Ѽ�:
'*    Integer �^�ǰ�(�C)�I����m
'* ��    ��:
'*    2.00: 20080913 Earvin   New
'***************************************************************************************************
Public Function FindHighLowDate(ByRef udtStock() As StockData, _
                            ByVal intStartPos As Integer, _
                            ByVal intEndPos As Integer, _
                            ByVal sngFlag As Single) As Integer

    Dim i As Integer
    Dim sngMaxValue As Single, sngMinValue As Single
    Dim intPos As Integer
       
    On Error GoTo ERR_HANDLE
    
    '*** Initialize Variables ***
    sngMaxValue = 0
    sngMinValue = 99999
    intPos = 0
    
    For i = intStartPos To intEndPos
        '--- sngFlag = 1 --> �䰪�I�FsngFalg = 0.5 --> ��C�I ---
        If sngFlag = 1 Then ' ���I
            If udtStock(i).sngEndprice > sngMaxValue Then
                sngMaxValue = udtStock(i).sngEndprice
                intPos = i
            End If
        Else    ' �C�I
            If udtStock(i).sngEndprice < sngMinValue Then
                sngMinValue = udtStock(i).sngEndprice
                intPos = i
            End If
        End If
    Next
    
    FindHighLowDate = intPos
    
    Exit Function
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            Debug.Print "[GCFR_General_Module.FindHighLowDate()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
    
    Err.Clear
    Resume Next
End Function


''''***********************************************************************************
''''* ��X��Sector���̰�(�C)�I
''''* input param:
''''*   udtStock   �G�n�B�z�����(�s��C��Sector�����)
''''*   intStartPos�G��Sector���_�l��m
''''*   intEndPos  �G��Sector��������m
''''*   signalFlag    �G��=1���O�䰪�I�F��=0.5���ܧ�C�I
''''*   Return     �G�^�ǰ�(�C)�I����m
''''***********************************************************************************
'''Public Function FindHighLowDate(ByRef udtStock() As Stockdata, _
'''                            ByVal intStartPos As Integer, _
'''                            ByVal intEndPos As Integer, _
'''                            ByVal signalFlag As Single) As Integer
'''
'''    Dim i As Integer
'''    Dim sngMaxValue As Single, sngMinValue As Single
'''    Dim intPos As Integer
'''
'''    On Error GoTo ERR_HANDLE
'''
'''    '--- Initialize Variables ---
'''    sngMaxValue = 0
'''    sngMinValue = 99999
'''    intPos = 0
'''
'''    For i = intStartPos To intEndPos
'''        '--- signalFlag = 1 --> �䰪�I�FsngFalg = 0.5 --> ��C�I ---
'''        If signalFlag = 1 Then ' ���I
'''            If udtStock(i).sngEndprice > sngMaxValue Then
'''                sngMaxValue = udtStock(i).sngEndprice
'''                intPos = i
'''            End If
'''        Else    ' �C�I
'''            If udtStock(i).sngEndprice < sngMinValue Then
'''                sngMinValue = udtStock(i).sngEndprice
'''                intPos = i
'''            End If
'''        End If
'''    Next
'''
'''    FindHighLowDate = intPos
'''
'''    Exit Function
'''
'''ERR_HANDLE:
'''    Select Case Err.Number
'''        Case Else
'''            Debug.Print "[Method: FindHighLowDate()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
'''    End Select
'''
'''    Err.Clear
'''    Resume Next
'''End Function


'***********************************************************************************
'* Get attributes value
'* Input Param:
'*   udtIndex    : �x�s�����Ƹ��
'*   intPos      : �nŪ����ƪ���m
'*   intSelFactor: ��ܪ�attribute
'* Return        : �ҿ�ܤ���Ƥ�attribute����
'***********************************************************************************
Public Function GetFactorValue(ByRef udtIndex() As IndexData, _
                                ByVal intPos As Integer, _
                                intSelFactor) As Single
    On Error GoTo ERR_HANDLE
    
    '--- �j���ܪ�attribute�ƥءA���^��99999 ---
    If intSelFactor > gintSelCount Then
        GetFactorValue = 99999
        Exit Function
    End If
    
    If gstrSelFactors(intSelFactor) = "BIAS" Then
        GetFactorValue = udtIndex(intPos).sngBias
    ElseIf gstrSelFactors(intSelFactor) = "MACD" Then
        GetFactorValue = udtIndex(intPos).sngMACD
    ElseIf gstrSelFactors(intSelFactor) = "PSY" Then
        GetFactorValue = udtIndex(intPos).sngPSY
    ElseIf gstrSelFactors(intSelFactor) = "RSI_L" Then
        GetFactorValue = udtIndex(intPos).sngRSI_L
    ElseIf gstrSelFactors(intSelFactor) = "RSI_S" Then
        GetFactorValue = udtIndex(intPos).sngRSI_S
    ElseIf gstrSelFactors(intSelFactor) = "WMS" Then
        GetFactorValue = udtIndex(intPos).sngWMS
    ElseIf gstrSelFactors(intSelFactor) = "K" Then
        GetFactorValue = udtIndex(intPos).sngK
    ElseIf gstrSelFactors(intSelFactor) = "D" Then
        GetFactorValue = udtIndex(intPos).sngD
'    ElseIf gstrSelFactors(intSelFactor) = "KDDis" Then
'        GetFactorValue = udtIndex(intPos).sngKDDis
    ElseIf gstrSelFactors(intSelFactor) = "MAPDis" Then
        GetFactorValue = udtIndex(intPos).sngMAPDis
'    ElseIf gstrSelFactors(intSelFactor) = "RSIDis" Then
'        GetFactorValue = udtIndex(intPos).sngRSIDis
    ElseIf gstrSelFactors(intSelFactor) = "MAP3" Then
        GetFactorValue = udtIndex(intPos).sngP3
    ElseIf gstrSelFactors(intSelFactor) = "MAP4" Then
        GetFactorValue = udtIndex(intPos).sngP4
    ElseIf gstrSelFactors(intSelFactor) = "MAP5" Then
        GetFactorValue = udtIndex(intPos).sngP5
    ElseIf gstrSelFactors(intSelFactor) = "MAP6" Then
        GetFactorValue = udtIndex(intPos).sngP6
    ElseIf gstrSelFactors(intSelFactor) = "MAP8" Then
        GetFactorValue = udtIndex(intPos).sngP8
    ElseIf gstrSelFactors(intSelFactor) = "MAP10" Then
        GetFactorValue = udtIndex(intPos).sngP10
    ElseIf gstrSelFactors(intSelFactor) = "MAP12" Then
        GetFactorValue = udtIndex(intPos).sngP12
    ElseIf gstrSelFactors(intSelFactor) = "MAP24" Then
        GetFactorValue = udtIndex(intPos).sngP24
    ElseIf gstrSelFactors(intSelFactor) = "MAP30" Then
        GetFactorValue = udtIndex(intPos).sngP30
'    ElseIf gstrSelFactors(intSelFactor) = "MAP48" Then
'        GetFactorValue = udtIndex(intPos).sngP48
    ElseIf gstrSelFactors(intSelFactor) = "MAP72" Then
        GetFactorValue = udtIndex(intPos).sngP72
    ElseIf gstrSelFactors(intSelFactor) = "MAP144" Then
        GetFactorValue = udtIndex(intPos).sngP144
    ElseIf gstrSelFactors(intSelFactor) = "MAP288" Then
        GetFactorValue = udtIndex(intPos).sngP288
    ElseIf gstrSelFactors(intSelFactor) = "DIF" Then
        GetFactorValue = udtIndex(intPos).sngDIF
    ElseIf gstrSelFactors(intSelFactor) = "DIF_MACD" Then
        GetFactorValue = udtIndex(intPos).sngDIF_MACD
'    ElseIf gstrSelFactors(intSelFactor) = "TAPI" Then
'        GetFactorValue = udtIndex(intPos).sngTAPI
'    ElseIf gstrSelFactors(intSelFactor) = "OBV" Then
'        GetFactorValue = udtIndex(intPos).sngOBV
    ElseIf gstrSelFactors(intSelFactor) = "VR" Then
        GetFactorValue = udtIndex(intPos).sngVR
    ElseIf gstrSelFactors(intSelFactor) = "CY" Then
        GetFactorValue = Str(Round(udtIndex(intPos).sngDIF_MACD, 2))
'    ElseIf gstrSelFactors(intSelFactor) = "AR" Then
'        GetFactorValue = udtIndex(intPos).sngAR
'    ElseIf gstrSelFactors(intSelFactor) = "BR" Then
'        GetFactorValue = udtIndex(intPos).sngBR
    ElseIf gstrSelFactors(intSelFactor) = "VOL24" Then
        GetFactorValue = udtIndex(intPos).sngVol24
    Else
        Err.Raise 10002
    End If
    
    Exit Function
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.GetFactorValue()] -- " & Err.Number & ":" & Err.Description & " -- �䤣��������쪺����", vbOKOnly
End Function


'***********************************************************************************
'* �p���intCount�C��ƪ�GRG
'* input param:
'*   udtGRG  �G�n�B�z�����(�s��C��Sector�����)
'*   udtGroup�Gmaybe no use ... 920907
'*   intCount�G�����n�p��(udtGRG)�����ơA��intCount�s�񪺬O���ƦC�����
'*
'* 920728�G���禡�O��ӧO��factors�@�_��GRG�B���E��
'* 920907�G�HGRC�����P�_�פ����
'***********************************************************************************
'Public Sub CalGRG2(ByRef udtGRG() As udtGRGIndex, ByRef udtGroup() As Boolean, _
'                    ByVal intCount As Integer)
'    Dim sngMax(8) As Single
'    Dim sngMin(8) As Single
'    Dim blnFlag As Boolean          ' ����Sector�O�_�w���ۦP�E�� (���=false)
'    Dim blnChangeFlag As Boolean    ' ����e��⦸�E���O�_�ۦP (�ۦP=true)
'    Dim udtGRGDiff() As udtGRGIndex
'    Dim sngGRGPrev() As Single
'    Dim i As Integer, j As Integer
'    Dim intLoop As Integer
'    Dim sngSumRo As Single
'
'    On Error GoTo ERR_HANDLE
'
'    blnFlag = True
'    ReDim udtGRGDiff(intCount)
'    ReDim sngGRGPrev(intCount)
'
'    While blnFlag
'        '--- initialize variables ---
'        For i = 1 To 8
'            sngMax(i) = 0
'            sngMin(i) = 1
'        Next
'
'        '--- �p��t�ǦC (intCount�x����ƦC�����) ---
'        For i = 1 To intCount - 1
'            udtGRGDiff(i).sngParam1 = Abs(udtGRG(intCount).sngParam1 - udtGRG(i).sngParam1)
'            udtGRGDiff(i).sngParam2 = Abs(udtGRG(intCount).sngParam2 - udtGRG(i).sngParam2)
'            udtGRGDiff(i).sngParam3 = Abs(udtGRG(intCount).sngParam3 - udtGRG(i).sngParam3)
'            udtGRGDiff(i).sngParam4 = Abs(udtGRG(intCount).sngParam4 - udtGRG(i).sngParam4)
'            udtGRGDiff(i).sngParam5 = Abs(udtGRG(intCount).sngParam5 - udtGRG(i).sngParam5)
'            udtGRGDiff(i).sngParam6 = Abs(udtGRG(intCount).sngParam6 - udtGRG(i).sngParam6)
'            udtGRGDiff(i).sngParam7 = Abs(udtGRG(intCount).sngParam7 - udtGRG(i).sngParam7)
'            udtGRGDiff(i).sngParam8 = Abs(udtGRG(intCount).sngParam8 - udtGRG(i).sngParam8)
'        Next
'        '--- �N���ƦC���ȲM��0 ---
'        With udtGRGDiff(i)
'            .sngGRG = 0
'            .sngParam1 = 0
'            .sngParam2 = 0
'            .sngParam3 = 0
'            .sngParam4 = 0
'            .sngParam5 = 0
'            .sngParam6 = 0
'            .sngParam7 = 0
'            .sngParam8 = 0
'        End With
'        '-------------------------------------------------------
'        '* ��X�U��Attribue���t�ǦC�̤j�Ȥγ̤p��
'        '* 920705 --> �Y����8��Attribute�n���B�z�K
'        '-------------------------------------------------------
'        Dim sngMax As Single    ' 930810 has bug
'        Dim sngMin As Single    ' 930810 has bug
'        For i = 1 To intCount - 1
'            With udtGRGDiff(i)
'                If .sngParam1 > sngMax(1) Then
'                    sngMax = .sngParam1
'                End If
'                If .sngParam1 < sngMin(1) Then
'                    sngMin = .sngParam1
'                End If
'                If .sngParam2 > sngMax(2) Then
'                    sngMax = .sngParam2
'                End If
'                If .sngParam2 < sngMin(2) Then
'                    sngMin = .sngParam2
'                End If
'                If .sngParam3 > sngMax(3) Then
'                    sngMax = .sngParam3
'                End If
'                If .sngParam3 < sngMin(3) Then
'                    sngMin = .sngParam3
'                End If
'                If .sngParam4 > sngMax(4) Then
'                    sngMax = .sngParam4
'                End If
'                If .sngParam4 < sngMin(4) Then
'                    sngMin = .sngParam4
'                End If
'                If .sngParam5 > sngMax(5) Then
'                    sngMax = .sngParam5
'                End If
'                If .sngParam5 < sngMin(5) Then
'                    sngMin = .sngParam5
'                End If
'                If .sngParam6 > sngMax(6) Then
'                    sngMax = .sngParam6
'                End If
'                If .sngParam6 < sngMin(6) Then
'                    sngMin = .sngParam6
'                End If
'                If .sngParam7 > sngMax(7) Then
'                    sngMax = .sngParam7
'                End If
'                If .sngParam7 < sngMin(7) Then
'                    sngMin = .sngParam7
'                End If
'                If .sngParam8 > sngMax(8) Then
'                    sngMax = .sngParam8
'                End If
'                If .sngParam8 < sngMin(8) Then
'                    sngMin = .sngParam8
'                End If
'            End With
'        Next
'        '--- �p��GRC ---
'        For i = 1 To intCount - 1
'            '--------------------------------------------------------------------
'            '* �ĥΤU�C�覡�AgsngRo �|�糧�B�⪺�v�T
'            '* �G�i�ǥѳ]�wgsngRo �ȨӤ���GRG����
'            '* 920727; ���Q��udtGroup�ӧP�_�B�z�X��attributes -- not implement
'            '--------------------------------------------------------------------
'            With udtGRGDiff(i)
'                If gintSelCount = 1 Then
'                    If (.sngParam1 + gsngRo * sngMax(1)) = 0 Then
'                        .sngParam1 = 0
'                    Else
'                        .sngParam1 = (sngMin(1) + gsngRo * sngMax(1)) / (.sngParam1 + gsngRo * sngMax(1))
'                    End If
'                ElseIf gintSelCount = 2 Then
'                    If (.sngParam1 + gsngRo * sngMax(1)) = 0 Then
'                        .sngParam1 = 0
'                    Else
'                        .sngParam1 = (sngMin(1) + gsngRo * sngMax(1)) / (.sngParam1 + gsngRo * sngMax(1))
'                    End If
'                    If (.sngParam2 + gsngRo * sngMax(2)) = 0 Then
'                        .sngParam2 = 0
'                    Else
'                        .sngParam2 = (sngMin(2) + gsngRo * sngMax(2)) / (.sngParam2 + gsngRo * sngMax(2))
'                    End If
'                ElseIf gintSelCount = 3 Then
'                    If (.sngParam1 + gsngRo * sngMax(1)) = 0 Then
'                        .sngParam1 = 0
'                    Else
'                        .sngParam1 = (sngMin(1) + gsngRo * sngMax(1)) / (.sngParam1 + gsngRo * sngMax(1))
'                    End If
'                    If (.sngParam2 + gsngRo * sngMax(2)) = 0 Then
'                        .sngParam2 = 0
'                    Else
'                        .sngParam2 = (sngMin(2) + gsngRo * sngMax(2)) / (.sngParam2 + gsngRo * sngMax(2))
'                    End If
'                    If (.sngParam3 + gsngRo * sngMax(3)) = 0 Then
'                        .sngParam3 = 0
'                    Else
'                        .sngParam3 = (sngMin(3) + gsngRo * sngMax(3)) / (.sngParam3 + gsngRo * sngMax(3))
'                    End If
'                ElseIf gintSelCount = 4 Then
'                    If (.sngParam1 + gsngRo * sngMax(1)) = 0 Then
'                        .sngParam1 = 0
'                    Else
'                        .sngParam1 = (sngMin(1) + gsngRo * sngMax(1)) / (.sngParam1 + gsngRo * sngMax(1))
'                    End If
'                    If (.sngParam2 + gsngRo * sngMax(2)) = 0 Then
'                        .sngParam2 = 0
'                    Else
'                        .sngParam2 = (sngMin(2) + gsngRo * sngMax(2)) / (.sngParam2 + gsngRo * sngMax(2))
'                    End If
'                    If (.sngParam3 + gsngRo * sngMax(3)) = 0 Then
'                        .sngParam3 = 0
'                    Else
'                        .sngParam3 = (sngMin(3) + gsngRo * sngMax(3)) / (.sngParam3 + gsngRo * sngMax(3))
'                    End If
'                    If (.sngParam4 + gsngRo * sngMax(4)) = 0 Then
'                        .sngParam4 = 0
'                    Else
'                        .sngParam4 = (sngMin(4) + gsngRo * sngMax(4)) / (.sngParam4 + gsngRo * sngMax(4))
'                    End If
'                ElseIf gintSelCount = 5 Then
'                    If (.sngParam1 + gsngRo * sngMax(1)) = 0 Then
'                        .sngParam1 = 0
'                    Else
'                        .sngParam1 = (sngMin(1) + gsngRo * sngMax(1)) / (.sngParam1 + gsngRo * sngMax(1))
'                    End If
'                    If (.sngParam2 + gsngRo * sngMax(2)) = 0 Then
'                        .sngParam2 = 0
'                    Else
'                        .sngParam2 = (sngMin(2) + gsngRo * sngMax(2)) / (.sngParam2 + gsngRo * sngMax(2))
'                    End If
'                    If (.sngParam3 + gsngRo * sngMax(3)) = 0 Then
'                        .sngParam3 = 0
'                    Else
'                        .sngParam3 = (sngMin(3) + gsngRo * sngMax(3)) / (.sngParam3 + gsngRo * sngMax(3))
'                    End If
'                    If (.sngParam4 + gsngRo * sngMax(4)) = 0 Then
'                        .sngParam4 = 0
'                    Else
'                        .sngParam4 = (sngMin(4) + gsngRo * sngMax(4)) / (.sngParam4 + gsngRo * sngMax(4))
'                    End If
'                    If (.sngParam5 + gsngRo * sngMax(5)) = 0 Then
'                        .sngParam5 = 0
'                    Else
'                        .sngParam5 = (sngMin(5) + gsngRo * sngMax(5)) / (.sngParam5 + gsngRo * sngMax(5))
'                    End If
'                ElseIf gintSelCount = 6 Then
'                    If (.sngParam1 + gsngRo * sngMax(1)) = 0 Then
'                        .sngParam1 = 0
'                    Else
'                        .sngParam1 = (sngMin(1) + gsngRo * sngMax(1)) / (.sngParam1 + gsngRo * sngMax(1))
'                    End If
'                    If (.sngParam2 + gsngRo * sngMax(2)) = 0 Then
'                        .sngParam2 = 0
'                    Else
'                        .sngParam2 = (sngMin(2) + gsngRo * sngMax(2)) / (.sngParam2 + gsngRo * sngMax(2))
'                    End If
'                    If (.sngParam3 + gsngRo * sngMax(3)) = 0 Then
'                        .sngParam3 = 0
'                    Else
'                        .sngParam3 = (sngMin(3) + gsngRo * sngMax(3)) / (.sngParam3 + gsngRo * sngMax(3))
'                    End If
'                    If (.sngParam4 + gsngRo * sngMax(4)) = 0 Then
'                        .sngParam4 = 0
'                    Else
'                        .sngParam4 = (sngMin(4) + gsngRo * sngMax(4)) / (.sngParam4 + gsngRo * sngMax(4))
'                    End If
'                    If (.sngParam5 + gsngRo * sngMax(5)) = 0 Then
'                        .sngParam5 = 0
'                    Else
'                        .sngParam5 = (sngMin(5) + gsngRo * sngMax(5)) / (.sngParam5 + gsngRo * sngMax(5))
'                    End If
'                    If (.sngParam6 + gsngRo * sngMax(6)) = 0 Then
'                        .sngParam6 = 0
'                    Else
'                        .sngParam6 = (sngMin(6) + gsngRo * sngMax(6)) / (.sngParam6 + gsngRo * sngMax(6))
'                    End If
'                ElseIf gintSelCount = 7 Then
'                    If (.sngParam1 + gsngRo * sngMax(1)) = 0 Then
'                        .sngParam1 = 0
'                    Else
'                        .sngParam1 = (sngMin(1) + gsngRo * sngMax(1)) / (.sngParam1 + gsngRo * sngMax(1))
'                    End If
'                    If (.sngParam2 + gsngRo * sngMax(2)) = 0 Then
'                        .sngParam2 = 0
'                    Else
'                        .sngParam2 = (sngMin(2) + gsngRo * sngMax(2)) / (.sngParam2 + gsngRo * sngMax(2))
'                    End If
'                    If (.sngParam3 + gsngRo * sngMax(3)) = 0 Then
'                        .sngParam3 = 0
'                    Else
'                        .sngParam3 = (sngMin(3) + gsngRo * sngMax(3)) / (.sngParam3 + gsngRo * sngMax(3))
'                    End If
'                    If (.sngParam4 + gsngRo * sngMax(4)) = 0 Then
'                        .sngParam4 = 0
'                    Else
'                        .sngParam4 = (sngMin(4) + gsngRo * sngMax(4)) / (.sngParam4 + gsngRo * sngMax(4))
'                    End If
'                    If (.sngParam5 + gsngRo * sngMax(5)) = 0 Then
'                        .sngParam5 = 0
'                    Else
'                        .sngParam5 = (sngMin(5) + gsngRo * sngMax(5)) / (.sngParam5 + gsngRo * sngMax(5))
'                    End If
'                    If (.sngParam6 + gsngRo * sngMax(6)) = 0 Then
'                        .sngParam6 = 0
'                    Else
'                        .sngParam6 = (sngMin(6) + gsngRo * sngMax(6)) / (.sngParam6 + gsngRo * sngMax(6))
'                    End If
'                    If (.sngParam7 + gsngRo * sngMax(7)) = 0 Then
'                        .sngParam7 = 0
'                    Else
'                        .sngParam7 = (sngMin(7) + gsngRo * sngMax(7)) / (.sngParam7 + gsngRo * sngMax(7))
'                    End If
'                Else
'                    If (.sngParam1 + gsngRo * sngMax(1)) = 0 Then
'                        .sngParam1 = 0
'                    Else
'                        .sngParam1 = (sngMin(1) + gsngRo * sngMax(1)) / (.sngParam1 + gsngRo * sngMax(1))
'                    End If
'                    If (.sngParam2 + gsngRo * sngMax(2)) = 0 Then
'                        .sngParam2 = 0
'                    Else
'                        .sngParam2 = (sngMin(2) + gsngRo * sngMax(2)) / (.sngParam2 + gsngRo * sngMax(2))
'                    End If
'                    If (.sngParam3 + gsngRo * sngMax(3)) = 0 Then
'                        .sngParam3 = 0
'                    Else
'                        .sngParam3 = (sngMin(3) + gsngRo * sngMax(3)) / (.sngParam3 + gsngRo * sngMax(3))
'                    End If
'                    If (.sngParam4 + gsngRo * sngMax(4)) = 0 Then
'                        .sngParam4 = 0
'                    Else
'                        .sngParam4 = (sngMin(4) + gsngRo * sngMax(4)) / (.sngParam4 + gsngRo * sngMax(4))
'                    End If
'                    If (.sngParam5 + gsngRo * sngMax(5)) = 0 Then
'                        .sngParam5 = 0
'                    Else
'                        .sngParam5 = (sngMin(5) + gsngRo * sngMax(5)) / (.sngParam5 + gsngRo * sngMax(5))
'                    End If
'                    If (.sngParam6 + gsngRo * sngMax(6)) = 0 Then
'                        .sngParam6 = 0
'                    Else
'                        .sngParam6 = (sngMin(6) + gsngRo * sngMax(6)) / (.sngParam6 + gsngRo * sngMax(6))
'                    End If
'                    If (.sngParam7 + gsngRo * sngMax(7)) = 0 Then
'                        .sngParam7 = 0
'                    Else
'                        .sngParam7 = (sngMin(7) + gsngRo * sngMax(7)) / (.sngParam7 + gsngRo * sngMax(7))
'                    End If
'                    If (.sngParam8 + gsngRo * sngMax(8)) = 0 Then
'                        .sngParam8 = 0
'                    Else
'                        .sngParam8 = (sngMin(8) + gsngRo * sngMax(8)) / (.sngParam8 + gsngRo * sngMax(8))
'                    End If
'                End If
'            End With
'        Next
'        '--------------------------------------------------------------------
'        '* �p��GRG
'        '* 920705 --> �ھ�attributes�B�z
'        '--------------------------------------------------------------------
'        For i = 1 To intCount - 1
'            With udtGRGDiff(i)
'                '--- �ĥΧ��v���覡 ---
''                .sngGRG = (.sngParam1 + .sngParam2 + .sngParam3 + .sngParam4 + .sngParam5 + .sngParam6 + .sngParam7 + .sngParam8) / 8
'                '--------------------------------------------------------------------
'                '* �ھڰѼƭӼƨM�w���樺��stmt
'                '--------------------------------------------------------------------
'                If gintSelCount = 1 Then
'                    .sngGRG = .sngParam1
'                ElseIf gintSelCount = 2 Then
'                    .sngGRG = (.sngParam1 + .sngParam2) / 2
'                ElseIf gintSelCount = 3 Then
'                    .sngGRG = (.sngParam1 + .sngParam2 + .sngParam3) / 3
'                ElseIf gintSelCount = 4 Then
'                    '--- 920706 : �ĥΧ��v�覡�A���A�ΡA����Υ[�v�覡 ---
'                    .sngGRG = (.sngParam1 + .sngParam2 + .sngParam3 + .sngParam4) / 4
''                    .sngGRG = .sngParam1 * 3 / 10 + .sngParam2 * 3 / 10 + .sngParam3 * 2 / 10 + .sngParam4 * 2 / 10
'                ElseIf gintSelCount = 5 Then
'                    '--- 920706 : �ĥΧ��v�覡�A���A�ΡA����Υ[�v�覡 ---
'                    .sngGRG = (.sngParam1 + .sngParam2 + .sngParam3 + .sngParam4 + .sngParam5) / 5
'                ElseIf gintSelCount = 6 Then
'                    '--- 920706 : �ĥΧ��v�覡�A���A�ΡA����Υ[�v�覡 ---
'                    .sngGRG = (.sngParam1 + .sngParam2 + .sngParam3 + .sngParam4 + .sngParam5 + .sngParam6) / 6
''                    .sngGRG = (.sngParam1 * 3 / 20 + .sngParam2 * 1 / 4 + .sngParam3 * 1 / 4 + .sngParam4 * 1 / 4 + .sngParam5 * 1 / 20 + .sngParam6 * 1 / 20)
'                ElseIf gintSelCount = 7 Then
'                    .sngGRG = (.sngParam1 + .sngParam2 + .sngParam3 + .sngParam4 + .sngParam5 + .sngParam6 + .sngParam7) / 7
'                Else: gintSelCount = 8
'                    .sngGRG = (.sngParam1 + .sngParam2 + .sngParam3 + .sngParam4 + .sngParam5 + .sngParam6 + .sngParam7 + .sngParam8) / 8
''                    .sngGRG = (.sngParam1 * 3 / 21 + .sngParam2 * 3 / 21 + .sngParam3 * 2 / 21 + .sngParam4 * 2 / 21 * 3 / 21 + .sngParam5 * 2 / 21 + .sngParam6 * 3 / 21 + .sngParam7 * 3 / 21 + .sngParam8 * 3 / 21)
'                End If
'            End With
'        Next
'
'        '--------------------------------------------------------------------
'        '* �E�����R
'        '--------------------------------------------------------------------
'        sngSumRo = 0            ' �O���j��֭Ȫ�����
'        blnChangeFlag = True    ' �Y�O�����ѦҼƦC�����󦹦����ѦҼƦC�K
'        For i = 1 To intCount - 1
'            With udtGRGDiff(i)
'                If .sngGRG >= gsngFa Then
'                    ' intCount�O���V���ƦC��m
''                    udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
''                    udtGRGDiff(intCount).sngParam2 = udtGRGDiff(intCount).sngParam2 + .sngParam2 * .sngGRG
''                    udtGRGDiff(intCount).sngParam3 = udtGRGDiff(intCount).sngParam3 + .sngParam3 * .sngGRG
''                    udtGRGDiff(intCount).sngParam4 = udtGRGDiff(intCount).sngParam4 + .sngParam4 * .sngGRG
''                    udtGRGDiff(intCount).sngParam5 = udtGRGDiff(intCount).sngParam5 + .sngParam5 * .sngGRG
''                    udtGRGDiff(intCount).sngParam6 = udtGRGDiff(intCount).sngParam6 + .sngParam6 * .sngGRG
''                    udtGRGDiff(intCount).sngParam7 = udtGRGDiff(intCount).sngParam7 + .sngParam7 * .sngGRG
''                    udtGRGDiff(intCount).sngParam8 = udtGRGDiff(intCount).sngParam8 + .sngParam8 * .sngGRG
'                    '--------------------------------------------------------------------
'                    '* �ھکҿ諸Attributes�ƥب�summarize GRG
'                    '--------------------------------------------------------------------
'                    If gintSelCount = 1 Then
'                        udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
'                    ElseIf gintSelCount = 2 Then
'                        udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
'                        udtGRGDiff(intCount).sngParam2 = udtGRGDiff(intCount).sngParam2 + .sngParam2 * .sngGRG
'                    ElseIf gintSelCount = 3 Then
'                        udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
'                        udtGRGDiff(intCount).sngParam2 = udtGRGDiff(intCount).sngParam2 + .sngParam2 * .sngGRG
'                        udtGRGDiff(intCount).sngParam3 = udtGRGDiff(intCount).sngParam3 + .sngParam3 * .sngGRG
'                    ElseIf gintSelCount = 4 Then
'                        udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
'                        udtGRGDiff(intCount).sngParam2 = udtGRGDiff(intCount).sngParam2 + .sngParam2 * .sngGRG
'                        udtGRGDiff(intCount).sngParam3 = udtGRGDiff(intCount).sngParam3 + .sngParam3 * .sngGRG
'                        udtGRGDiff(intCount).sngParam4 = udtGRGDiff(intCount).sngParam4 + .sngParam4 * .sngGRG
'                    ElseIf gintSelCount = 5 Then
'                        udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
'                        udtGRGDiff(intCount).sngParam2 = udtGRGDiff(intCount).sngParam2 + .sngParam2 * .sngGRG
'                        udtGRGDiff(intCount).sngParam3 = udtGRGDiff(intCount).sngParam3 + .sngParam3 * .sngGRG
'                        udtGRGDiff(intCount).sngParam4 = udtGRGDiff(intCount).sngParam4 + .sngParam4 * .sngGRG
'                        udtGRGDiff(intCount).sngParam5 = udtGRGDiff(intCount).sngParam5 + .sngParam5 * .sngGRG
'                    ElseIf gintSelCount = 6 Then
'                        udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
'                        udtGRGDiff(intCount).sngParam2 = udtGRGDiff(intCount).sngParam2 + .sngParam2 * .sngGRG
'                        udtGRGDiff(intCount).sngParam3 = udtGRGDiff(intCount).sngParam3 + .sngParam3 * .sngGRG
'                        udtGRGDiff(intCount).sngParam4 = udtGRGDiff(intCount).sngParam4 + .sngParam4 * .sngGRG
'                        udtGRGDiff(intCount).sngParam5 = udtGRGDiff(intCount).sngParam5 + .sngParam5 * .sngGRG
'                        udtGRGDiff(intCount).sngParam6 = udtGRGDiff(intCount).sngParam6 + .sngParam6 * .sngGRG
'                    ElseIf gintSelCount = 7 Then
'                        udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
'                        udtGRGDiff(intCount).sngParam2 = udtGRGDiff(intCount).sngParam2 + .sngParam2 * .sngGRG
'                        udtGRGDiff(intCount).sngParam3 = udtGRGDiff(intCount).sngParam3 + .sngParam3 * .sngGRG
'                        udtGRGDiff(intCount).sngParam4 = udtGRGDiff(intCount).sngParam4 + .sngParam4 * .sngGRG
'                        udtGRGDiff(intCount).sngParam5 = udtGRGDiff(intCount).sngParam5 + .sngParam5 * .sngGRG
'                        udtGRGDiff(intCount).sngParam6 = udtGRGDiff(intCount).sngParam6 + .sngParam6 * .sngGRG
'                        udtGRGDiff(intCount).sngParam7 = udtGRGDiff(intCount).sngParam7 + .sngParam7 * .sngGRG
'                    ElseIf gintSelCount = 8 Then
'                        udtGRGDiff(intCount).sngParam1 = udtGRGDiff(intCount).sngParam1 + .sngParam1 * .sngGRG
'                        udtGRGDiff(intCount).sngParam2 = udtGRGDiff(intCount).sngParam2 + .sngParam2 * .sngGRG
'                        udtGRGDiff(intCount).sngParam3 = udtGRGDiff(intCount).sngParam3 + .sngParam3 * .sngGRG
'                        udtGRGDiff(intCount).sngParam4 = udtGRGDiff(intCount).sngParam4 + .sngParam4 * .sngGRG
'                        udtGRGDiff(intCount).sngParam5 = udtGRGDiff(intCount).sngParam5 + .sngParam5 * .sngGRG
'                        udtGRGDiff(intCount).sngParam6 = udtGRGDiff(intCount).sngParam6 + .sngParam6 * .sngGRG
'                        udtGRGDiff(intCount).sngParam7 = udtGRGDiff(intCount).sngParam7 + .sngParam7 * .sngGRG
'                        udtGRGDiff(intCount).sngParam8 = udtGRGDiff(intCount).sngParam8 + .sngParam8 * .sngGRG
'                    End If
'                    sngSumRo = sngSumRo + 1
'                    '--------------------------------------------------------------------
'                    '* GRG > gsnFa �hudtGroup(i) = true --> ok
'                    '* else modified udtGroup(i) = true
'                    '--------------------------------------------------------------------
'                    If Not udtGroup(i) Then
'                        udtGroup(i) = True
'                        blnChangeFlag = False
'                    End If
'                Else
'                    If udtGroup(i) Then
'                        udtGroup(i) = False
'                        blnChangeFlag = False
'                    End If
'                End If
'            End With
'        Next
'
'        '--- �YblnChangeFlag = True�h���ܤG���p��һE������ƬҬ۵��A�h�i���������p�� ---
'        If blnChangeFlag Then
'            blnFlag = False
'        End If
'
'        '--- For Debug : ��ܪ��E������m ---
'        Debug.Print "---------------------------------------"
'        For i = 1 To intCount - 1
'            If udtGroup(i) = True Then
'                Debug.Print "i=" & i
'            End If
'            With udtGRG(i)
'                .sngGRG = udtGRGDiff(i).sngGRG
'            End With
'        Next
'        Debug.Print "---------------------------------------"
'
'        '--- ���ͥ��ƦC��� ---
'        With udtGRGDiff(intCount)
'            If sngSumRo = 0 Then
''                MsgBox "�S���ŦX�����"
'                Err.Raise 10001, "CalGRG", "�S���ŦX�����"
'            End If
'            .sngParam1 = .sngParam1 / sngSumRo
'            .sngParam2 = .sngParam2 / sngSumRo
'            .sngParam3 = .sngParam3 / sngSumRo
'            .sngParam4 = .sngParam4 / sngSumRo
'            .sngParam5 = .sngParam5 / sngSumRo
'            .sngParam6 = .sngParam6 / sngSumRo
'            .sngParam7 = .sngParam7 / sngSumRo
'            .sngParam8 = .sngParam8 / sngSumRo
'        End With
'
'        '--- �O���U���� ---
'        With udtGRG(intCount)
'            .sngParam1 = udtGRGDiff(intCount).sngParam1
'            .sngParam2 = udtGRGDiff(intCount).sngParam2
'            .sngParam3 = udtGRGDiff(intCount).sngParam3
'            .sngParam4 = udtGRGDiff(intCount).sngParam4
'            .sngParam5 = udtGRGDiff(intCount).sngParam5
'            .sngParam6 = udtGRGDiff(intCount).sngParam6
'            .sngParam7 = udtGRGDiff(intCount).sngParam7
'            .sngParam8 = udtGRGDiff(intCount).sngParam8
''            Debug.Print "the avergae heart parm1= " & .sngParam1 & ",parm2=" & .sngParam2 & ",parm3=" & .sngParam3 & ",parm4=" & .sngParam4 & ",parm5=" & .sngParam5 & ",parm6=" & .sngParam6 & ",parm7=" & .sngParam7 & ",parm8=" & .sngParam8
'        End With
'
''        ' For Debug : ��ܦ����B�⪺����
''        '             �W�L20���A�����U�Ӭݬ�����
''        intLoop = intLoop + 1
''        If intLoop > 100 Then
''            Debug.Print "intloop=" & intLoop
''            blnFlag = False
''        End If
'    Wend
'
'    Exit Sub
'
'
'ERR_HANDLE:
'    Select Case Err.Number
'        Case 10001
'            Debug.Print "[Method: CalGRG2()] -- Error Cluster"
''            Resume Next
'        Case Else
'            MsgBox "[Method: CalGRG2()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
'    End Select
'
'End Sub


'***********************************************************************************
'* �p���intCount�C��ƪ�GRG
'* input param:
'*   udtStock      �G�C��ѻ����
'*   udtIndex      �G�x�s�C��ѻ���ƪ����Ƹ��
'*   intStockNo    �G�C��ѻ���Ƶ���
'*   gudtClusterDat�G�E�����Gdataset
'*   intClusterCnt �G�E�����G����
'***********************************************************************************
Public Sub CalculateHighLowPoints(ByRef udtStock() As StockData, _
                                ByRef udtIndex() As IndexData, _
                                ByVal intStockNo As Integer, _
                                ByRef gudtClusterDat() As udtGRGIndex, _
                                ByVal intClusterCnt As Integer)
    Dim i As Integer
    
    On Error GoTo ERR_HANDLE
    
    For i = 1 To intStockNo
        '--- �H90�~�H�᪺��Ƭ�traingng set ---
        If udtStock(i).sngDate >= 900109 Then
'            udtIndex(i).sngGRG = CalGRGValue2(udtIndex, gudtClusterDat, i, 1)     ' �Ⱚ�I
            udtIndex(i).sngGRG = CalGRGValue2(udtIndex, gudtClusterDat, i, 2)      ' ��C�I
            '--- ���q -- 920924 ---
            If udtIndex(i).sngGRG > 0 Then
                '--- ���q���I�O�_���T -- 920924 ---
'                Call EvaluateTheResult(udtStock, udtIndex, i, intStockNo, 1)     ' ���q���I
                Call EvaluateTheResult(udtStock, udtIndex, i, intStockNo, 2)      ' ���q�C�I
            End If
        End If
    Next
    
    Exit Sub
    
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.CalculateHighLowPoints()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
End Sub


'***********************************************************************************
'* ����Method�G�p���intCount�C��ƪ�GRG�O�_�����I�ΧC�I�A�Y�O�h��ܥX��
'* input param:
'*   udtStock       �G�C��ѻ����
'*   udtIndex       �G�x�s�C��ѻ���ƪ����Ƹ��
'*   intStockNo     �G�C��ѻ���Ƶ���
'*   gudtClusterDat �G�E�����Gdataset
'*   intClusterCnt  �G�E�����G����
'*   intSelAttrCount�G�U�E�����G�ҿ�ΨӻE����Attributes���Ӽ�
'***********************************************************************************
Public Sub CalculateHighLowPoints2(ByRef udtStock() As StockData, _
                                ByRef udtIndex() As IndexData, _
                                ByVal intStockNo As Integer, _
                                ByRef gudtClusterDat() As udtGRGIndex, _
                                ByVal intClusterCnt As Integer, _
                                ByRef intSelAttrCount() As Integer)
    Dim i As Integer
    
    On Error GoTo ERR_HANDLE
    
    For i = 1 To intStockNo
        '--- �H90�~�H�᪺��Ƭ�Traingng Set ---
        If udtStock(i).sngDate >= 900101 Then
            '--- �p�Ⱚ�I ---
            If frmGeryExp.chkCalGRG.Value = 1 Then
                udtIndex(i).sngGRG = CalGRGValue2(udtIndex, gudtClusterDat, i, 1)
            End If
            '--- �p��C�I ---
            If frmGeryExp.chkCalGRG2.Value = 1 Then
                udtIndex(i).sngGRG = CalGRGValue2(udtIndex, gudtClusterDat, i, 2)
            End If
            
            '-----------------------------------
            '--- ���q���I�O�_���T -- 920924 ---
            '-----------------------------------
            If udtIndex(i).sngGRG > 0 Then
                '--- ���q���I ---
                If frmGeryExp.chkCalGRG.Value = 1 Then
                    Call EvaluateTheResult(udtStock, udtIndex, i, intStockNo, 1)
                End If
                '--- ���q�C�I ---
                If frmGeryExp.chkCalGRG2.Value = 1 Then
                    Call EvaluateTheResult(udtStock, udtIndex, i, intStockNo, 2)
                End If
            End If
        End If
    Next
    
    Exit Sub
    
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.CalculateHighLowPoints2()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
End Sub


'***********************************************************************************
'* �٭�E���X�Ӫ���
'* Input Param :
'*   udtClusterDat�G�E�����G������
'*   intPos       �G�Ӹ�ƪ���m
'***********************************************************************************
Public Sub RestoreData(ByRef udtClusterDat() As udtGRGIndex, _
                        ByVal intPos As Integer)
    On Error GoTo ERR_HANDLE
    
'''    With udtClusterDat(intPos)
'''        If frmGeryExp.chkSelAttr(0).Value = "1" Then
'''            .sngParam1 = (sngMax(1) - sngMin(1)) * .sngParam1 + sngMin(1)
'''        End If
'''        If frmGeryExp.chkSelAttr(1).Value = "1" Then
'''            .sngParam2 = (sngMax(2) - sngMin(2)) * .sngParam2 + sngMin(2)
'''        End If
'''        If frmGeryExp.chkSelAttr(2).Value = "1" Then
'''            .sngParam3 = (sngMax(3) - sngMin(3)) * .sngParam3 + sngMin(3)
'''        End If
'''        If frmGeryExp.chkSelAttr(3).Value = "1" Then
'''            .sngParam4 = (sngMax(4) - sngMin(4)) * .sngParam4 + sngMin(4)
'''        End If
'''        If frmGeryExp.chkSelAttr(4).Value = "1" Then
'''            .sngParam5 = (sngMax(5) - sngMin(5)) * .sngParam5 + sngMin(5)
'''        End If
'''        If frmGeryExp.chkSelAttr(5).Value = "1" Then
'''            .sngParam6 = (sngMax(6) - sngMin(6)) * .sngParam6 + sngMin(6)
'''        End If
'''        If frmGeryExp.chkSelAttr(6).Value = "1" Then
'''            .sngParam7 = (sngMax(7) - sngMin(7)) * .sngParam7 + sngMin(7)
'''        End If
'''        If frmGeryExp.chkSelAttr(7).Value = "1" Then
'''            .sngParam8 = (sngMax(8) - sngMin(8)) * .sngParam8 + sngMin(8)
'''        End If
'''    End With

    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.RestoreData()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
    
    Resume Next
End Sub





'***********************************************************************************
'* ���ư��e�B�z
'* Input Param.
'*   udtGRG  �G�n�B�z�����
'*   intCount�G�n�B�z����ƪ�����
'***********************************************************************************
Public Sub PreProcess2(ByRef udtGRG() As udtGRGIndex, ByVal intCount As Integer)
    Dim i As Integer
    Dim sngMax As Single, sngMin As Single

    On Error GoTo ERR_HANDLE
   ' 20080228 marked for complier...
'''    '--- Initialize Variables ---
'''    sngMax = -99999
'''    sngMin = 99999
'''
'''    '--------------------------------------------------------------------
'''    '* Find each Max value and Min value in each parameter
'''    '--------------------------------------------------------------------
'''    For i = 1 To intCount
'''        With udtGRG(i)
'''            If frmGeryExp.chkSelAttr(0).Value = "1" Then
'''                If sngMax < .sngParam1 Then
'''                    sngMax = .sngParam1
'''                End If
'''                If sngMin > .sngParam1 Then
'''                    sngMin = .sngParam1
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(1).Value = "1" Then
'''                If sngMax < .sngParam2 Then
'''                    sngMax = .sngParam2
'''                End If
'''                If sngMin > .sngParam2 Then
'''                    sngMin = .sngParam2
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(2).Value = "1" Then
'''                If sngMax < .sngParam3 Then
'''                    sngMax = .sngParam3
'''                End If
'''                If sngMin > .sngParam3 Then
'''                    sngMin = .sngParam3
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(3).Value = "1" Then
'''                If sngMax < .sngParam4 Then
'''                    sngMax = .sngParam4
'''                End If
'''                If sngMin > .sngParam4 Then
'''                    sngMin = .sngParam4
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(4).Value = "1" Then
'''                If sngMax < .sngParam5 Then
'''                    sngMax = .sngParam5
'''                End If
'''                If sngMin > .sngParam5 Then
'''                    sngMin = .sngParam5
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(5).Value = "1" Then
'''                If sngMax < .sngParam6 Then
'''                    sngMax = .sngParam6
'''                End If
'''                If sngMin > .sngParam6 Then
'''                    sngMin = .sngParam6
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(6).Value = "1" Then
'''                If sngMax < .sngParam7 Then
'''                    sngMax = .sngParam7
'''                End If
'''                If sngMin > .sngParam7 Then
'''                    sngMin = .sngParam7
'''                End If
'''            End If
'''            If frmGeryExp.chkSelAttr(7).Value = "1" Then
'''                If sngMax < .sngParam8 Then
'''                    sngMax = .sngParam8
'''                End If
'''                If sngMin > .sngParam8 Then
'''                    sngMin = .sngParam8
'''                End If
'''            End If
'''        End With
'''    Next
'''
'''    '--------------------------------------------------------------------
'''    '* ��Ȥ�
'''    '--------------------------------------------------------------------
'''    For i = 1 To intCount - 1
'''        With udtGRG(i)
''''            '--------------------------------------------------------------------
''''            '* gintSelFactorsMethod = 1 ���u��j�v
''''            '* gintSelFactorsMethod = 2 ���u��p�v
''''            '* gintSelFactorsMethod = 3 ���u��ءv
''''            '--------------------------------------------------------------------
''''            If frmGeryExp.chkSelAttr(0).Value = "1" Then
''''                If gintSelFactorsMethod(1) = 1 Then
''''                    .sngParam1 = (.sngParam1 - sngMin) / (sngMax - sngMin)
''''                ElseIf gintSelFactorsMethod(1) = 2 Then
''''                    .sngParam1 = (sngMax - .sngParam1) / (sngMax - sngMin)
''''                Else
''''                    .sngParam1 = 1 - Abs(.sngParam1 - udtGRG(intCount).sngParam1) / (IIf((sngMax - udtGRG(intCount).sngParam1 > udtGRG(intCount).sngParam1 - sngMin), sngMax - udtGRG(intCount).sngParam1, udtGRG(intCount).sngParam1 - sngMin))
''''                End If
''''            End If
''''
''''            If frmGeryExp.chkSelAttr(1).Value = "1" Then
''''                If gintSelFactorsMethod(2) = 1 Then
''''                    .sngParam2 = (.sngParam2 - sngMin) / (sngMax - sngMin)
''''                ElseIf gintSelFactorsMethod(2) = 2 Then
''''                    .sngParam2 = (sngMax - .sngParam2) / (sngMax - sngMin)
''''                Else
''''                    .sngParam2 = 1 - Abs(.sngParam2 - udtGRG(intCount).sngParam2) / (IIf((sngMax - udtGRG(intCount).sngParam2 > udtGRG(intCount).sngParam2 - sngMin), sngMax - udtGRG(intCount).sngParam2, udtGRG(intCount).sngParam2 - sngMin))
''''                End If
''''            End If
''''
''''            If frmGeryExp.chkSelAttr(2).Value = "1" Then
''''                If gintSelFactorsMethod(3) = 1 Then
''''                    .sngParam3 = (.sngParam3 - sngMin) / (sngMax - sngMin)
''''                ElseIf gintSelFactorsMethod(3) = 2 Then
''''                    .sngParam3 = (sngMax - .sngParam3) / (sngMax - sngMin)
''''                Else
''''                    .sngParam3 = 1 - Abs(.sngParam3 - udtGRG(intCount).sngParam3) / (IIf((sngMax - udtGRG(intCount).sngParam3 > udtGRG(intCount).sngParam3 - sngMin), sngMax - udtGRG(intCount).sngParam3, udtGRG(intCount).sngParam3 - sngMin))
''''                End If
''''            End If
''''
''''            If frmGeryExp.chkSelAttr(3).Value = "1" Then
''''                If gintSelFactorsMethod(4) = 1 Then
''''                    .sngParam4 = (.sngParam4 - sngMin) / (sngMax - sngMin)
''''                ElseIf gintSelFactorsMethod(4) = 2 Then
''''                    .sngParam4 = (sngMax - .sngParam4) / (sngMax - sngMin)
''''                Else
''''                    .sngParam4 = 1 - Abs(.sngParam4 - udtGRG(intCount).sngParam4) / (IIf((sngMax - udtGRG(intCount).sngParam4 > udtGRG(intCount).sngParam4 - sngMin), sngMax - udtGRG(intCount).sngParam4, udtGRG(intCount).sngParam4 - sngMin))
''''                End If
''''            End If
''''
''''            If frmGeryExp.chkSelAttr(4).Value = "1" Then
''''                If gintSelFactorsMethod(5) = 1 Then
''''                    .sngParam5 = (.sngParam5 - sngMin) / (sngMax - sngMin)
''''                ElseIf gintSelFactorsMethod(5) = 2 Then
''''                    .sngParam5 = (sngMax - .sngParam5) / (sngMax - sngMin)
''''                Else
''''                    .sngParam5 = 1 - Abs(.sngParam5 - udtGRG(intCount).sngParam5) / (IIf((sngMax - udtGRG(intCount).sngParam5 > udtGRG(intCount).sngParam5 - sngMin), sngMax - udtGRG(intCount).sngParam5, udtGRG(intCount).sngParam5 - sngMin))
''''                End If
''''            End If
''''
''''            If frmGeryExp.chkSelAttr(5).Value = "1" Then
''''                If gintSelFactorsMethod(6) = 1 Then
''''                    .sngParam6 = (.sngParam6 - sngMin) / (sngMax - sngMin)
''''                ElseIf gintSelFactorsMethod(6) = 2 Then
''''                    .sngParam6 = (sngMax - .sngParam6) / (sngMax - sngMin)
''''                Else
''''                    .sngParam6 = 1 - Abs(.sngParam6 - udtGRG(intCount).sngParam6) / (IIf((sngMax - udtGRG(intCount).sngParam6 > udtGRG(intCount).sngParam6 - sngMin), sngMax - udtGRG(intCount).sngParam6, udtGRG(intCount).sngParam6 - sngMin))
''''                End If
''''            End If
''''
''''            If frmGeryExp.chkSelAttr(6).Value = "1" Then
''''                If gintSelFactorsMethod(7) = 1 Then
''''                    .sngParam7 = (.sngParam7 - sngMin) / (sngMax - sngMin)
''''                ElseIf gintSelFactorsMethod(7) = 2 Then
''''                    .sngParam7 = (sngMax - .sngParam7) / (sngMax - sngMin)
''''                Else
''''                    .sngParam7 = 1 - Abs(.sngParam7 - udtGRG(intCount).sngParam7) / (IIf((sngMax - udtGRG(intCount).sngParam7 > udtGRG(intCount).sngParam7 - sngMin), sngMax - udtGRG(intCount).sngParam7, udtGRG(intCount).sngParam7 - sngMin))
''''                End If
''''            End If
''''
''''            If frmGeryExp.chkSelAttr(7).Value = "1" Then
''''                If gintSelFactorsMethod(8) = 1 Then
''''                    .sngParam8 = (.sngParam8 - sngMin) / (sngMax - sngMin)
''''                ElseIf gintSelFactorsMethod(8) = 2 Then
''''                    .sngParam8 = (sngMax - .sngParam8) / (sngMax - sngMin)
''''                Else
''''                    .sngParam8 = 1 - Abs(.sngParam8 - udtGRG(intCount).sngParam8) / (IIf((sngMax - udtGRG(intCount).sngParam8 > udtGRG(intCount).sngParam8 - sngMin), sngMax - udtGRG(intCount).sngParam8, udtGRG(intCount).sngParam8 - sngMin))
''''                End If
''''            End If
'''            ' �����אּ��سB�z
'''            .sngParam1 = 1 - Abs(.sngParam1 - udtGRG(intCount).sngParam1) / (IIf((sngMax - udtGRG(intCount).sngParam1 > udtGRG(intCount).sngParam1 - sngMin), sngMax - udtGRG(intCount).sngParam1, udtGRG(intCount).sngParam1 - sngMin))
'''            .sngParam2 = 1 - Abs(.sngParam2 - udtGRG(intCount).sngParam2) / (IIf((sngMax - udtGRG(intCount).sngParam2 > udtGRG(intCount).sngParam2 - sngMin), sngMax - udtGRG(intCount).sngParam2, udtGRG(intCount).sngParam2 - sngMin))
'''            .sngParam3 = 1 - Abs(.sngParam3 - udtGRG(intCount).sngParam3) / (IIf((sngMax - udtGRG(intCount).sngParam3 > udtGRG(intCount).sngParam3 - sngMin), sngMax - udtGRG(intCount).sngParam3, udtGRG(intCount).sngParam3 - sngMin))
'''            .sngParam4 = 1 - Abs(.sngParam4 - udtGRG(intCount).sngParam4) / (IIf((sngMax - udtGRG(intCount).sngParam4 > udtGRG(intCount).sngParam4 - sngMin), sngMax - udtGRG(intCount).sngParam4, udtGRG(intCount).sngParam4 - sngMin))
'''            .sngParam5 = 1 - Abs(.sngParam5 - udtGRG(intCount).sngParam5) / (IIf((sngMax - udtGRG(intCount).sngParam5 > udtGRG(intCount).sngParam5 - sngMin), sngMax - udtGRG(intCount).sngParam5, udtGRG(intCount).sngParam5 - sngMin))
'''            .sngParam6 = 1 - Abs(.sngParam6 - udtGRG(intCount).sngParam6) / (IIf((sngMax - udtGRG(intCount).sngParam6 > udtGRG(intCount).sngParam6 - sngMin), sngMax - udtGRG(intCount).sngParam6, udtGRG(intCount).sngParam6 - sngMin))
'''            .sngParam7 = 1 - Abs(.sngParam7 - udtGRG(intCount).sngParam7) / (IIf((sngMax - udtGRG(intCount).sngParam7 > udtGRG(intCount).sngParam7 - sngMin), sngMax - udtGRG(intCount).sngParam7, udtGRG(intCount).sngParam7 - sngMin))
'''            .sngParam8 = 1 - Abs(.sngParam8 - udtGRG(intCount).sngParam8) / (IIf((sngMax - udtGRG(intCount).sngParam8 > udtGRG(intCount).sngParam8 - sngMin), sngMax - udtGRG(intCount).sngParam8, udtGRG(intCount).sngParam8 - sngMin))
'''        End With
'''    Next
    
    Exit Sub
    
    
ERR_HANDLE:
    Select Case Err.Number
        Case 6
            Debug.Print "[GCFR_General_Module.PreProcess2()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
        Case Else
            MsgBox "[GCFR_General_Module.PreProcess2()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
    
    Err.Clear
    Resume Next
End Sub


'***********************************************************************************
'* �p��90�~01��01��H�᪺��� --
'* Input Param :
'*   udtStock  �G�x�s�C�骺�Ѳ����
'*   udtIndex  �G�x�s�C�骺���Ƹ��
'*   intPos    �G�nŪ��udtIndex�����@�����(�Y�Ҧb��m)
'*   intStockNo�GudtStock���`����
'*   intHighLow�G���q���I�άO�C�I (���I=1�B�C�I=0.5)
'* Return      �G�^�ǻP�Ҧ��E��DataSet��GRG���G���̰���
'*
'***********************************************************************************
Public Sub EvaluateTheResult(ByRef udtStock() As StockData, _
                            ByRef udtIndex() As IndexData, _
                            ByVal intPos As Integer, _
                            ByVal intStockNo As Integer, _
                            ByVal intHighLow As Integer)
    Dim intDayLimit As Integer
    Dim sngHighDate As Single
    Dim sngHighEndP As Single
    Dim sngLowDate As Single
    Dim sngLowEndP As Single
    Dim sngGetDate As Single
    Dim sngGetEndP As Single
    Dim sngDiff As Single
    Dim i As Integer
    
    On Error GoTo ERR_HANDLE
    
    '---------------------------------------------------
    '* Initialize Variables
    '---------------------------------------------------
    intDayLimit = frmGeryExp.txtDayLimit.Text
    sngHighDate = 0
    sngHighEndP = -99999
    sngLowDate = 0
    sngLowEndP = 99999
    sngGetDate = udtStock(intPos).sngDate
    sngGetEndP = udtStock(intPos).sngEndprice
    
    For i = 1 To intDayLimit
        If sngHighEndP < udtStock(intPos).sngEndprice Then
            sngHighDate = udtStock(intPos).sngDate
            sngHighEndP = udtStock(intPos).sngEndprice
        End If
        If sngLowEndP > udtStock(intPos).sngEndprice Then
            sngLowDate = udtStock(intPos).sngDate
            sngLowEndP = udtStock(intPos).sngEndprice
        End If
        
        If intPos < intStockNo Then
            intPos = intPos + 1
        End If
    Next
    
    sngDiff = Abs(sngHighEndP - sngLowEndP) * 10 / 100
    
    If sngGetEndP <= (sngHighEndP + sngDiff) Then
        Debug.Print "nice-date=," & sngGetDate & ", is ok" & "src end-price=," & sngGetEndP & ", high end-price=," & sngHighEndP & ",low end-price=," & sngLowEndP & ", sngDiff=," & sngDiff
    Else
        Debug.Print "fail-date=," & sngGetDate & ", is ok" & "src end-price=," & sngGetEndP & ", high end-price,=" & sngHighEndP & ",low end-price=," & sngLowEndP & ", sngDiff=," & sngDiff & ",fa-value=," & (sngHighEndP - sngDiff) & ", need-value=," & (sngGetEndP - (sngHighEndP - sngDiff))
    End If
 
    Exit Sub
    
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.EvaluateTheResult()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
End Sub


'***********************************************************************************
'* �p��90�~01��01��H�᪺��� -- �ϥ�GRG��k
'* Input Param :
'*   udtIndex        : �x�s�C�骺���Ƹ��
'*   gudtClusterDat  : �x�s�E�����G�����
'*   intPos          : �nŪ��udtIndex�����@�����(�Y�Ҧb��m)
'*  Return :�^�ǻP�Ҧ��E��dataset��GRG���G���̰���
'*
'***********************************************************************************
Public Function CalGRGValue2(ByRef udtIndex() As IndexData, _
                            ByRef gudtClusterDat() As udtGRGIndex, _
                            ByVal intPos As Integer, _
                            ByVal intHighLow As Integer) As Single
    Dim udtGRGDiff As udtGRGIndex                   ' �x��t�ǦC���ܼ�
    Dim M(8) As Single                              ' ���ƦC��attribute����
    Dim S(8) As Single                              ' �l�ƦC��attribute����
    Dim sngDiff(8) As Single                        ' �t�ǦC����
    Dim sngTestGRG(2) As udtGRGIndex                ' �ΰ��e�B�z���Ȧs�ܼ�
    Dim sngGRG As Single                            ' ����GRG�����G
    Dim sngPrevGRG As Single                        ' �e�@��GRG�����G
    Dim sngSumGRG As Single                         ' �U�����ܼƪ�GRC�X�p
    Dim intGRGMethod As Integer                     ' 1 ���ܥ�GRGa, 2 ���ܥ�GRGd
    Dim sngMax As Single, sngMin As Single          '
    Dim i As Integer, j As Integer, k As Integer    '
    ReDim gstrSelFactors(8)                         ' Redefine ����x�s��attributes��size
          
    On Error GoTo ERR_HANDLE
    
'''    '--------------------------------------------------------------------
'''    '* Initialize Variables
'''    '--------------------------------------------------------------------
'''    sngMax = -99999
'''    sngMin = 99999
'''    sngGRG = 0
'''    sngPrevGRG = 0
'''    i = 0
'''
'''    '--- ��ܻE������k ---
'''    If frmGeryExp.cboGRGMethod.Text = "GRGa" Then
'''        intGRGMethod = 1
'''    ElseIf frmGeryExp.cboGRGMethod.Text = "GRGd" Then
'''        intGRGMethod = 2
'''    Else
'''        Err.Raise 11000, "[CalGRGValue]", "�������աA�|����ܻE������k"
'''        Exit Function
'''    End If
'''
'''    '--- �YgintClusterCnt = 0 ���ܨS���E�����\ ---
'''    If gintClusterCnt = 0 Then
'''        Err.Raise 11000, "[CalGRGValue]", "�������աA�S���E�����\"
'''        Exit Function
'''    End If
'''    '--- �P�_�O�찪�I�ΧC�I ---
'''    If intHighLow = 1 Then          ' ���I
'''        If udtIndex(intPos).sngP24 < udtIndex(intPos).sngP72 Then
'''            Exit Function
'''        End If
'''    ElseIf intHighLow = 2 Then      ' �C�I
'''        If udtIndex(intPos).sngP24 > udtIndex(intPos).sngP72 Then
'''            Exit Function
'''        End If
'''    End If
'''
'''    '--- ���o�n������������� ---
''''    S(1) = GetFactorValue(udtIndex, intPos, 1)
''''    S(2) = GetFactorValue(udtIndex, intPos, 2)
''''    S(3) = GetFactorValue(udtIndex, intPos, 3)
''''    S(4) = GetFactorValue(udtIndex, intPos, 4)
''''    S(5) = GetFactorValue(udtIndex, intPos, 5)
''''    S(6) = GetFactorValue(udtIndex, intPos, 6)
''''    S(7) = GetFactorValue(udtIndex, intPos, 7)
''''    S(8) = GetFactorValue(udtIndex, intPos, 8)
'''    For i = 1 To gintClusterCnt     ' gintClusterCnt ���ܻE�����G���ƥ�
'''        '--- Initialize Variables ---
'''        sngMax = -99999
'''        sngMin = 99999
'''        sngSumGRG = 0
'''        gintSelCount = gintSelAttrCount(i)
'''        With gudtSelAttrs(i)
'''            '-------------------------------------------------------
'''            '* �N��i�����E�����d assign ��gstrSelFactors�ܼƤ��A
'''            '* ��Method:GetFactorValue()�P�_��
'''            '-------------------------------------------------------
'''            gstrSelFactors(1) = .strParam1
'''            gstrSelFactors(2) = .strParam2
'''            gstrSelFactors(3) = .strParam3
'''            gstrSelFactors(4) = .strParam4
'''            gstrSelFactors(5) = .strParam5
'''            gstrSelFactors(6) = .strParam6
'''            gstrSelFactors(7) = .strParam7
'''            gstrSelFactors(8) = .strParam8
'''            '--- ���o�n������������� ---
'''            S(1) = GetFactorValue(udtIndex, intPos, 1)
'''            S(2) = GetFactorValue(udtIndex, intPos, 2)
'''            S(3) = GetFactorValue(udtIndex, intPos, 3)
'''            S(4) = GetFactorValue(udtIndex, intPos, 4)
'''            S(5) = GetFactorValue(udtIndex, intPos, 5)
'''            S(6) = GetFactorValue(udtIndex, intPos, 6)
'''            S(7) = GetFactorValue(udtIndex, intPos, 7)
'''            S(8) = GetFactorValue(udtIndex, intPos, 8)
'''        End With
'''        '--- Assign���ƦC���Ȧ��ܼ�M�� ---
'''        M(1) = gudtClusterDat(i).sngParam1
'''        M(2) = gudtClusterDat(i).sngParam2
'''        M(3) = gudtClusterDat(i).sngParam3
'''        M(4) = gudtClusterDat(i).sngParam4
'''        M(5) = gudtClusterDat(i).sngParam5
'''        M(6) = gudtClusterDat(i).sngParam6
'''        M(7) = gudtClusterDat(i).sngParam7
'''        M(8) = gudtClusterDat(i).sngParam8
'''
'''        '-------------------------------------------------------------------
'''        '* ���o�t�ǦC
'''        '-------------------------------------------------------------------
'''        If gintSelCount < 2 Then
'''            Err.Raise 11001, "[CalGRGValue]", _
'''                        "��ܤ�attributes�ӼƤ��o�p�󢱡A�_�h�L�kGRG"
'''        Else
'''            If intGRGMethod = 1 Then
'''                '--- �p��U��attributes�������n -- For GRGa ---
'''                For j = 1 To gintSelCount - 1
'''                    If (M(j + 1) - S(j + 1)) * (M(j) - S(j)) >= 0 Then
'''                        sngDiff(j) = (Abs(M(j + 1) - S(j + 1)) + Abs(M(j) - S(j))) / 2
'''                    Else
'''                        sngDiff(j) = (Abs(M(j + 1) - S(j + 1)) * Abs(M(j + 1) - S(j + 1)) + Abs(M(j) - S(j)) * Abs(M(j) - S(j))) / (2 * (Abs(M(j + 1) - S(j + 1)) + Abs(M(j) - S(j))))
'''                    End If
'''                Next
'''            ElseIf intGRGMethod = 2 Then
'''                '--- �p��U��attributes�����Z�� -- For GRGd ---
'''                For j = 1 To gintSelCount
'''                    sngDiff(j) = Abs(M(j) - S(j))
'''                Next
'''            End If
'''        End If
'''        '--------------------------------------------------------------------
'''        '* ��X�̤j�Ȥγ̤p��
'''        '--------------------------------------------------------------------
'''        If intGRGMethod = 1 Then
'''            For j = 1 To gintSelCount - 1
'''                If sngDiff(j) > sngMax Then
'''                    sngMax = sngDiff(j)
'''                End If
'''                If sngDiff(j) < sngMin Then
'''                    sngMin = sngDiff(j)
'''                End If
'''            Next
'''        ElseIf intGRGMethod = 2 Then
'''            '--- ��X�t�ǦC�����̤j�Ȥγ̤p�� ---
'''            For j = 1 To gintSelCount
'''                If sngDiff(j) > sngMax Then
'''                    sngMax = sngDiff(j)
'''                End If
'''                If sngDiff(j) < sngMin Then
'''                    sngMin = sngDiff(j)
'''                End If
'''            Next
'''        End If
'''        '--------------------------------------------------------------------
'''        '* �p��GRC
'''        '--------------------------------------------------------------------
'''        If intGRGMethod = 1 Then
'''            '--- Mthod 1 : Use GRGa �p��U��attributes�������n ---
'''            For j = 1 To gintSelCount - 1
'''                If (sngMax + sngDiff(j)) = 0 Then
'''                    sngDiff(j) = 1
'''                Else
'''                    sngDiff(j) = (sngMax * gsngRo) / (sngDiff(j) + sngMax * gsngRo)
'''                End If
'''            Next
'''        ElseIf intGRGMethod = 2 Then
'''            '--- Method 2 : Use GRGd �p��U��attributes�����Z�� ---
'''            With gudtSelAttrs(i)
'''                If Len(.strParam1) > 0 Then
'''                    If (sngDiff(1) + gsngRo * sngMax) = 0 Then
'''                        sngDiff(1) = 0
'''                    Else
'''                        sngDiff(1) = (sngMin + gsngRo * sngMax) / (sngDiff(1) + gsngRo * sngMax)
'''                    End If
'''                End If
'''                If Len(.strParam2) > 0 Then
'''                    If (sngDiff(2) + gsngRo * sngMax) = 0 Then
'''                        sngDiff(2) = 0
'''                    Else
'''                        sngDiff(2) = (sngMin + gsngRo * sngMax) / (sngDiff(2) + gsngRo * sngMax)
'''                    End If
'''                End If
'''                If Len(.strParam3) > 0 Then
'''                    If (sngDiff(3) + gsngRo * sngMax) = 0 Then
'''                        sngDiff(3) = 0
'''                    Else
'''                        sngDiff(3) = (sngMin + gsngRo * sngMax) / (sngDiff(3) + gsngRo * sngMax)
'''                    End If
'''                End If
'''                If Len(.strParam4) > 0 Then
'''                    If (sngDiff(4) + gsngRo * sngMax) = 0 Then
'''                        sngDiff(4) = 0
'''                    Else
'''                        sngDiff(4) = (sngMin + gsngRo * sngMax) / (sngDiff(4) + gsngRo * sngMax)
'''                    End If
'''                End If
'''                If Len(.strParam5) > 0 Then
'''                    If (sngDiff(5) + gsngRo * sngMax) = 0 Then
'''                        sngDiff(5) = 0
'''                    Else
'''                        sngDiff(5) = (sngMin + gsngRo * sngMax) / (sngDiff(5) + gsngRo * sngMax)
'''                    End If
'''                End If
'''                If Len(.strParam6) > 0 Then
'''                    If (sngDiff(6) + gsngRo * sngMax) = 0 Then
'''                        sngDiff(6) = 0
'''                    Else
'''                        sngDiff(6) = (sngMin + gsngRo * sngMax) / (sngDiff(6) + gsngRo * sngMax)
'''                    End If
'''                End If
'''                If Len(.strParam7) > 0 Then
'''                    If (sngDiff(7) + gsngRo * sngMax) = 0 Then
'''                        sngDiff(7) = 0
'''                    Else
'''                        sngDiff(7) = (sngMin + gsngRo * sngMax) / (sngDiff(7) + gsngRo * sngMax)
'''                    End If
'''                End If
'''                If Len(.strParam8) > 0 Then
'''                    If (sngDiff(8) + gsngRo * sngMax) = 0 Then
'''                        sngDiff(8) = 0
'''                    Else
'''                        sngDiff(8) = (sngMin + gsngRo * sngMax) / (sngDiff(8) + gsngRo * sngMax)
'''                    End If
'''                End If
'''            End With
'''            '--------------------------------------------------------------------
'''            '* �p��GRG
'''            '--------------------------------------------------------------------
'''            If intGRGMethod = 1 Then
'''                '--- For GRGa ---
'''                For j = 1 To gintSelCount - 1
'''                    sngSumGRG = sngSumGRG + sngDiff(j)
'''                Next
'''                sngGRG = sngSumGRG / (gintSelCount - 1)
'''            ElseIf intGRGMethod = 2 Then
'''                '--- For GRGd ---
'''                For j = 1 To gintSelCount
'''                    sngSumGRG = sngSumGRG + sngDiff(j)
'''                Next
'''                sngGRG = sngSumGRG / gintSelCount
'''            End If
'''
'''            '--- ��X�P�Ҧ����ƦC�B�⤤�̤j���� ---
'''            If sngGRG > sngPrevGRG Then
'''                sngPrevGRG = sngGRG
'''            End If
'''        End If
'''    Next
'''
'''    '--------------------------------------------------------------------
'''    '* �Ǧ^�B��᪺GRG���G
'''    '--------------------------------------------------------------------
'''    If sngGRG >= gsngCompFa Then
'''        '--- �Ǧ^���G ---
'''        CalGRGValue2 = sngGRG
'''    Else
'''        CalGRGValue2 = 0
'''    End If
           
    Exit Function
   
    
ERR_HANDLE:
    Select Case Err.Number
        Case 11001
            MsgBox "[GCFR_General_Module.CalGRGValue2()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
            Err.Raise11001
            Exit Function
        Case Else
            MsgBox "[GCFR_General_Module.CalGRGValue2()], Err-Number= " & Err.Number & ", Err-Desc= " & Err.Description, vbOKOnly
            Err.Raise 11001
            Exit Function
    End Select
End Function


' 921221 -- Modified -- Not Finished
'***********************************************************************************
'*
'***********************************************************************************
Sub CaluateGRGs(ByRef udtStock() As StockData, ByRef udtIndex() As IndexData, _
                ByVal intDayIndex As Integer, ByVal sngBegDate As Single, _
                ByVal sngEndDate As Single, ByVal intDay As Integer, _
                ByVal strIndex As String)
    Dim sngGRGDiff() As Single
    Dim sngGRGRo() As Single
    Dim sngRoSum As Single
    Dim sngGRG As Single
    Dim i As Integer
    Dim j As Integer
    Dim intSize As Integer
    Dim intBegPos As Integer    ' �p��_�l��m
    Dim intEndPos As Integer    ' �p�⵲����m
    Dim sngMax As Single
    Dim sngMin As Single
    
    On Error GoTo ERR_HANDLE
    
    '--- Initialize Variables ---
    intSize = 0
    i = 1
    sngMax = 0
    sngMin = 9999
    
    While ((udtStock(i).sngDate <= sngEndDate) And (i < intDayIndex))
        '--- �O���_�l��m ---
        If udtStock(i).sngDate = sngBegDate Then
            intBegPos = i
        End If
        '--- �O��������m ---
        If udtStock(i).sngDate = sngEndDate Then
            intEndPos = i
        End If
        '--- �O��Size ---
        If (udtStock(i).sngDate >= sngBegDate) And (udtStock(i).sngDate <= sngEndDate) Then
            intSize = intSize + 1
        End If

        i = i + 1
    Wend
    
    ReDim sngGRGDiff(intSize)
    ReDim sngGRGRo(intSize)
    j = 1
    For i = intBegPos To intEndPos - 1
        '--- �p��GRG Difference ---
        If strIndex = "PSY" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngPSY - udtIndex(i).sngPSY))
        ElseIf strIndex = "WMS" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngWMS - udtIndex(i).sngWMS))
        ElseIf strIndex = "K" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngK - udtIndex(i).sngK))
        ElseIf strIndex = "D" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngD - udtIndex(i).sngD))
        ElseIf strIndex = "EMA_S" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngDIF - udtIndex(i).sngDIF))
        ElseIf strIndex = "EMA_L" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngDIF - udtIndex(i).sngDIF))
        ElseIf strIndex = "MACD" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngMACD - udtIndex(i).sngMACD))
        ElseIf strIndex = "RSI_S" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngRSI_S - udtIndex(i).sngRSI_S))
        ElseIf strIndex = "RSI_L" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngRSI_L - udtIndex(i).sngRSI_L))
        ElseIf strIndex = "BIAS" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngBias - udtIndex(i).sngBias))
'''''        ElseIf strIndex = "AR" Then
'''''            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngAR - udtIndex(i).sngAR))
'''''        ElseIf strIndex = "BR" Then
'''''            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngBR - udtIndex(i).sngBR))
'''''        ElseIf strIndex = "OBV" Then
'''''            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngOBV - udtIndex(i).sngOBV))
'''''        ElseIf strIndex = "TAPI" Then
'''''            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngTAPI - udtIndex(i).sngTAPI))
        ElseIf strIndex = "VR" Then
            sngGRGDiff(j) = Abs((udtStock(i + 1).sngEndprice - udtStock(i).sngEndprice) - (udtIndex(i + 1).sngVR - udtIndex(i).sngVR))
        Else
            MsgBox "�S���ŦX������", vbOKOnly
        End If
        j = j + 1
    Next
    
    For i = 1 To intSize
        If sngMax < sngGRGDiff(i) Then
            sngMax = sngGRGDiff(i)
        End If
        If sngMin > sngGRGDiff(i) Then
            sngMin = sngGRGDiff(i)
        End If
    Next
    
    For i = 1 To intSize - 1
        sngGRGRo(i) = (sngMin + sngMax) / (sngGRGDiff(i) + sngMax)
    Next
    
    For i = 1 To intSize - 1
        sngRoSum = sngRoSum + sngGRGRo(i)
    Next
    
    sngGRG = sngRoSum / (intSize - 1)
    
    If gsngTestGRG < sngGRG Then
        gsngTestGRG = sngGRG
        frmGeryExp.cboIndDays.Text = intDay
    End If
       
    frmGeryExp.txtGRGResults.Text = "Day-index= " & intDay & ", snggrg=" & sngGRG & vbCrLf & frmGeryExp.txtGRGResults.Text
    
    Exit Sub
    
ERR_HANDLE:
'    MsgBox "[Method: CaluateGRGs()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    Debug.Print "[GCFR_General_Module.CaluateGRGs()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
End Sub



'***************************************************************************************************
'* ��    ��: �Q�ΦǻE����k�A��X�C��Sector(Use CY split)�������C�I
'* ��J�Ѽ�: udtStock  : �C��ѻ����
'*           udtIndex  �G�x�s�����Ƹ��
'*           intStockNo�G��Ƶ���
'*           strStartDT�G�ǤJ����ư_�l���
'*           strEndDT  �G�ǤJ����Ƶ������
'* ��X�Ѽ�: �L
'* ��    ��: 1.00: 20041214 �s�W
'*           1.10: 20050604 Modified
'***************************************************************************************************
Public Sub GetHighLowPoints4CY(ByRef udtStock() As StockData, _
                            ByRef udtIndex() As IndexData, _
                            ByVal intStockNo As Integer, _
                            ByVal strStartDT As String, _
                            ByVal strEndDT As String)
    Dim intCurrentPos As Integer    ' �O���ثe���Ъ���m
    Dim intBegPos As Integer        ' �O����Sector���_�l��m
    Dim intEndPos As Integer        ' �O���U�@��Sector���_�l��m
    Dim sngFlag As Single           ' �O�������n�E�����O���I�ΧC�I
    Dim udtGRG() As udtGRGIndex     ' �x�s�n���E�������
    Dim udtGroup() As Boolean       ' �O���O���X����ƻE����(�C)�I
    Dim intMPos As Integer          ' �O�����E��������(�C)�I����m
    Dim i As Integer
    Dim j As Integer
    
    On Error GoTo ERR_HANDLE
    
    '--- Initialize Variables ---
    ReDim gudtClusterDat(100)   ' �O���C��sector�̫�E�����G���� (�̦h�i�O100��)
    ReDim gudtCYSHDat(50)
    ReDim gudtCYSLDat(50)
    intCurrentPos = 1
    gintCYSHCount = 1
    gintCYSLCount = 1
    '--- Reset gudtCYHDat and gudtCYSLDat ---
    For i = 1 To 50
        With gudtCYSHDat(i)
            .sngDate = 0
            .sngGRG = 0
            .sngMax = 0
            .sngMin = 0
            .sngParam1 = 0
            .sngParam2 = 0
            .sngParam3 = 0
            .sngParam4 = 0
            .sngParam5 = 0
            .sngParam6 = 0
            .sngParam7 = 0
            .sngParam8 = 0
        End With
        With gudtCYSLDat(i)
            .sngDate = 0
            .sngGRG = 0
            .sngMax = 0
            .sngMin = 0
            .sngParam1 = 0
            .sngParam2 = 0
            .sngParam3 = 0
            .sngParam4 = 0
            .sngParam5 = 0
            .sngParam6 = 0
            .sngParam7 = 0
            .sngParam8 = 0
        End With
    Next
    
    '===================================================================
    '* �u�B�zLearning Set����
    '===================================================================
    While intCurrentPos < intStockNo
        If udtStock(intCurrentPos).sngDate >= LEARN_START_DATE And _
            udtStock(intCurrentPos).sngDate <= LEARN_END_DATE Then
            intBegPos = intCurrentPos
            intEndPos = intCurrentPos
            sngFlag = udtIndex(intBegPos).sngSector
            
            While (sngFlag = udtIndex(intEndPos).sngSector) And (intEndPos < intStockNo)
                If sngFlag = udtIndex(intEndPos).sngSector Then
                    intEndPos = intEndPos + 1
                End If
            Wend
            intCurrentPos = intEndPos - 1           ' �O���U�@�ӭn�B�z��Sector
            ReDim udtGroup(intEndPos - intBegPos)   ' �O����Sector���X���E���@�� (+1����]�O�]���̫�1���n�x�b���ƦC)
            ReDim udtGRG(intEndPos - intBegPos)     ' �x�s��Sector���E�����
            j = 1
            
            '===================================================================
            '* �b�����R�e�A�n���O�Ҧ����Э��s�p��
            '* �ثe���I�P�C�I�U�ۦ��@�M�ۤw�����ФѼƪ��O��
            '===================================================================
            If sngFlag = 1 Then
                PSY_No = 13
                WMS_No = 9
                KD_No = 9
                MACD_No = 24
                EMA_S = 12
                EMA_L = 26
                RSI_S = 6
                RSI_L = 12
                Bias_No = 10
                VR_NO = 12
                OBV_No = 12
                TAPI_No = 12
                AR_No = 12
            Else
                PSY_No = 13
                WMS_No = 9
                KD_No = 9
                MACD_No = 24
                EMA_S = 12
                EMA_L = 26
                RSI_S = 6
                RSI_L = 6
                Bias_No = 24
                VR_NO = 12
                OBV_No = 12
                TAPI_No = 12
                AR_No = 12
            End If
            Call subCalculateIndex(gudtStockDay, gudtIndexDay, gintDayIndex)
            Call subCalculateIndex(gudtStockWeek, gudtIndexWeek, gintWeekIndex)
            Call subCalculateIndex(gudtStockMonth, gudtIndexMonth, gintMonthIndex)
            
            '--- �N�����n���R��udtIndex()���assign to udtGRG() ---
            For i = intBegPos To intEndPos - 1
                udtGRG(j).sngDate = udtStock(i).sngDate
                udtGRG(j).sngParam1 = GetAttributesValue4CY(udtIndex, i, 1, sngFlag)
                udtGRG(j).sngParam2 = GetAttributesValue4CY(udtIndex, i, 2, sngFlag)
                udtGRG(j).sngParam3 = GetAttributesValue4CY(udtIndex, i, 3, sngFlag)
                udtGRG(j).sngParam4 = GetAttributesValue4CY(udtIndex, i, 4, sngFlag)
                udtGRG(j).sngParam5 = GetAttributesValue4CY(udtIndex, i, 5, sngFlag)
                udtGRG(j).sngParam6 = GetAttributesValue4CY(udtIndex, i, 6, sngFlag)
                udtGRG(j).sngParam7 = GetAttributesValue4CY(udtIndex, i, 7, sngFlag)
                udtGRG(j).sngParam8 = GetAttributesValue4CY(udtIndex, i, 8, sngFlag)
                j = j + 1
            Next
            '--- ��X�����RSector's���ƦC�ñN��assign��array���̫�@�C ---
            intMPos = FindHighLowDate(udtStock, intBegPos, intEndPos - 1, sngFlag)
            udtGRG(intEndPos - intBegPos).sngDate = udtStock(intMPos).sngDate
            udtGRG(intEndPos - intBegPos).sngParam1 = GetAttributesValue4CY(udtIndex, intMPos, 1, sngFlag)
            udtGRG(intEndPos - intBegPos).sngParam2 = GetAttributesValue4CY(udtIndex, intMPos, 2, sngFlag)
            udtGRG(intEndPos - intBegPos).sngParam3 = GetAttributesValue4CY(udtIndex, intMPos, 3, sngFlag)
            udtGRG(intEndPos - intBegPos).sngParam4 = GetAttributesValue4CY(udtIndex, intMPos, 4, sngFlag)
            udtGRG(intEndPos - intBegPos).sngParam5 = GetAttributesValue4CY(udtIndex, intMPos, 5, sngFlag)
            udtGRG(intEndPos - intBegPos).sngParam6 = GetAttributesValue4CY(udtIndex, intMPos, 6, sngFlag)
            udtGRG(intEndPos - intBegPos).sngParam7 = GetAttributesValue4CY(udtIndex, intMPos, 7, sngFlag)
            udtGRG(intEndPos - intBegPos).sngParam8 = GetAttributesValue4CY(udtIndex, intMPos, 8, sngFlag)
                       
            '--- ��ƫe�B�z ---
            Call PreProcess4CY(udtGRG, intEndPos - intBegPos, sngFlag)
            '--- �E�� ---
            Call CalculateGRG4CY(udtGRG, intEndPos - intBegPos, udtStock(intMPos).sngDate, sngFlag)
            
            '--- �E����B�z ---
            '===================================================================
            '* �O���U�o���E�������G --
            '===================================================================
            If udtGRG(UBound(udtGRG)).sngGRG <> -1 Then
                If sngFlag = 1 Then
                    gudtCYSHDat(gintCYSHCount) = udtGRG(UBound(udtGRG))
                    ' �N�E�����G��attribute���٭�
                    Call RestoreData4CY(gudtCYSHDat, gintCYSHCount, sngFlag)
                    gintCYSHCount = gintCYSHCount + 1
                Else
                    gudtCYSLDat(gintCYSLCount) = udtGRG(UBound(udtGRG))
                    ' �N�E�����G��attribute���٭�
                    Call RestoreData4CY(gudtCYSLDat, gintCYSLCount, sngFlag)
                    gintCYSLCount = gintCYSLCount + 1
                End If
            
                '===================================================================
                '* �N��sector����ƪ�GRG��Assign�^udtindex()�ѵ{��display the value
                '===================================================================
                i = 1   ' �}�C�_�l��m��0
                gsngCompFa = GRG_HIGH
                gsngCompFa2 = GRG_LOW
            
                For j = intBegPos To intEndPos - 1
                    If udtGRG(i).sngGRG >= gsngCompFa Then
                        udtIndex(j).sngGRG = udtGRG(i).sngGRG
                    ElseIf udtGRG(i).sngGRG <= gsngCompFa2 Then
                        udtIndex(j).sngGRG = udtGRG(i).sngGRG
                    Else
                        udtIndex(j).sngGRG = 0
                    End If
                    i = i + 1
                Next
            End If
        End If
        intCurrentPos = intCurrentPos + 1
    Wend
    
    '-----------------------------------------------------------
    '* Print High-Pioints and Low-Points' Pattern STA
    '-----------------------------------------------------------
    For i = 1 To gintCYSHCount
        Debug.Print gudtCYSHDat(i).sngDate & "," & _
            gudtCYSHDat(i).sngParam1 & "," & _
            gudtCYSHDat(i).sngParam2 & "," & _
            gudtCYSHDat(i).sngParam3 & "," & _
            gudtCYSHDat(i).sngParam4 & "," & _
            gudtCYSHDat(i).sngParam5 & "," & _
            gudtCYSHDat(i).sngParam6 & "," & _
            gudtCYSHDat(i).sngParam7 & "," & _
            gudtCYSHDat(i).sngParam8
    Next
    
    For i = 1 To gintCYSLCount
        Debug.Print gudtCYSLDat(i).sngDate & "," & _
            gudtCYSLDat(i).sngParam1 & "," & _
            gudtCYSLDat(i).sngParam2 & "," & _
            gudtCYSLDat(i).sngParam3 & "," & _
            gudtCYSLDat(i).sngParam4 & "," & _
            gudtCYSLDat(i).sngParam5 & "," & _
            gudtCYSLDat(i).sngParam6 & "," & _
            gudtCYSLDat(i).sngParam7 & "," & _
            gudtCYSLDat(i).sngParam8
    Next
    
    '-----------------------------------------------------------
    '* Print High-Pioints and Low-Points' Pattern END
    '-----------------------------------------------------------
    
    '--- ���o�ثe��Ƥ��̷s���@������� ---
    Dim strTestEndDate As String
    strTestEndDate = GetTheLatestDate(udtStock, intStockNo)
    '--- ����Testing-Set��GRG�� ---
    Call GenearteTestingSetGRG(udtStock, udtIndex, intStockNo, TEST_START_DATE, strTestEndDate)
    intCurrentPos = 2
    While intCurrentPos < intStockNo
        If udtStock(intCurrentPos).sngDate >= LEARN_END_DATE Then
            If udtIndex(intCurrentPos).sngGRG < GRG_HIGH _
                And udtIndex(intCurrentPos).sngGRG > GRG_LOW Then
                udtIndex(intCurrentPos).sngGRG = 0
            End If
        End If
        intCurrentPos = intCurrentPos + 1
    Wend
   
    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case 6
            MsgBox "[GCFR_General_Module.GetHighLowPoints4CY()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
            Resume Next
        Case 10001
            MsgBox "[GCFR_General_Module.GetHighLowPoints4CY()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
        Case Else
            MsgBox "[GCFR_General_Module.GetHighLowPoints4CY()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
   
    Err.Clear
    Resume Next
End Sub


'***************************************************************************************************
'* ��    ��: ��ܶR��T�� (sngGRG�Ȥj��Τp��]�w��ܰT���̡A�~�p��F�p�⵲����A�p
'*           �G����]�w)
'* ��J�Ѽ�: udtStock  : �C��ѻ����
'*           udtIndex  �G�x�s�����Ƹ��
'*           intStockNo�G��Ƶ���
'* ��X�Ѽ�: �L
'* ��    ��: 1.00: 20040411 �s�W
'*           1.10: 20050604 Modified
'***************************************************************************************************
Public Sub DisplaySignals4CY(ByRef udtStock() As StockData, _
                            ByRef udtIndex() As IndexData, _
                            ByVal intStockNo As Integer)
    Dim i As Integer
    Dim bln1stAHSAppear As Boolean  ' CY>0�϶����A�Y�Ĥ@���X�{AHS�h���X�г]��true
    Dim bln1stALSAppear As Boolean  ' CY<0�϶����A�Y�Ĥ@���X�{ALS�h���X�г]��true
    Dim bln2ndAHSAppear As Boolean  ' CY>0�϶����A�Y�ĤG���X�{AHS�h���X�г]��true
    Dim bln2ndALSAppear As Boolean  ' CY<0�϶����A�Y�ĤG���X�{ALS�h���X�г]��true
    Dim blnHSAppear As Boolean
    Dim blnHS2Appear As Boolean
    Dim intHSAppearDays As Integer
    Dim intLSAppearDays As Integer
    Dim blnLSAppear As Boolean
    Dim blnLS2Appear As Boolean
    Dim blnAHSCross As Boolean      ' �O���O�_�X�{���馬�L�� cross-down 60MAP
    Dim blnALSCross As Boolean      ' �O���O�_�X�{���馬�L�� cross-upon 60MAP
    Dim sngLSBiasValue As Single    ' �O��Fuzzy�ƫ᪺ LSBias ��
    Dim sngMASValue As Single       ' �O��Fuzzy�ƫ᪺ MAS ��
    Dim blnLSBiasH3 As Boolean

    On Error GoTo ERR_HANDLE

    bln1stAHSAppear = False
    bln1stALSAppear = False
    bln2ndAHSAppear = False
    bln2ndALSAppear = False
    blnHSAppear = False
    blnHS2Appear = False
    blnLSAppear = False
    blnLS2Appear = False
    intHSAppearDays = 0
    intLSAppearDays = 0
    blnAHSCross = False
    blnALSCross = False
    blnLSBiasH3 = False

    For i = 3 To intStockNo
        '*** Initialize Variables ***
        udtIndex(i).sngSignal = 0
        
        ' 851018�H��~��CY�ȥi�����R
        If udtStock(i).sngDate > LEARN_START_DATE Then
            If udtIndex(i).sngCyOp > 0 Then
                ' Initialize Variables
                bln1stALSAppear = False
                bln2ndALSAppear = False
                blnLSAppear = False
                blnLS2Appear = False
                intLSAppearDays = 0
                blnALSCross = False

                '*** ���Ͱ��I�T�� ***
                If Not bln1stALSAppear Then
                    If udtIndex(i).sngGRG >= GRG_HIGH Then
                        ' Bias Fuzzy Rules
                        If udtIndex(i).sngLSBias >= LSBIASH3 Then
                            sngLSBiasValue = 1
                        ElseIf udtIndex(i).sngLSBias >= LSBIASH2 Then
                            sngLSBiasValue = (udtIndex(i).sngLSBias - LSBIASH2) / (LSBIASH3 - LSBIASH2) * (1 - 0.9) + 0.9
                        ElseIf udtIndex(i).sngLSBias >= LSBIASH1 Then
                            sngLSBiasValue = (udtIndex(i).sngLSBias - LSBIASH1) / (LSBIASH2 - LSBIASH1) * (0.9 - 0.8) + 0.8
                        ElseIf udtIndex(i).sngLSBias >= 5 Then
                            sngLSBiasValue = (udtIndex(i).sngLSBias - 5) / (LSBIASH1 - 5) * (0.8 - 0.7) + 0.7
                        Else
                            sngLSBiasValue = 0
                        End If
                        ' MAPS Fuzzy Rules
                        If udtIndex(i).sngMASlope >= MASH5 Then
                            sngMASValue = 1
                        ElseIf udtIndex(i).sngMASlope >= MASH4 Then
                            sngMASValue = (udtIndex(i).sngMASlope - MASH4) / (MASH5 - MASH4) * (1 - 0.9) + 0.9
                        ElseIf udtIndex(i).sngMASlope >= MASH3 Then
                            sngMASValue = (udtIndex(i).sngMASlope - MASH3) / (MASH4 - MASH3) * (0.9 - 0.8) + 0.8
                        ElseIf udtIndex(i).sngMASlope >= MASH2 Then
                            sngMASValue = (udtIndex(i).sngMASlope - MASH2) / (MASH3 - MASH2) * (0.8 - 0.7) + 0.7
                        ElseIf udtIndex(i).sngMASlope >= MASH1 Then
                            sngMASValue = (udtIndex(i).sngMASlope - MASH1) / (MASH2 - MASH1) * (0.7 - 0.6) + 0.6
                        Else
                            sngMASValue = 0
                        End If
                        ' Calculate The Signal Value
                        If sngLSBiasValue * sngMASValue > 0 Then
                            udtIndex(i).sngSignal = udtIndex(i).sngGRG * 150 * sngLSBiasValue * sngMASValue
                            If Not (udtIndex(i).sngSignal >= HIGHSIGNAL) Then
                                udtIndex(i).sngSignal = 0
                            Else
                                blnHSAppear = True
                                intHSAppearDays = 1
                            End If
                        End If
                    End If
                    ' �p�G���I�X�{�A�h�}�l�p��g�L�ѼơA�Y�W�L5�ѫh���s�k 0
                    If intHSAppearDays > 0 And intHSAppearDays < 5 Then
                        intHSAppearDays = intHSAppearDays + 1
                    Else
                        intHSAppearDays = 0
                    End If
                    '*** �P�_�O�_�X�{�Ĥ@��AHS ***
                    ' �X�{���I�T��5�餺�A�Y���馬�L���e5MA and 10MA
                    If intHSAppearDays > 0 _
                        And udtStock(i).sngEndprice < udtIndex(i).sngP5 _
                        And udtStock(i).sngEndprice < udtIndex(i).sngP10 Then
                        udtIndex(i).sngSignal = 145
                        udtIndex(i).sngSignal = 140
                        bln1stAHSAppear = True
                        intHSAppearDays = 0
                    End If

                    If blnHSAppear And Not bln1stAHSAppear Then
                        ' ���馬�L���e5MA and 10MA and �X�{���`��e
                        If (udtStock(i).sngEndprice < udtIndex(i).sngP5 _
                            And udtStock(i).sngEndprice < udtIndex(i).sngP10) _
                            And (udtIndex(i - 1).sngP5 >= udtIndex(i - 1).sngP10 _
                            And udtIndex(i).sngP5 <= udtIndex(i).sngP10) Then
                            udtIndex(i).sngSignal = 145
                            udtIndex(i).sngSignal = 140
                            bln1stAHSAppear = True
                        End If
                        ' ���馬�L���e5MA and 10MA
                        If udtStock(i).sngEndprice < udtIndex(i).sngP5 _
                            And udtStock(i).sngEndprice < udtIndex(i).sngP10 Then
                            udtIndex(i).sngSignal = 145
                            udtIndex(i).sngSignal = 140
                            bln1stAHSAppear = True
                        End If
                        ' �X�{���`��e
                        If udtIndex(i - 1).sngP5 >= udtIndex(i - 1).sngP10 _
                            And udtIndex(i).sngP5 <= udtIndex(i).sngP10 Then
                            udtIndex(i).sngSignal = 145
                            udtIndex(i).sngSignal = 140
                            bln1stAHSAppear = True
                        End If
                    End If
                Else
                    ' ��ĤG��AHS
                    If bln1stAHSAppear And Not bln2ndAHSAppear Then   ' �Ĥ@��AHS�X�{��
                        If udtIndex(i).sngGRG >= (GRG_HIGH - 0.1) Then
                            ' Bias Fuzzy Rules
                            If udtIndex(i).sngLSBias >= 4 Then
                                sngLSBiasValue = 1
                            ElseIf udtIndex(i).sngLSBias >= 3.5 Then
                                sngLSBiasValue = (udtIndex(i).sngLSBias - 3.5) / (4 - 3.5) * (1 - 0.9) + 0.9
                            ElseIf udtIndex(i).sngLSBias >= 3 Then
                                sngLSBiasValue = (udtIndex(i).sngLSBias - 3) / (3.5 - 3) * (0.9 - 0.8) + 0.8
                            ElseIf udtIndex(i).sngLSBias >= 2 Then
                                sngLSBiasValue = (udtIndex(i).sngLSBias - 2) / (3 - 2) * (0.8 - 0.7) + 0.7
                            ElseIf udtIndex(i).sngLSBias >= 1 Then
                                sngLSBiasValue = (udtIndex(i).sngLSBias - 1) / (2 - 1) * (0.7 - 0.6) + 0.6
                            Else
                                sngLSBiasValue = 0
                            End If
                            ' MAPS Fuzzy Rules
                            If udtIndex(i).sngMASlope >= MASH5 Then
                                sngMASValue = 1
                            ElseIf udtIndex(i).sngMASlope >= MASH4 Then
                                sngMASValue = (udtIndex(i).sngMASlope - MASH4) / (MASH5 - MASH4) * (1 - 0.9) + 0.9
                            ElseIf udtIndex(i).sngMASlope >= MASH3 Then
                                sngMASValue = (udtIndex(i).sngMASlope - MASH3) / (MASH4 - MASH3) * (0.9 - 0.8) + 0.8
                            ElseIf udtIndex(i).sngMASlope >= MASH2 Then
                                sngMASValue = (udtIndex(i).sngMASlope - MASH2) / (MASH3 - MASH2) * (0.8 - 0.7) + 0.7
                            ElseIf udtIndex(i).sngMASlope >= MASH1 Then
                                sngMASValue = (udtIndex(i).sngMASlope - MASH1) / (MASH2 - MASH1) * (0.7 - 0.6) + 0.6
                            Else
                                sngMASValue = 0
                            End If
                            ' Calcualte Signal Value
                            If sngLSBiasValue * sngMASValue > 0 Then
                                udtIndex(i).sngSignal = udtIndex(i).sngGRG * 150 * sngLSBiasValue * sngMASValue
                                If Not (udtIndex(i).sngSignal >= HIGHSIGNAL) Then
                                    udtIndex(i).sngSignal = 0
                                Else
                                    blnHS2Appear = True
                                End If
                            End If
                        End If
                        
                        If blnHS2Appear And Not bln2ndAHSAppear Then
                            ' ���馬�L���e5MA and 10MA and �X�{���`��e
                            If (udtStock(i).sngEndprice < udtIndex(i).sngP5 _
                                And udtStock(i).sngEndprice < udtIndex(i).sngP10) _
                                And (udtIndex(i - 1).sngP5 >= udtIndex(i - 1).sngP10 _
                                And udtIndex(i).sngP5 <= udtIndex(i).sngP10) Then
                                udtIndex(i).sngSignal = 140
                                bln2ndAHSAppear = True
                            End If
                            ' ���馬�L���e5MA and 10MA
                            If udtStock(i).sngEndprice < udtIndex(i).sngP5 _
                                And udtStock(i).sngEndprice < udtIndex(i).sngP10 Then
                                udtIndex(i).sngSignal = 140
                                bln2ndAHSAppear = True
                            End If
                            ' �X�{���`��e
                            If udtIndex(i - 1).sngP5 >= udtIndex(i - 1).sngP10 _
                                And udtIndex(i).sngP5 <= udtIndex(i).sngP10 Then
                                udtIndex(i).sngSignal = 140
                                bln2ndAHSAppear = True
                            End If
                        End If
                    End If
                End If

                ' ���L���e��60MAP���Q�B���l�I �B �s3�Ѧ���K
                If (udtIndex(i).sngP60 > udtStock(i).sngEndprice _
                    And udtIndex(i - 1).sngP60 < udtStock(i - 1).sngEndprice) _
                    Or (udtIndex(i).sngP60 > udtStock(i).sngEndprice _
                    And udtIndex(i - 2).sngP60 < udtStock(i - 2).sngEndprice) Then
                    If udtStock(i - 2).sngStartprice > udtStock(i - 2).sngEndprice _
                        And udtStock(i - 1).sngStartprice > udtStock(i - 1).sngEndprice _
                        And udtStock(i).sngStartprice > udtStock(i).sngEndprice Then
                        If udtIndex(i).sngUpDownDays = -1 Then
                            udtIndex(i).sngSignal = 150
                            bln1stAHSAppear = True
                        End If
                    End If
                End If
                
                ' ���馬�L���e��60MAP�ɡA�p�G���U�Ӫ���l���L���C��60MAP�F100�I�A�h���AHS
                If udtStock(i).sngEndprice < udtIndex(i).sngP60 _
                    And udtStock(i - 1).sngEndprice > udtIndex(i - 1).sngP60 Then
                    blnAHSCross = True
                End If
                If blnAHSCross Then
                    If udtStock(i).sngEndprice > udtIndex(i).sngP60 Then
                        blnAHSCross = False
                    End If
                End If
                If blnAHSCross And Abs(udtIndex(i).sngMAPDis) > 100 Then
                    udtIndex(i).sngSignal = 150
                    bln1stAHSAppear = True
                    blnAHSCross = False
                End If
            ElseIf udtIndex(i).sngCyOp < 0 Then
                '*** Initialize Variables ***
                bln1stAHSAppear = False
                bln2ndAHSAppear = False
                blnHSAppear = False
                blnHS2Appear = False
                intHSAppearDays = 0
                blnAHSCross = False

                '*** ���ͧC�I�T�� ***
                If udtIndex(i).sngGRG <= GRG_LOW And udtIndex(i).sngGRG > 0 Then
                    ' Bias Fuzzy Rules
                    If udtIndex(i).sngLSBias <= LSBIASL3 Then
                        sngLSBiasValue = 1
                    ElseIf udtIndex(i).sngLSBias <= LSBIASL2 Then
                        sngLSBiasValue = (udtIndex(i).sngLSBias - LSBIASL2) / (LSBIASL3 - LSBIASL2) * (1 - 0.9) + 0.9
                    ElseIf udtIndex(i).sngLSBias <= LSBIASL1 Then
                        sngLSBiasValue = (udtIndex(i).sngLSBias - LSBIASL1) / (LSBIASL3 - LSBIASL1) * (0.9 - 0.8) + 0.8
                    Else
                        sngLSBiasValue = 0
                    End If
                    ' MAPS Fuzzy Rules
                    If udtIndex(i).sngMASlope <= MASL5 Then
                        sngMASValue = 1
                    ElseIf udtIndex(i).sngMASlope <= MASL4 Then
                        sngMASValue = (udtIndex(i).sngMASlope - MASL4) / (MASL5 - MASL4) * (1 - 0.9) + 0.9
                    ElseIf udtIndex(i).sngMASlope <= MASL3 Then
                        sngMASValue = (udtIndex(i).sngMASlope - MASL3) / (MASH4 - MASL3) * (0.9 - 0.8) + 0.8
                    ElseIf udtIndex(i).sngMASlope <= MASL2 Then
                        sngMASValue = (udtIndex(i).sngMASlope - MASL2) / (MASH3 - MASL2) * (0.8 - 0.7) + 0.7
                    ElseIf udtIndex(i).sngMASlope <= MASL1 Then
                        sngMASValue = (udtIndex(i).sngMASlope - MASL1) / (MASH2 - MASL1) * (0.7 - 0.6) + 0.6
                    Else
                        sngMASValue = 0
                    End If
                    ' Calculate The Signal Value
                    If sngLSBiasValue * sngMASValue > 0 Then
                        udtIndex(i).sngSignal = udtIndex(i).sngGRG * 150 * (1 - (sngLSBiasValue * sngMASValue)) + 10
                        ' Signal�ŦX����A�h���ܥ��϶��i���C�I
                        If Not (udtIndex(i).sngSignal >= LOWSIGNAL) Then
                            udtIndex(i).sngSignal = 10
                        End If
                    End If
                End If

                ' ���馬�L���W��60MAP�ɡA�p�G���U�Ӫ���l���L������60MAP�F200�I�άO�W���W�L5�ѡA�h���LHS
                If udtStock(i).sngEndprice > udtIndex(i).sngP60 _
                    And udtStock(i - 1).sngEndprice < udtIndex(i - 1).sngP60 Then
                    blnALSCross = True
                End If
                If blnALSCross Then
                    If udtStock(i).sngEndprice < udtIndex(i).sngP60 Then
                        blnALSCross = False
                    End If
                End If
                If blnALSCross And (Abs(udtIndex(i).sngMAPDis) > 200 Or (udtIndex(i).sngUpDownDays > 5 And Abs(udtIndex(i).sngMAPDis) > 150)) Then
                    udtIndex(i).sngSignal = 5
                    blnALSCross = False
                End If
            End If
        End If
    Next


    bln1stAHSAppear = False
    Dim blnFind2ndAHS As Boolean
    blnFind2ndAHS = False
    Dim intHSDay As Integer
    For i = 1 To intStockNo
        If udtIndex(i).sngSignal > 10 And udtIndex(i).sngSignal < 140 Then
            udtIndex(i).sngSignal = 0
        End If
        ' �p�G�T��=150 �����L�㪬�p�A�h�����ӰT��
        If udtIndex(i).sngSignal = 150 And udtIndex(i).sngInRange > 0 Then
            udtIndex(i).sngSignal = 0
        End If
        '�X�{ALS�T���A�ܤ֫e�@�Ѥ]�n�OGRG�C�I�e��
        If udtIndex(i).sngSignal = 10 Then
'            If Not (udtIndex(i - 1).sngGRG > 0 And udtIndex(i - 1).sngGRG <= frmGeryExp.txtGRGThreshold2) Then
            If Not (udtIndex(i - 1).sngGRG > 0 And udtIndex(i - 1).sngGRG <= GRG_LOW) Then
                udtIndex(i).sngSignal = 0
            End If
        End If

        ' *** 60-10Bias�����j��LSBIASH3�ɡA��2��AHS�M��覡 ***
        ' ��60-10Bias��>=LSBIASH3�A���[��ͶձN�j�զV�W�A���ɲ�2��AHS�����ͤ覡�p�U:
        ' Cond1: 60-10Bias>=LSBIASH3 �B�X�{��1��AHS
        ' Cond2: 60MAS<MASH1
        ' Cond3: HS appear and 5�餺���L���n�e��5MAP, 10MAP �B���馬��K�B�}�L���P���L�����t>=10�I
        If udtIndex(i).sngLSBias >= LSBIASH3 Then
            blnLSBiasH3 = True
        End If
        If udtIndex(i).sngCyOp < 0 Then
            blnLSBiasH3 = False
            blnFind2ndAHS = False
        End If
        ' 60-10 Bias�����v�j�L�]�w�d��A���F��2��AHS���зǮɡA�Y�A���E�XAHS�A�@�߲M��
        If blnLSBiasH3 And bln1stAHSAppear Then
            If udtIndex(i).sngSignal > 0 And udtIndex(i).sngSignal <> 150 Then
                udtIndex(i).sngSignal = 0
            End If
        End If
        ' ��1���X�{AHS
        If udtIndex(i).sngSignal >= 140 Then
            bln1stAHSAppear = True
        End If
        If udtIndex(i).sngCyOp < 0 Then
            bln1stAHSAppear = False
        End If
        ' �ŦX60-10Bias �β�1��AHS�X�{��A�}�l�P�_�O�_�ŦXCond2
        If blnLSBiasH3 And bln1stAHSAppear Then
            If udtIndex(i).sngMASlope < MASH1 Then
                blnFind2ndAHS = True
            End If
        Else
            blnFind2ndAHS = False
        End If
        ' �ŦXCond1 and Cond2 �}�l�P�_�O�_�ŦX Cond3�A�Y�ŦX�Y���ܧ���2��AHS
        If blnFind2ndAHS Then
'            If udtIndex(i).sngGRG >= frmGeryExp.txtGRGThreshold Then
            If udtIndex(i).sngGRG >= GRG_HIGH Then
                blnHSAppear = True
                intHSDay = 5
            End If
        End If
        If intHSDay > 0 Then
            intHSDay = intHSDay - 1
            If udtStock(i).sngEndprice < udtIndex(i).sngP5 And udtStock(i).sngEndprice < udtIndex(i).sngP10 _
                And udtStock(i).sngStartprice > udtStock(i).sngEndprice And Abs(udtStock(i).sngStartprice - udtStock(i).sngEndprice) >= 10 Then
                udtIndex(i).sngSignal = 140
                blnFind2ndAHS = False
                intHSDay = 0
            End If
        Else
            blnHSAppear = False
        End If
    Next


    Dim int140AHS As Integer
    Dim int150AHS As Integer
    For i = 1 To intStockNo
        If udtIndex(i).sngCyOp > 0 Then
            If udtIndex(i).sngSignal = 140 Then
                int140AHS = int140AHS + 1
            End If
            If udtIndex(i).sngSignal = 150 Then
                int150AHS = int150AHS + 1
            End If
            If udtIndex(i).sngSignal = 150 Then
                If (int140AHS + int150AHS) > 2 Then
                    udtIndex(i).sngSignal = 0
                End If
            End If
        ElseIf udtIndex(i).sngCyOp < 0 Then
            int140AHS = 0
            int150AHS = 0
        End If
    Next

    Exit Sub

ERR_HANDLE:
    MsgBox "[GCFR_General_Module.DisplaySignals4CY()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    Resume Next
End Sub


'***************************************************************************************************
'* ��    ��:
'*    ���ΥX�C��Sector -- use CY
'* ��J�Ѽ�:
'*    udtStock �C��ѻ����(��l���)
'*    udtIndex �C��ѻ����(�޳N����)
'*    intStockNo �ѻ���Ƶ���
'*    strDayNo �϶����̤֤Ѽ�(�p�󦹭Ȫ̻ݦX��)
'*    strStkDis �϶����̰��P�̧C�I�t�Z��(�p�󦹭Ȫ̻ݦX��)
'*    indexName1 �ǤJ��MAP�r��--�_��
'*    indexName2 �ǤJ��MAP�r��--����
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00: 20080911 �s�W
'* ��    ��:
'*    sngSector = 1 ���ܬ����I�Ϭq�FsngSector = 0.5 ���ܬ��C�I�Ϭq
'***************************************************************************************************
Public Sub SplitSector4CY(ByRef udtStock() As StockData, _
                        ByRef udtIndex() As IndexData, _
                        ByVal intStockNo As Integer)
    Dim sngFlag As Single       ' ��=1�����I�B��=0.5���C�I
    Dim i As Integer
      
    On Error GoTo ERR_HANDLE
    
    '*** Initialize Variables ***
    sngFlag = 1
    gintSector = 0
    
    For i = 2 To intStockNo
        With udtIndex(i)
            ' 851019 �H��~��CY index�����
            If udtStock(i).sngDate >= LEARN_START_DATE Then
                '--- �O�����I�O�ݩ��I�ΧC�I ---
                If .sngCyOp >= 0 Then
                    sngFlag = 1     ' ���I
                Else
                    sngFlag = 0.5   ' �C�I
                End If
                .sngSector = sngFlag
            End If
        End With
    Next
        
    Exit Sub
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.SplitSector4CY()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
End Sub


'***************************************************************************************************
'* ��    ��:
'*    ���ư��e�B�z ���o�C�@�ӦU�O���Ъ��̤j�Ȥγ̤p��
'* ��J�Ѽ�:
'*    udtGRG �n�B�z�����
'*    intCount �n�B�z����ƪ�����
'*    sngFlag �����e�B�z�����I�άO�C�I
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20080911 �s�W
'***************************************************************************************************
Public Sub PreProcess4CY(ByRef udtGRG() As udtGRGIndex, _
                        ByVal intCount As Integer, _
                        ByVal sngFlag As Single)
    Dim i As Integer
    Dim j As Integer

    On Error GoTo ERR_HANDLE
    
    '--- Initialize Variables ---
    For i = 1 To 8
        sngMax(i) = -99999
        sngMin(i) = 99999
    Next
    
    '--------------------------------------------------------------------
    '* Find each Max value and Min value in each parameter
    '--------------------------------------------------------------------
    For i = 1 To intCount
        If sngFlag = 1 Then     ' ���I
            With udtGRG(i)
                If sngMax(1) < .sngParam1 Then
                    sngMax(1) = .sngParam1
                End If
                If sngMin(1) > .sngParam1 Then
                    sngMin(1) = .sngParam1
                End If
                If sngMax(2) < .sngParam2 Then
                    sngMax(2) = .sngParam2
                End If
                If sngMin(2) > .sngParam2 Then
                    sngMin(2) = .sngParam2
                End If
                If sngMax(3) < .sngParam3 Then
                    sngMax(3) = .sngParam3
                End If
                If sngMin(3) > .sngParam3 Then
                    sngMin(3) = .sngParam3
                End If
                If sngMax(4) < .sngParam4 Then
                    sngMax(4) = .sngParam4
                End If
                If sngMin(4) > .sngParam4 Then
                    sngMin(4) = .sngParam4
                End If
                If sngMax(5) < .sngParam5 Then
                    sngMax(5) = .sngParam5
                End If
                If sngMin(5) > .sngParam5 Then
                    sngMin(5) = .sngParam5
                End If
                If sngMax(6) < .sngParam6 Then
                    sngMax(6) = .sngParam6
                End If
                If sngMin(6) > .sngParam6 Then
                    sngMin(6) = .sngParam6
                End If
            End With
        Else        ' �C�I
            With udtGRG(i)
                If sngMax(1) < .sngParam1 Then
                    sngMax(1) = .sngParam1
                End If
                If sngMin(1) > .sngParam1 Then
                    sngMin(1) = .sngParam1
                End If
                If sngMax(2) < .sngParam2 Then
                    sngMax(2) = .sngParam2
                End If
                If sngMin(2) > .sngParam2 Then
                    sngMin(2) = .sngParam2
                End If
                If sngMax(3) < .sngParam3 Then
                    sngMax(3) = .sngParam3
                End If
                If sngMin(3) > .sngParam3 Then
                    sngMin(3) = .sngParam3
                End If
                If sngMax(4) < .sngParam4 Then
                    sngMax(4) = .sngParam4
                End If
                If sngMin(4) > .sngParam4 Then
                    sngMin(4) = .sngParam4
                End If
                If sngMax(5) < .sngParam5 Then
                    sngMax(5) = .sngParam5
                End If
                If sngMin(5) > .sngParam5 Then
                    sngMin(5) = .sngParam5
                End If
                If sngMax(6) < .sngParam6 Then
                    sngMax(6) = .sngParam6
                End If
                If sngMin(6) > .sngParam6 Then
                    sngMin(6) = .sngParam6
                End If
            End With
        End If
    Next
    
    '--------------------------------------------------------------------
    '* ��Ȥ�
    '*
    '* Note: gintSelFactorsMethod()    �}�C start with 1
    '*       gintSelLowFactorsMethod() �}�C start with 1
    '*
    '* gintSelAttributesMethod = 1 ���u��j�v
    '* gintSelAttributesMethod = 2 ���u��p�v
    '* gintSelAttributesMethod = 3 ���u��ءv
    '--------------------------------------------------------------------
    For i = 1 To intCount
        If sngFlag = 1 Then     ' ���I
            With udtGRG(i)
                If UBound(gintSelFactorsMethod) >= 1 Then
                    If gintSelFactorsMethod(1) = 1 And UBound(gintSelFactorsMethod) >= 1 Then
                        If (sngMax(1) - sngMin(1)) <> 0 Then
                            .sngParam1 = (.sngParam1 - sngMin(1)) / (sngMax(1) - sngMin(1))
                        End If
                    ElseIf gintSelFactorsMethod(1) = 2 Then
                        If (sngMax(1) - sngMin(1)) <> 0 Then
                            .sngParam1 = (sngMax(1) - .sngParam1) / (sngMax(1) - sngMin(1))
                        End If
                    ElseIf gintSelFactorsMethod(1) = 3 Then
                        If (sngMax(1) - udtGRG(intCount).sngParam1) <> 0 Or _
                            (udtGRG(intCount).sngParam1 - sngMin(1)) <> 0 Then
                            .sngParam1 = 1 - Abs(.sngParam1 - udtGRG(intCount).sngParam1) / (IIf((sngMax(1) - udtGRG(intCount).sngParam1 > udtGRG(intCount).sngParam1 - sngMin(1)), sngMax(1) - udtGRG(intCount).sngParam1, udtGRG(intCount).sngParam1 - sngMin(1)))
                        End If
                    End If
                End If
                
                If UBound(gintSelFactorsMethod) >= 2 Then
                    If gintSelFactorsMethod(2) = 1 And UBound(gintSelFactorsMethod) >= 2 Then
                        If (sngMax(2) - sngMin(2)) <> 0 Then
                            .sngParam2 = (.sngParam2 - sngMin(2)) / (sngMax(2) - sngMin(2))
                        End If
                    ElseIf gintSelFactorsMethod(2) = 2 Then
                        If (sngMax(2) - sngMin(2)) <> 0 Then
                            .sngParam2 = (sngMax(2) - .sngParam2) / (sngMax(2) - sngMin(2))
                        End If
                    ElseIf gintSelFactorsMethod(2) = 3 Then
                        If (sngMax(2) - udtGRG(intCount).sngParam2) <> 0 Or _
                            (udtGRG(intCount).sngParam2 - sngMin(2)) <> 0 Then
                            .sngParam2 = 1 - Abs(.sngParam2 - udtGRG(intCount).sngParam2) / (IIf((sngMax(2) - udtGRG(intCount).sngParam2 > udtGRG(intCount).sngParam2 - sngMin(2)), sngMax(2) - udtGRG(intCount).sngParam2, udtGRG(intCount).sngParam2 - sngMin(2)))
                        End If
                    End If
                End If
                
                If UBound(gintSelFactorsMethod) >= 3 Then
                    If gintSelFactorsMethod(3) = 1 And UBound(gintSelFactorsMethod) >= 3 Then
                        If (sngMax(3) - sngMin(3)) <> 0 Then
                            .sngParam3 = (.sngParam3 - sngMin(3)) / (sngMax(3) - sngMin(3))
                        End If
                    ElseIf gintSelFactorsMethod(3) = 2 Then
                        If (sngMax(3) - sngMin(3)) <> 0 Then
                            .sngParam3 = (sngMax(3) - .sngParam3) / (sngMax(3) - sngMin(3))
                        End If
                    ElseIf gintSelFactorsMethod(2) = 3 Then
                        If (sngMax(3) - udtGRG(intCount).sngParam3) <> 0 Or _
                            (udtGRG(intCount).sngParam3 - sngMin(3)) <> 0 Then
                            .sngParam3 = 1 - Abs(.sngParam3 - udtGRG(intCount).sngParam3) / (IIf((sngMax(3) - udtGRG(intCount).sngParam3 > udtGRG(intCount).sngParam3 - sngMin(3)), sngMax(3) - udtGRG(intCount).sngParam3, udtGRG(intCount).sngParam3 - sngMin(3)))
                        End If
                    End If
                End If
            
                If UBound(gintSelFactorsMethod) >= 4 Then
                    If gintSelFactorsMethod(4) = 1 And UBound(gintSelFactorsMethod) >= 4 Then
                        If (sngMax(4) - sngMin(4)) <> 0 Then
                            .sngParam4 = (.sngParam4 - sngMin(4)) / (sngMax(4) - sngMin(4))
                        End If
                    ElseIf gintSelFactorsMethod(4) = 2 Then
                        If (sngMax(4) - sngMin(4)) <> 0 Then
                            .sngParam4 = (sngMax(4) - .sngParam4) / (sngMax(4) - sngMin(4))
                        End If
                    ElseIf gintSelFactorsMethod(4) = 3 Then
                        If (sngMax(4) - udtGRG(intCount).sngParam4) <> 0 Or _
                            (udtGRG(intCount).sngParam4 - sngMin(4)) <> 0 Then
                            .sngParam4 = 1 - Abs(.sngParam4 - udtGRG(intCount).sngParam4) / (IIf((sngMax(4) - udtGRG(intCount).sngParam4 > udtGRG(intCount).sngParam4 - sngMin(4)), sngMax(4) - udtGRG(intCount).sngParam4, udtGRG(intCount).sngParam4 - sngMin(4)))
                        End If
                    End If
                End If
            
                If UBound(gintSelFactorsMethod) >= 5 Then
                    If gintSelFactorsMethod(5) = 1 And UBound(gintSelFactorsMethod) >= 5 Then
                        If (sngMax(5) - sngMin(5)) <> 0 Then
                            .sngParam5 = (.sngParam5 - sngMin(5)) / (sngMax(5) - sngMin(5))
                        End If
                    ElseIf gintSelFactorsMethod(5) = 2 Then
                        If (sngMax(5) - sngMin(5)) <> 0 Then
                            .sngParam5 = (sngMax(5) - .sngParam5) / (sngMax(5) - sngMin(5))
                        End If
                    ElseIf gintSelFactorsMethod(5) = 3 Then
                        If (sngMax(5) - udtGRG(intCount).sngParam5) <> 0 Or _
                            (udtGRG(intCount).sngParam5 - sngMin(5)) <> 0 Then
                            .sngParam5 = 1 - Abs(.sngParam5 - udtGRG(intCount).sngParam5) / (IIf((sngMax(5) - udtGRG(intCount).sngParam5 > udtGRG(intCount).sngParam5 - sngMin(5)), sngMax(5) - udtGRG(intCount).sngParam5, udtGRG(intCount).sngParam5 - sngMin(5)))
                        End If
                    End If
                End If
            
                If UBound(gintSelFactorsMethod) >= 6 Then
                    If gintSelFactorsMethod(6) = 1 Then
                        If (sngMax(6) - sngMin(6)) <> 0 Then
                            .sngParam6 = (.sngParam6 - sngMin(6)) / (sngMax(6) - sngMin(6))
                        End If
                    ElseIf gintSelFactorsMethod(6) = 2 Then
                        If (sngMax(6) - sngMin(6)) <> 0 Then
                            .sngParam6 = (sngMax(6) - .sngParam6) / (sngMax(6) - sngMin(6))
                        End If
                    ElseIf gintSelFactorsMethod(6) = 3 Then
                        If (sngMax(6) - udtGRG(intCount).sngParam6) <> 0 Or _
                            (udtGRG(intCount).sngParam6 - sngMin(6)) <> 0 Then
                            .sngParam6 = 1 - Abs(.sngParam6 - udtGRG(intCount).sngParam6) / (IIf((sngMax(6) - udtGRG(intCount).sngParam6 > udtGRG(intCount).sngParam6 - sngMin(6)), sngMax(6) - udtGRG(intCount).sngParam6, udtGRG(intCount).sngParam6 - sngMin(6)))
                        End If
                    End If
                End If
            End With
        Else        ' �C�I
            With udtGRG(i)
                If UBound(gintSelLowFactorsMethod) >= 1 Then
                    If gintSelLowFactorsMethod(1) = 1 Then
                        If (sngMax(1) - sngMin(1)) <> 0 Then
                            .sngParam1 = (.sngParam1 - sngMin(1)) / (sngMax(1) - sngMin(1))
                        End If
                    ElseIf gintSelLowFactorsMethod(1) = 2 Then
                        If (sngMax(1) - sngMin(1)) <> 0 Then
                            .sngParam1 = (sngMax(1) - .sngParam1) / (sngMax(1) - sngMin(1))
                        End If
                    ElseIf gintSelLowFactorsMethod(1) = 3 Then
                        If (sngMax(1) - udtGRG(intCount).sngParam1) <> 0 Or _
                            (udtGRG(intCount).sngParam1 - sngMin(1)) <> 0 Then
                            .sngParam1 = 1 - Abs(.sngParam1 - udtGRG(intCount).sngParam1) / (IIf((sngMax(1) - udtGRG(intCount).sngParam1 > udtGRG(intCount).sngParam1 - sngMin(1)), sngMax(1) - udtGRG(intCount).sngParam1, udtGRG(intCount).sngParam1 - sngMin(1)))
                        End If
                    End If
                End If
            
                If UBound(gintSelLowFactorsMethod) >= 2 Then
                    If gintSelLowFactorsMethod(2) = 1 Then
                        If (sngMax(2) - sngMin(2)) <> 0 Then
                            .sngParam2 = (.sngParam2 - sngMin(2)) / (sngMax(2) - sngMin(2))
                        End If
                    ElseIf gintSelLowFactorsMethod(2) = 2 Then
                        If (sngMax(2) - sngMin(2)) <> 0 Then
                            .sngParam2 = (sngMax(2) - .sngParam2) / (sngMax(2) - sngMin(2))
                        End If
                    ElseIf gintSelLowFactorsMethod(2) = 3 Then
                        If (sngMax(2) - udtGRG(intCount).sngParam2) <> 0 Or _
                            (udtGRG(intCount).sngParam2 - sngMin(2)) <> 0 Then
                            .sngParam2 = 1 - Abs(.sngParam2 - udtGRG(intCount).sngParam2) / (IIf((sngMax(2) - udtGRG(intCount).sngParam2 > udtGRG(intCount).sngParam2 - sngMin(2)), sngMax(2) - udtGRG(intCount).sngParam2, udtGRG(intCount).sngParam2 - sngMin(2)))
                        End If
                    End If
                End If
            
                If UBound(gintSelLowFactorsMethod) >= 3 Then
                    If gintSelLowFactorsMethod(3) = 1 Then
                        If (sngMax(3) - sngMin(3)) <> 0 Then
                            .sngParam3 = (.sngParam3 - sngMin(3)) / (sngMax(3) - sngMin(3))
                        End If
                    ElseIf gintSelLowFactorsMethod(3) = 2 Then
                        If (sngMax(3) - sngMin(3)) <> 0 Then
                            .sngParam3 = (sngMax(3) - .sngParam3) / (sngMax(3) - sngMin(3))
                        End If
                    ElseIf gintSelLowFactorsMethod(3) = 3 Then
                        If (sngMax(3) - udtGRG(intCount).sngParam3) <> 0 Or _
                            (udtGRG(intCount).sngParam3 - sngMin(3)) <> 0 Then
                            .sngParam3 = 1 - Abs(.sngParam3 - udtGRG(intCount).sngParam3) / (IIf((sngMax(3) - udtGRG(intCount).sngParam3 > udtGRG(intCount).sngParam3 - sngMin(3)), sngMax(3) - udtGRG(intCount).sngParam3, udtGRG(intCount).sngParam3 - sngMin(3)))
                        End If
                    End If
                End If
            
                If UBound(gintSelLowFactorsMethod) >= 4 Then
                    If gintSelLowFactorsMethod(4) = 1 Then
                        If (sngMax(4) - sngMin(4)) <> 0 Then
                            .sngParam4 = (.sngParam4 - sngMin(4)) / (sngMax(4) - sngMin(4))
                        End If
                    ElseIf gintSelLowFactorsMethod(4) = 2 Then
                        If (sngMax(4) - sngMin(4)) <> 0 Then
                            .sngParam4 = (sngMax(4) - .sngParam4) / (sngMax(4) - sngMin(4))
                        End If
                    ElseIf gintSelLowFactorsMethod(4) = 3 Then
                        If (sngMax(4) - udtGRG(intCount).sngParam4) <> 0 Or _
                            (udtGRG(intCount).sngParam4 - sngMin(4)) <> 0 Then
                            .sngParam4 = 1 - Abs(.sngParam4 - udtGRG(intCount).sngParam4) / (IIf((sngMax(4) - udtGRG(intCount).sngParam4 > udtGRG(intCount).sngParam4 - sngMin(4)), sngMax(4) - udtGRG(intCount).sngParam4, udtGRG(intCount).sngParam4 - sngMin(4)))
                        End If
                    End If
                End If
            
                If UBound(gintSelLowFactorsMethod) >= 5 Then
                    If gintSelLowFactorsMethod(5) = 1 Then
                        If (sngMax(5) - sngMin(5)) <> 0 Then
                            .sngParam5 = (.sngParam5 - sngMin(5)) / (sngMax(5) - sngMin(5))
                        End If
                    ElseIf gintSelLowFactorsMethod(5) = 2 Then
                        If (sngMax(5) - sngMin(5)) <> 0 Then
                            .sngParam5 = (sngMax(5) - .sngParam5) / (sngMax(5) - sngMin(5))
                        End If
                    ElseIf gintSelLowFactorsMethod(5) = 3 Then
                        If (sngMax(5) - udtGRG(intCount).sngParam5) <> 0 Or _
                            (udtGRG(intCount).sngParam5 - sngMin(5)) <> 0 Then
                            .sngParam5 = 1 - Abs(.sngParam5 - udtGRG(intCount).sngParam5) / (IIf((sngMax(5) - udtGRG(intCount).sngParam5 > udtGRG(intCount).sngParam5 - sngMin(5)), sngMax(5) - udtGRG(intCount).sngParam5, udtGRG(intCount).sngParam5 - sngMin(5)))
                        End If
                    End If
                End If
            
                If UBound(gintSelLowFactorsMethod) >= 6 Then
                    If gintSelLowFactorsMethod(6) = 1 Then
                        If (sngMax(6) - sngMin(6)) <> 0 Then
                            .sngParam6 = (.sngParam6 - sngMin(6)) / (sngMax(6) - sngMin(6))
                        End If
                    ElseIf gintSelLowFactorsMethod(6) = 2 Then
                        If (sngMax(6) - sngMin(6)) <> 0 Then
                            .sngParam6 = (sngMax(6) - .sngParam6) / (sngMax(6) - sngMin(6))
                        End If
                    ElseIf gintSelLowFactorsMethod(6) = 3 Then
                        If (sngMax(6) - udtGRG(intCount).sngParam6) <> 0 Or _
                            (udtGRG(intCount).sngParam6 - sngMin(6)) <> 0 Then
                            .sngParam6 = 1 - Abs(.sngParam6 - udtGRG(intCount).sngParam6) / (IIf((sngMax(6) - udtGRG(intCount).sngParam6 > udtGRG(intCount).sngParam6 - sngMin(6)), sngMax(6) - udtGRG(intCount).sngParam6, udtGRG(intCount).sngParam6 - sngMin(6)))
                        End If
                    End If
                End If
            End With
        End If
    Next
    
    Exit Sub
    
    
ERR_HANDLE:
    Select Case Err.Number
        Case 6
            Debug.Print "[GCFR_General_Module.PreProcess4CY()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
        Case Else
            Debug.Print "[GCFR_General_Module.PreProcess4CY()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
    
    Err.Clear
    Resume Next
End Sub



'***************************************************************************************************
'* ��    ��:
'*    Get attributes value
'* ��J�Ѽ�:
'*    udtIndex �x�s�����Ƹ��
'*    intPos �nŪ����ƪ���m
'*    intSelAttribute ��ܪ�attribute
'* ��X�Ѽ�:
'*    Single �ҿ�ܤ���Ƥ�attribute����
'* ��    ��:
'*    2.00  20080911 Modified
'***************************************************************************************************
Public Function GetAttributesValue4CY(ByRef udtIndex() As IndexData, _
                                ByVal intPos As Integer, _
                                ByVal intSelAttribute As Integer, _
                                ByVal sngFlag As Single) As Single
    
    On Error GoTo ERR_HANDLE
    
    If sngFlag = 1 Then
        '--- �j���ܪ�attribute�ƥءA���^��99999 ---
        If intSelAttribute > gintSelCount Then
            GetAttributesValue4CY = 99999
            Exit Function
        End If
    
        If gstrSelFactors(intSelAttribute) = "BIAS" Then
            GetAttributesValue4CY = udtIndex(intPos).sngBias
        ElseIf gstrSelFactors(intSelAttribute) = "MACD" Then
            GetAttributesValue4CY = udtIndex(intPos).sngMACD
        ElseIf gstrSelFactors(intSelAttribute) = "PSY" Then
            GetAttributesValue4CY = udtIndex(intPos).sngPSY
        ElseIf gstrSelFactors(intSelAttribute) = "RSI_L" Then
            GetAttributesValue4CY = udtIndex(intPos).sngRSI_L
        ElseIf gstrSelFactors(intSelAttribute) = "RSI_S" Then
            GetAttributesValue4CY = udtIndex(intPos).sngRSI_S
        ElseIf gstrSelFactors(intSelAttribute) = "WMS" Then
            GetAttributesValue4CY = udtIndex(intPos).sngWMS
        ElseIf gstrSelFactors(intSelAttribute) = "K" Then
            GetAttributesValue4CY = udtIndex(intPos).sngK
        ElseIf gstrSelFactors(intSelAttribute) = "D" Then
            GetAttributesValue4CY = udtIndex(intPos).sngD
'        ElseIf gstrSelFactors(intSelAttribute) = "KDDis" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngKDDis
        ElseIf gstrSelFactors(intSelAttribute) = "MAPDis" Then
            GetAttributesValue4CY = udtIndex(intPos).sngMAPDis
'        ElseIf gstrSelFactors(intSelAttribute) = "RSIDis" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngRSIDis
        ElseIf gstrSelFactors(intSelAttribute) = "MAP3" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP3
        ElseIf gstrSelFactors(intSelAttribute) = "MAP4" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP4
        ElseIf gstrSelFactors(intSelAttribute) = "MAP5" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP5
        ElseIf gstrSelFactors(intSelAttribute) = "MAP6" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP6
        ElseIf gstrSelFactors(intSelAttribute) = "MAP8" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP8
        ElseIf gstrSelFactors(intSelAttribute) = "MAP10" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP10
        ElseIf gstrSelFactors(intSelAttribute) = "MAP12" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP12
        ElseIf gstrSelFactors(intSelAttribute) = "MAP24" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP24
        ElseIf gstrSelFactors(intSelAttribute) = "MAP30" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP30
        ElseIf gstrSelFactors(intSelAttribute) = "MAP72" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP72
        ElseIf gstrSelFactors(intSelAttribute) = "MAP144" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP144
        ElseIf gstrSelFactors(intSelAttribute) = "MAP288" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP288
        ElseIf gstrSelFactors(intSelAttribute) = "DIF" Then
            GetAttributesValue4CY = udtIndex(intPos).sngDIF
        ElseIf gstrSelFactors(intSelAttribute) = "DIF_MACD" Then
            GetAttributesValue4CY = udtIndex(intPos).sngDIF_MACD
'        ElseIf gstrSelFactors(intSelAttribute) = "TAPI" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngTAPI
'        ElseIf gstrSelFactors(intSelAttribute) = "OBV" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngOBV
        ElseIf gstrSelFactors(intSelAttribute) = "VR" Then
            GetAttributesValue4CY = udtIndex(intPos).sngVR
        ElseIf gstrSelFactors(intSelAttribute) = "CY" Then
            GetAttributesValue4CY = Str(Round(udtIndex(intPos).sngDIF_MACD, 2))
'        ElseIf gstrSelFactors(intSelAttribute) = "AR" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngAR
'        ElseIf gstrSelFactors(intSelAttribute) = "BR" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngBR
        ElseIf gstrSelFactors(intSelAttribute) = "VOL24" Then
            GetAttributesValue4CY = udtIndex(intPos).sngVol24
        ElseIf gstrSelFactors(intSelAttribute) = "CY" Then
            GetAttributesValue4CY = udtIndex(intPos).sngCyOp
'        ElseIf gstrSelFactors(intSelAttribute) = "CYS" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngCYS
        Else
            Err.Raise 10002
        End If
    Else
        '--- �j���ܪ�attribute�ƥءA���^��99999 ---
        If intSelAttribute > gintSelLowCount Then
            GetAttributesValue4CY = 99999
            Exit Function
        End If
    
        If gstrSelLowFactors(intSelAttribute) = "BIAS" Then
            GetAttributesValue4CY = udtIndex(intPos).sngBias
        ElseIf gstrSelLowFactors(intSelAttribute) = "MACD" Then
            GetAttributesValue4CY = udtIndex(intPos).sngMACD
        ElseIf gstrSelLowFactors(intSelAttribute) = "PSY" Then
            GetAttributesValue4CY = udtIndex(intPos).sngPSY
        ElseIf gstrSelLowFactors(intSelAttribute) = "RSI_L" Then
            GetAttributesValue4CY = udtIndex(intPos).sngRSI_L
        ElseIf gstrSelLowFactors(intSelAttribute) = "RSI_S" Then
            GetAttributesValue4CY = udtIndex(intPos).sngRSI_S
        ElseIf gstrSelLowFactors(intSelAttribute) = "WMS" Then
            GetAttributesValue4CY = udtIndex(intPos).sngWMS
        ElseIf gstrSelLowFactors(intSelAttribute) = "K" Then
            GetAttributesValue4CY = udtIndex(intPos).sngK
        ElseIf gstrSelLowFactors(intSelAttribute) = "D" Then
            GetAttributesValue4CY = udtIndex(intPos).sngD
'        ElseIf gstrSelLowFactors(intSelAttribute) = "KDDis" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngKDDis
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAPDis" Then
            GetAttributesValue4CY = udtIndex(intPos).sngMAPDis
'        ElseIf gstrSelLowFactors(intSelAttribute) = "RSIDis" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngRSIDis
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP3" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP3
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP4" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP4
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP5" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP5
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP6" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP6
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP8" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP8
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP10" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP10
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP12" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP12
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP24" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP24
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP30" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP30
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP72" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP72
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP144" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP144
        ElseIf gstrSelLowFactors(intSelAttribute) = "MAP288" Then
            GetAttributesValue4CY = udtIndex(intPos).sngP288
        ElseIf gstrSelLowFactors(intSelAttribute) = "DIF" Then
            GetAttributesValue4CY = udtIndex(intPos).sngDIF
        ElseIf gstrSelLowFactors(intSelAttribute) = "DIF_MACD" Then
            GetAttributesValue4CY = udtIndex(intPos).sngDIF_MACD
'        ElseIf gstrSelLowFactors(intSelAttribute) = "TAPI" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngTAPI
'        ElseIf gstrSelLowFactors(intSelAttribute) = "OBV" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngOBV
        ElseIf gstrSelLowFactors(intSelAttribute) = "VR" Then
            GetAttributesValue4CY = udtIndex(intPos).sngVR
        ElseIf gstrSelLowFactors(intSelAttribute) = "CY" Then
            GetAttributesValue4CY = Str(Round(udtIndex(intPos).sngDIF_MACD, 2))
'        ElseIf gstrSelLowFactors(intSelAttribute) = "AR" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngAR
'        ElseIf gstrSelLowFactors(intSelAttribute) = "BR" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngBR
        ElseIf gstrSelLowFactors(intSelAttribute) = "VOL24" Then
            GetAttributesValue4CY = udtIndex(intPos).sngVol24
        ElseIf gstrSelLowFactors(intSelAttribute) = "CY" Then
            GetAttributesValue4CY = udtIndex(intPos).sngCyOp
'        ElseIf gstrSelLowFactors(intSelAttribute) = "CYS" Then
'            GetAttributesValue4CY = udtIndex(intPos).sngCYS
        Else
            Err.Raise 10003
        End If
    End If
    
    Exit Function
    
    
ERR_HANDLE:
    MsgBox "[GCFR_General_Module.GetAttributesValue4CY()] -- " & Err.Number & ":" & Err.Description & " -- �䤣��������쪺����", vbOKOnly
'    Err.Clear
    Resume Next
'    Exit Function
End Function


'***************************************************************************************************
'* ��    ��:
'*    �٭�E���X�Ӫ���
'* ��J�Ѽ�:
'*    udtClusterDat �E�����G������
'*    intPos �Ӹ�ƪ���m
'*    intPos �Ӹ�ƪ���m
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20080911 Modified
'***************************************************************************************************
Public Sub RestoreData4CY(ByRef udtClusterDat() As udtGRGIndex, _
                            ByVal intPos As Integer, _
                            ByVal sngFlag)
    On Error GoTo ERR_HANDLE
    
    If sngFlag = 1 Then
        With udtClusterDat(intPos)
            .sngParam1 = (sngMax(1) - sngMin(1)) * .sngParam1 + sngMin(1)
            .sngParam2 = (sngMax(2) - sngMin(2)) * .sngParam2 + sngMin(2)
            .sngParam3 = (sngMax(3) - sngMin(3)) * .sngParam3 + sngMin(3)
            .sngParam4 = (sngMax(4) - sngMin(4)) * .sngParam4 + sngMin(4)
            .sngParam5 = (sngMax(5) - sngMin(5)) * .sngParam5 + sngMin(5)
            .sngParam6 = (sngMax(6) - sngMin(6)) * .sngParam6 + sngMin(6)
        End With
    Else
        With udtClusterDat(intPos)
            .sngParam1 = (sngMax(1) - sngMin(1)) * .sngParam1 + sngMin(1)
            .sngParam2 = (sngMax(2) - sngMin(2)) * .sngParam2 + sngMin(2)
            .sngParam3 = (sngMax(3) - sngMin(3)) * .sngParam3 + sngMin(3)
            .sngParam4 = (sngMax(4) - sngMin(4)) * .sngParam4 + sngMin(4)
            .sngParam5 = (sngMax(5) - sngMin(5)) * .sngParam5 + sngMin(5)
            .sngParam6 = (sngMax(6) - sngMin(6)) * .sngParam6 + sngMin(6)
        End With
    End If

    Exit Sub
    
    
ERR_HANDLE:
    Select Case Err.Number
        Case Else
            MsgBox "[GCFR_General_Module.RestoreData4CY()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    End Select
    
    Resume Next
End Sub


'***************************************************************************************************
'* ��    ��:
'*    ����Testing Sets' GRG values
'* ��J�Ѽ�:
'*    udtStock �C��ѻ����
'*    udtIndex �x�s�����Ƹ��
'*    intStockNo ��Ƶ���
'*    strStartDT �ǤJ����ư_�l���
'*    strEndDT �ǤJ����Ƶ������
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00: 20080913 Earvin   New
'***************************************************************************************************
Public Sub GenearteTestingSetGRG(ByRef udtStock() As StockData, _
                            ByRef udtIndex() As IndexData, _
                            ByVal intStockNo As Integer, _
                            ByVal strStartDT As String, _
                            ByVal strEndDT As String)
    Dim intCurrentPos As Integer
                            
    On Error GoTo ERR_HANDLE
    
    '---------------------------------------------------
    '* ��2�����A�H���٭��ƹB�⪺�ɶ� -- CY-Index > 0
    '---------------------------------------------------
    PSY_No = 13
    WMS_No = 9
    KD_No = 9
    MACD_No = 24
    EMA_S = 12
    EMA_L = 26
    RSI_S = 6
    RSI_L = 12
    Bias_No = 10
    VR_NO = 12
    OBV_No = 12
    TAPI_No = 12
    AR_No = 12
    
    Call subCalculateIndex(gudtStockDay, gudtIndexDay, gintDayIndex)
    Call subCalculateIndex(gudtStockWeek, gudtIndexWeek, gintWeekIndex)
    Call subCalculateIndex(gudtStockMonth, gudtIndexMonth, gintMonthIndex)
    Call frmEarvinStocks.DrawStockForm(gsngEndIndex, GetStockName(frmEarvinStocks.cboStocks.Text))
    
    intCurrentPos = 2
    While intCurrentPos < intStockNo
        If udtStock(intCurrentPos).sngDate >= strStartDT And udtStock(intCurrentPos).sngDate <= strEndDT Then
            If udtIndex(intCurrentPos).sngCyOp >= 0 Then
                udtIndex(intCurrentPos).sngGRG = CalculateTestingSetGRG4CY(udtStock, udtIndex, intCurrentPos, intStockNo, 1)
            End If
        End If
        intCurrentPos = intCurrentPos + 1
    Wend

    '---------------------------------------------------
    '* ��2�����A�H���٭��ƹB�⪺�ɶ� -- CY-Index < 0
    '---------------------------------------------------
    PSY_No = 13
    WMS_No = 9
    KD_No = 9
    MACD_No = 24
    EMA_S = 12
    EMA_L = 26
    RSI_S = 6
    RSI_L = 6
    Bias_No = 24
    VR_NO = 12
    OBV_No = 12
    TAPI_No = 12
    AR_No = 12
                
    Call subCalculateIndex(gudtStockDay, gudtIndexDay, gintDayIndex)
    Call subCalculateIndex(gudtStockWeek, gudtIndexWeek, gintWeekIndex)
    Call subCalculateIndex(gudtStockMonth, gudtIndexMonth, gintMonthIndex)
    Call frmEarvinStocks.DrawStockForm(gsngEndIndex, GetStockName(frmEarvinStocks.cboStocks.Text))
    
    intCurrentPos = 2
    While intCurrentPos < intStockNo
        If udtStock(intCurrentPos).sngDate >= strStartDT And udtStock(intCurrentPos).sngDate <= strEndDT Then
            If udtIndex(intCurrentPos).sngCyOp < 0 Then
                udtIndex(intCurrentPos).sngGRG = CalculateTestingSetGRG4CY(udtStock, udtIndex, intCurrentPos, intStockNo, 2)
            End If
        End If
        intCurrentPos = intCurrentPos + 1
    Wend

    Exit Sub
    
    
ERR_HANDLE:
    Debug.Print "[GCFR_General_Module.GenearteTestingSetGRG()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
End Sub



''''***************************************************************************************************
''''* ��    ��:
''''*    �{���@�Ұʦ۰ʻE���ð���POS����
''''* ��J�Ѽ�:
''''*    udtStock �C��ѻ����
''''*    udtIndex �x�s�����Ƹ��
''''*    intIndexCnt ��Ƶ���
''''*    strSTA ���ϥΤ�����(POS, SSOS, EOS, SOS)
''''*    intKind 1���ܲ��ͤ��ơF2���ܲ��Ͷg��ơF3���ܲ��ͤ���
''''* ��X�Ѽ�: �L
''''* ��    ��:
''''*    2.00: 20080913 Earvin   New
''''***************************************************************************************************
'''Public Sub GenSignals(ByRef udtStock() As Stockdata, _
'''                    ByRef udtIndex() As IndexData, _
'''                    ByVal intIndexCnt As Integer, _
'''                    ByVal strSTA As String, _
'''                    ByVal intKind As Integer)
'''    Dim i As Integer, j As Integer
'''
'''    On Error GoTo ERR_HANDLE
'''
'''    '*** Initialize Variables ***
'''    gintSelCount = 0                ' �O�����I�@�@�ΤF�X��attributes���E��
'''    gintSelLowCount = 0             ' �O���C�I�@�@�ΤF�X��attributes���E��
'''    gintClusterCnt = 0              ' �O�����\�F�h�֪��E��pattern
'''    gintSum = 0
'''
'''    If intKind = 1 Then     ' ��
'''        If Not blnClusterDayOK Then
'''            Call ExecGRG(gudtStockDay, gudtIndexDay, gintDayIndex)  ' �E��
'''            blnClusterDayOK = True
'''        End If
''''''''        If strSTA = "POS" Then
''''''''            Call CalculateProfits4CY1(gudtStockDay, gudtIndexDay, gintDayIndex) ' POS
''''''''            Call GenSTA1Report2
''''''''        ElseIf strSTA = "SSOS" Then
''''''''            Call CalculateProfits4CY2(gudtStockDay, gudtIndexDay, gintDayIndex) ' SSOS
''''''''            Call GenSTA2Report2
''''''''        ElseIf strSTA = "EOS" Then
''''''''            Call CalculateProfits4CY3NGLA(gudtStockDay, gudtIndexDay, gintDayIndex) ' EOS
''''''''            Call GenSTA3Report2
''''''''        ElseIf strSTA = "SOS" Then
''''''''            Call CalculateProfits4CY4(gudtStockDay, gudtIndexDay, gintDayIndex) ' SOS
''''''''            Call GenSTA4Report2
''''''''        End If
'''    ElseIf intKind = 2 Then     ' �g
'''        If Not blnClusterWeekOK Then
'''            Call ExecGRG(gudtStockWeek, gudtIndexWeek, gintWeekIndex)
'''            blnClusterWeekOK = True
'''        End If
''''''''        Call CalculateProfits4CY1(gudtStockWeek, gudtIndexWeek, gintWeekIndex)
'''    ElseIf intKind = 3 Then     ' ��
'''        If Not blnClusterMonthOK Then
'''            Call ExecGRG(gudtStockMonth, gudtIndexMonth, gintMonthIndex)
'''            blnClusterMonthOK = True
'''        End If
''''''''        Call CalculateProfits4CY1(gudtStockMonth, gudtIndexMonth, gintMonthIndex)
'''    End If
'''
'''    Exit Sub
'''
'''
'''ERR_HANDLE:
'''    MsgBox "[Method: GenSignals()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
'''End Sub

                                                                                    


'***************************************************************************************************
'* ��    ��:
'*    ���o�̷s�@����ƪ����
'* ��J�Ѽ�:
'*    udtStock �ѥ����
'*    intStockNo �ѥ�����`����
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00  20050604 Earvin �s�W
'***************************************************************************************************
Public Function GetTheLatestDate(ByRef udtStock() As StockData, _
                                    ByVal intStockNo As Integer) As String
    GetTheLatestDate = udtStock(intStockNo).sngDate
End Function



'***************************************************************************************************
'* ��    ��:
'*    �N6�����мg�J�O���޳N���Ъ��}�C��
'* ��J�Ѽ�:
'*    udt6IndexData:
'*    intCount     :
'*    udtStock     :
'*    udtIndex     :
'*    intStockNo   :
'* ��X�Ѽ�: �L
'* ��    ��:
'*    2.00 20050604  Earvin   New
'***************************************************************************************************
Public Sub Write6Index(ByRef udt6IndexData() As SixStockData, _
                        ByVal intCount As Integer, _
                        ByRef udtStock() As StockData, _
                        ByRef udtIndex() As IndexData, _
                        ByVal intStockNo As Integer)
    Dim i As Integer
    Dim j As Integer
    Dim k As Integer
    '--- ���Ƥ�CY index�ϥ��ܼ� ---
    Dim sngValue As Single      ' �x�s�n���W�λ����
    Dim dtTheDate As Date       ' ��� : �_�l���
    Dim sngDate As Single       ' ��� : �������
    Dim intWeekDay As Integer   ' �O���Ӥ�����P���X
    
    On Error GoTo ERR_HANDLE

    '--- Initialize Variables ---
    j = 1
    
    For i = 1 To intStockNo
        If j <= intCount Then
            If udt6IndexData(j).sngDate = udtStock(i).sngDate Then
                With udt6IndexData(j)
                    udtIndex(i).sngDiffOp1 = .sngDiffOp1
                    udtIndex(i).sngDiffOp2 = .sngDiffOp2
                    udtIndex(i).sngQMOp = .sngQMOp
                    udtIndex(i).sngTrendOp = .sngTrendOp
                    udtIndex(i).sngCyOp = .sngCyOp
                    udtIndex(i).sngLstOp = .sngLstOp
                    udtIndex(i).sngLwOp = .sngLwOp
                    
                    j = j + 1
                End With
            ElseIf udt6IndexData(j).sngDate > udtStock(i).sngDate Then
                ' Do nothing
            Else
                j = j + 1
            End If
        Else
            With udtIndex(i)
                .sngDiffOp1 = 0
                .sngDiffOp2 = 0
                .sngQMOp = 0
                .sngTrendOp = 0
                .sngCyOp = 0
                .sngLstOp = 0
                .sngLwOp = 0
            End With
        End If
    Next
    
    Exit Sub
    
ERR_HANDLE:
    Debug.Print "[GCFR_General_Module.Write6Index()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
    Resume Next
End Sub

'***************************************************************************************************
'* ��    ��: ���o�ѥ����I���
'* ��J�Ѽ�: udtStock   �ѥ����
'*           udtIndex   �ѥ����и��
'*           intStockNo �ѥ���ƪ�����
'* ��X�Ѽ�: �L
'* ��    ��: 1.00 20100610 �s�W
'***************************************************************************************************
Public Sub subGenHighPointDate(ByRef udtStock() As StockData, _
                  ByRef udtIndex() As IndexData, _
                  ByVal intStockNo As Integer)
    Dim i As Integer
    Dim j As Integer
    Dim intUp As Integer
    Dim sngPSY As Single
    
    On Error GoTo ERR_HANDLE
    
    j = 2
    
    While j <= intStockNo
        ' ���}��
'        If KDGreaterTheValueAndCrossDown(udtIndex(j - 1).sngK, udtIndex(j - 1).sngD, udtIndex(j).sngK, udtIndex(j).sngD, theValue) Then
'            udtIndex(j).sngSignal = udtIndex(j).sngSignal + 30
'        End If
'        If MACDGreaterTheValueAndCrossDown(udtIndex(j - 1).sngMACD, udtIndex(j - 1).sngDIF, udtIndex(j).sngMACD, udtIndex(j).sngDIF, 0) Then
'            udtIndex(j).sngSignal = udtIndex(j).sngSignal + 30
'        End If
'        If BIASGreaterTheValue(udtIndex(j).sngBias, -10) Then
'            udtIndex(j).sngSignal = udtIndex(j).sngSignal + 30
'        End If
        
        ' �X�b�@�_��
        If (KDGreaterTheValueAndCrossDown(udtIndex(j - 1).sngK, udtIndex(j - 1).sngD, udtIndex(j).sngK, udtIndex(j).sngD, 30) Or _
            MACDGreaterTheValueAndCrossDown(udtIndex(j - 1).sngMACD, udtIndex(j - 1).sngDIF, udtIndex(j).sngMACD, udtIndex(j).sngDIF, 0)) And _
            BIASGreaterTheValue(udtIndex(j).sngBias, 0) Then
            udtIndex(j).sngSignal = udtIndex(j).sngSignal + 130
        End If
   
        j = j + 1
    Wend
    
    Exit Sub
    
ERR_HANDLE:
    Debug.Print "[GCFR_General_Module.subGenHighPointDate()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
End Sub


'***************************************************************************************************
'* ��    ��: ���o�ѥ��C�I���
'* ��J�Ѽ�: udtStock   �ѥ����
'*           udtIndex   �ѥ����и��
'*           intStockNo �ѥ���ƪ�����
'* ��X�Ѽ�: �L
'* ��    ��: 1.00 20100610 �s�W
'***************************************************************************************************
Public Sub subGenLowPointDate(ByRef udtStock() As StockData, _
                  ByRef udtIndex() As IndexData, _
                  ByVal intStockNo As Integer)
    Dim i As Integer
    Dim j As Integer
    
    On Error GoTo ERR_HANDLE
    
    j = 2
   
    ' ���B�C�I�T���ȽаѦ� Form : frmGeryExp�����]�w
    ' KD�� 20�H�U �B K ��e�V�W D
    ' MACD < 0 �B MACD ��e�V�W DIF
    ' BIAS < 0
    While j <= intStockNo
        ' ���}��
'        If KDUnderTheValueAndCrossUp(udtIndex(j - 1).sngK, udtIndex(j - 1).sngD, udtIndex(j).sngK, udtIndex(j).sngD, theValue) Then
'            udtIndex(j).sngSignal = udtIndex(j).sngSignal + 30
'        End If
'        If MACDUnderTheValueAndCrossUp(udtIndex(j - 1).sngMACD, udtIndex(j - 1).sngDIF, udtIndex(j).sngMACD, udtIndex(j).sngDIF, 0) Then
'            udtIndex(j).sngSignal = udtIndex(j).sngSignal + 30
'        End If
'        If BIASUnderTheValue(udtIndex(j).sngBias, -10) Then
'            udtIndex(j).sngSignal = udtIndex(j).sngSignal + 30
'        End If
        
        ' �X�b�@�_��
        If (KDUnderTheValueAndCrossUp(udtIndex(j - 1).sngK, udtIndex(j - 1).sngD, udtIndex(j).sngK, udtIndex(j).sngD, 30) Or _
            MACDUnderTheValueAndCrossUp(udtIndex(j - 1).sngMACD, udtIndex(j - 1).sngDIF, udtIndex(j).sngMACD, udtIndex(j).sngDIF, 0)) And _
            BIASUnderTheValue(udtIndex(j).sngBias, 0) Then
            udtIndex(j).sngSignal = udtIndex(j).sngSignal + 30
        End If
        j = j + 1
    Wend
    
    Exit Sub
    
ERR_HANDLE:
    Debug.Print "[GCFR_General_Module.subGenLowPointDate()] -- " & Err.Number & ":" & Err.Description, vbOKOnly
End Sub


'''' ���o�n�B�z���Ѳ��M��
'''Public Function GetProcessStockList() As String
'''    Dim openFile As String
'''    Dim lineData As String
'''    Dim splitData As Variant
'''    Dim path As String
'''    Dim stockList As String
'''    Dim i As Integer
'''
'''    path = GetAppPath(1)
'''    ' Read StockNo file form "taiwan_stkno.bat" file
'''    openFile = path + "stocks-files\�x�W�ѥ�\�Ӫ�\�ާ@�Ӫ�.txt"
'''    i = 0
'''
'''    Open openFile For Input As #1
'''    While Not EOF(1)
'''        Line Input #1, lineData
'''        splitData = Split(lineData, " ")
'''        stockList = stockList & splitData(1) & ","
'''        i = i + 1
'''    Wend
'''    Close #1
'''
'''    GetProcessStockList = stockList
'''End Function

'''' �M�䰪�B�C�I�T��
'''Public Sub FindHighAndLowSignals()
'''    Dim stockString As String
'''    Dim stockList
'''    Dim i As Integer
'''    Dim sp As SplitParameter
'''
'''    sp = GetSplitParameter
'''    i = 1
'''    stockString = GetProcessStockList
'''    stockList = Split(stockString, ",")
'''
'''    While (UBound(stockList) >= i)
'''        Call ChangeStockData(CStr(stockList(i)), sp)
'''        i = i + 1
'''    Wend
'''
'''End Sub




Private Function KDGreaterTheValueAndCrossDown(ByVal prevK As Single, ByVal prevD As Single, ByVal currK As Single, ByVal currD As Single, ByVal theValue As Single) As Boolean
    If prevK > prevD And _
        currK < currD And _
        prevK > theValue And _
        prevD > theValue And _
        currK > theValue And _
        currD > theValue Then
        KDGreaterTheValueAndCrossDown = True
    Else
        KDGreaterTheValueAndCrossDown = False
    End If
End Function


Private Function MACDUnderTheValueAndCrossUp(ByVal prevMACD As Single, ByVal prevDIF As Single, ByVal currMACD As Single, ByVal currDIF As Single, ByVal theValue As Single) As Boolean
    If prevMACD < prevDIF And currMACD > currDIF And _
        prevMACD < theValue And _
        prevDIF < theValue And _
        currMACD < theValue And _
        currDIF < theValue Then
        MACDUnderTheValueAndCrossUp = True
    Else
        MACDUnderTheValueAndCrossUp = False
    End If
End Function

Private Function MACDGreaterTheValueAndCrossDown(ByVal prevMACD As Single, ByVal prevDIF As Single, ByVal currMACD As Single, ByVal currDIF As Single, ByVal theValue As Single) As Boolean
    If prevMACD > prevDIF And currMACD < currDIF And _
        prevMACD > theValue And _
        prevDIF > theValue And _
        currMACD > theValue And _
        currDIF > theValue Then
        MACDGreaterTheValueAndCrossDown = True
    Else
        MACDGreaterTheValueAndCrossDown = False
    End If
End Function


Private Function BIASUnderTheValue(ByVal currBIAS As Single, ByVal theValue As Single) As Boolean
    If currBIAS < theValue Then
        BIASUnderTheValue = True
    Else
        BIASUnderTheValue = False
    End If
End Function


Private Function BIASGreaterTheValue(ByVal currBIAS As Single, ByVal theValue As Single) As Boolean
    If currBIAS > theValue Then
        BIASGreaterTheValue = True
    Else
        BIASGreaterTheValue = False
    End If
End Function



'''' �]�w�s��ӪѸ�ƪ����|(���o�{���s����|���W1(n)�h(ex: D:\A\B --> D:\A\))
'''Public Function GetAppPath(ByVal upLevel As Integer) As String
'''    Dim blnFlag As Boolean
'''    Dim path As String
'''    Dim strChar As String
'''    Dim intUpDir As Integer
'''    Dim i As Integer
'''    blnFlag = False
'''    intUpDir = 0
'''    path = App.path
'''    For i = Len(path) To 1 Step -1
'''        strChar = Mid(path, i, 1)
'''        If strChar = "\" Then
'''            intUpDir = intUpDir + 1
'''        End If
'''        If intUpDir = upLevel Then
'''            path = Mid(path, 1, i)
'''            Exit For
'''        End If
'''    Next
'''    GetAppPath = path
'''End Function
'''


