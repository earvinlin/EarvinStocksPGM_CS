﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace EarvinStocksPGM.Modules
{
    public static class GeneralModule
    {
        public struct FramePoints
        {
            public float frameX;
            public float frameY;
        }

        public const int MAP_UNSELECTED = 0;
        public const int MAP_KBAR = 1;
        public const int MAP_VOLUME = 2;
        public const int MAP_BIAS = 3;
        public const int MAP_WMS = 4;
        public const int MAP_PSY = 5;
        public const int MAP_SRSI = 6;
        public const int MAP_LRSI = 7;
        public const int MAP_RSI = 8;
        public const int MAP_K = 9;
        public const int MAP_D = 10;
        public const int MAP_KD = 11;
        public const int MAP_DIF = 12;
        public const int MAP_DIF_MACD = 13;
        public const int MAP_MACD = 14;
        public const int MAP_SECTORS = 15;

        // 記錄每個FRAME選擇顯示的資料(最多只能選9個；第1個一定是MAP_K)
        public static int[] SelectShowMapOnFrames = new int[9];

        public class HighLowValues
        {
            public double highValue { get; set; }
            public double lowValue { get; set; }
        }

        public static HighLowValues GetHighLowValue(StockData[] sd, IndexData[] idx, int startIndex, int displayCount, int type)
        {
            double highValue = double.MinValue;
            double lowValue = double.MaxValue;

            switch (type)
            {
                case MAP_KBAR :
                    for (int i = startIndex; i < (startIndex + displayCount); i++)
                    {
                        if (highValue < sd[i].HighPrice)
                            highValue = sd[i].HighPrice;
                        if (lowValue > sd[i].LowPrice)
                            lowValue = sd[i].LowPrice;
                    }
                    break;

                case MAP_VOLUME :
                    for (int i = startIndex; i < (startIndex + displayCount); i++)
                    {
                        if (highValue < sd[i].Volume)
                            highValue = sd[i].Volume;
                        if (lowValue > sd[i].Volume)
                            lowValue = sd[i].Volume;
                    }
                    break;

                case MAP_BIAS :
                    for (int i = startIndex; i < (startIndex + displayCount); i++)
                    {
                        if (highValue < idx[i].BIAS)
                            highValue = idx[i].BIAS;
                        if (lowValue > idx[i].BIAS)
                            lowValue = idx[i].BIAS;
                    }
                    highValue = Math.Round(highValue, 2);
                    lowValue = Math.Round(lowValue, 2);

                    if (highValue >= 0 && lowValue >= 0)
                    {
                        highValue = Math.Ceiling(Math.Abs(highValue));
                        lowValue = -highValue;
                    } 
                    else if (highValue >= 0 && lowValue < 0)
                    {
                        if (Math.Abs(highValue) >= Math.Abs(lowValue))
                        {
                            highValue = Math.Ceiling(Math.Abs(highValue));
                            lowValue = -highValue;
                        }
                        else
                        {
                            highValue = Math.Ceiling(Math.Abs(lowValue));
                            lowValue = -highValue;
                        }
                    }
                    else 
                    {
                        highValue = Math.Ceiling(Math.Abs(lowValue));
                        lowValue = -highValue;
                    }
                    break;

                case MAP_MACD:
                    double[] difValues = idx[startIndex..(startIndex + displayCount - 1)].Select(d => d.DIF).ToArray();
                    double[] macdValues = idx[startIndex..(startIndex + displayCount - 1)].Select(d => d.MACD).ToArray();
                    double[] oscValues = idx[startIndex..(startIndex + displayCount - 1)].Select(d => d.OSC).ToArray();
                    highValue = Math.Max(difValues.Max(), Math.Max(macdValues.Max(),oscValues.Max()));
                    lowValue = Math.Min(difValues.Min(), Math.Min(macdValues.Min(),oscValues.Min()));
                    break;

                case MAP_WMS:
                case MAP_PSY:
                case MAP_SRSI:
                case MAP_LRSI:
                case MAP_K:
                case MAP_D:
                case MAP_KD:
                    highValue = 100;
                    lowValue = 0;
                    break;

                case MAP_SECTORS:
                    highValue = 1;
                    lowValue = -1;
                    break;
            }
            HighLowValues values = new HighLowValues();
            values.highValue = highValue;
            values.lowValue = lowValue;

            return values;
        }

        public static int GetSelectFrame(FramePoints[] frmLeft, FramePoints[] frmRight, Point cursorPos, int frameNum)
        {
            int selectFrame = 0;

            for (int i = 0; i < frameNum; i++)
            {
                if ((cursorPos.Y) < frmLeft[i].frameY)
                {
                    break;
                }
                else if ((cursorPos.Y) >= frmLeft[i].frameY && (cursorPos.Y) <= frmLeft[i + 1].frameY)
                {
                    selectFrame = (i + 1);
                    break;
                }
                else if ((cursorPos.Y) > frmLeft[frameNum].frameY)
                {
                    break;
                }
            }
            return selectFrame;
        }
    }
}